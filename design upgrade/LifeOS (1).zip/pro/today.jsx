// Today — refined. Restrained aurora, hex radar as quiet hero, threaded timeline.
const { ProFrame, Surface, Display, Title, Body, Meta, HexRadar, Avatar, XpBar,
        TimelineBlock, TabBar, Icon, Pressable, MicFab, SURF, R, DOMAINS } = window;

function TodayScreen() {
  const scores = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };
  const avg = Math.round(Object.values(scores).reduce((a, b) => a + b, 0) / 6);

  return (
    <ProFrame time="9:41" sub="01 · home" label="Today" hero footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Greeting row — quiet, asymmetric */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <Meta size={9.5} color={SURF.tx3}>Tue · May 13 · day 47</Meta>
            <Title size={20} style={{ marginTop: 2, letterSpacing: -0.4 }}>Good morning, Arjun</Title>
          </div>
          <MicFab />
        </div>

        {/* Headline — Headspace-style emotional pacing.
            One sentence, large, plenty of air. Cognitive anchor for the day. */}
        <div style={{ paddingTop: 6, paddingBottom: 4 }}>
          <Display size={26} color={SURF.tx1} style={{ letterSpacing: -0.5, fontWeight: 800, lineHeight: 1.18 }}>
            One thing today.<br/>
            <span style={{ color: SURF.tx2, fontWeight: 600 }}>The </span>
            <span style={{ color: '#C5B3FF', fontWeight: 700 }}>ML mock at 4 PM</span>
            <span style={{ color: SURF.tx2, fontWeight: 600 }}> — the rest is rhythm.</span>
          </Display>
        </div>

        {/* Hex radar — quieter, smaller, set inside a surface so it reads as a panel
            rather than a free-floating decoration. Compact summary line under. */}
        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ flex: '0 0 auto' }}>
              <HexRadar scores={scores} size={156} showLabels={false} />
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <Meta>Life balance</Meta>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
                <Display size={36} color={SURF.tx1} style={{ lineHeight: 1 }}>{avg}</Display>
                <Meta color="#7EE0B8">▲ 4 wk</Meta>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 5, marginTop: 12 }}>
                {Object.entries(scores).sort(([,a],[,b]) => b-a).slice(0,3).map(([k,v]) => {
                  const d = DOMAINS[k];
                  return (
                    <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <div style={{ width: 5, height: 5, borderRadius: 3, background: d.hue }} />
                      <Body size={11.5} color={SURF.tx2} style={{ flex: 1, fontFamily: 'DM Sans' }}>{d.label}</Body>
                      <Meta size={10} color={SURF.tx2}>{v}</Meta>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Surface>

        {/* Section header — Today's flow */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
          <Title size={17}>Today's flow</Title>
          <div style={{ flex: 1 }} />
          <Meta size={10}>2 / 6 done</Meta>
        </div>

        {/* Timeline with vertical thread */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <TimelineBlock first time="06:30" title="Wake · sunlight · 16oz water" module="health" status="completed" />
          <TimelineBlock time="07:00" title="Strength · push day" module="health" status="completed" />
          <TimelineBlock time="09:00" title="Deep work · spec for Q3" sub="2h 30m · phone in dock" module="goal" live />
          <TimelineBlock time="12:30" title="Lunch · 600 kcal · 35g protein" module="health" />
          <TimelineBlock time="14:00" title="Andrew Ng · Sequence Models · L4" module="polymath" />
          <TimelineBlock last time="16:00" title="ML mock interview · system design" sub="Make-or-break for the week's career streak" module="career" />
        </div>

        {/* Quiet end-of-day nudge — single line, no glow */}
        <Pressable style={{ marginTop: 4 }}>
          <Surface level={1} padding={14} radius={R.md} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 28, height: 28, borderRadius: 14,
              background: 'rgba(255,214,107,0.12)', border: '1px solid rgba(255,214,107,0.28)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="moon" size={14} color="#FFD66B" />
            </div>
            <div style={{ flex: 1 }}>
              <Title size={13.5}>9 PM · evening review</Title>
              <Body size={11} color={SURF.tx3} style={{ marginTop: 1 }}>60 seconds · sets up tomorrow</Body>
            </div>
            <Icon name="chevron" size={16} color={SURF.tx3} />
          </Surface>
        </Pressable>

        {/* XP + streak — collapsed into one calm footer chip row. No glow text. */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '6px 2px 16px' }}>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 5 }}>
              <Meta size={9.5}>L7 navigator</Meta>
              <Meta size={9.5} color={SURF.tx2}>320 / 800 xp</Meta>
            </div>
            <XpBar pct={0.4} height={4} />
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', borderRadius: R.pill, border: `1px solid ${SURF.hairline}`, background: SURF.s1 }}>
            <Icon name="flame" size={12} color="#FF8C3C" strokeWidth={1.8} />
            <span style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: SURF.tx1 }}>47</span>
            <Meta size={9} color={SURF.tx3} style={{ letterSpacing: 0.8 }}>learn</Meta>
          </div>
        </div>
      </div>
    </ProFrame>
  );
}

window.TodayScreen = TodayScreen;
