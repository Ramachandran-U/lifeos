// Intro cover — refinement principles. Single wide artboard, like a strategy memo.
const { SURF, R, DOMAINS, Display, Title, Body, Meta, Icon } = window;

function IntroCover() {
  return (
    <div style={{
      width: 920, height: 1180,
      background: '#0B0712',
      padding: 56,
      fontFamily: 'DM Sans, system-ui',
      position: 'relative', overflow: 'hidden',
      color: SURF.tx1,
    }}>
      {/* Quiet aurora wash, single corner */}
      <div style={{
        position: 'absolute', top: -200, right: -180, width: 520, height: 520, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(165,132,255,0.18), rgba(165,132,255,0) 70%)',
        filter: 'blur(36px)', pointerEvents: 'none',
      }} />
      <div style={{
        position: 'absolute', top: -100, right: -50, width: 320, height: 320, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(126,224,184,0.08), rgba(126,224,184,0) 70%)',
        filter: 'blur(28px)', pointerEvents: 'none',
      }} />

      {/* Masthead */}
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, marginBottom: 8, position: 'relative' }}>
        <Meta size={11} color="rgba(244,239,255,0.4)">LifeOS · v2 refinement</Meta>
        <div style={{ flex: 1, height: 1, background: SURF.hairline }} />
        <Meta size={11} color="rgba(244,239,255,0.4)">May 13 · 2026</Meta>
      </div>

      <div style={{ marginTop: 28, maxWidth: 720, position: 'relative' }}>
        <Display size={64} style={{ letterSpacing: -1.2, lineHeight: 1, fontWeight: 800 }}>
          Same identity.<br/>
          <span style={{ color: SURF.tx3 }}>Quieter. Smarter.<br/>More tactile.</span>
        </Display>
        <Body size={17} color={SURF.tx2} style={{ marginTop: 32, lineHeight: 1.55, maxWidth: 560 }}>
          Aurora Refined v2 keeps the violet-and-teal soul, the hex radar, the glass surfaces. What changes is the <span style={{ color: SURF.tx1, fontWeight: 600 }}>posture</span> — less performance, more inhabited product. Color becomes data, motion becomes feedback, gamification becomes a quiet companion instead of a stage manager.
        </Body>
      </div>

      {/* Two-column rules */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, marginTop: 64, position: 'relative' }}>
        {/* Preserved */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: '#7EE0B8' }} />
            <Meta size={11} color="#7EE0B8">Preserved</Meta>
          </div>
          {[
            ['Aurora palette', 'Violet, teal, gold, peach, pink, blue — still the six domain hues.'],
            ['Hex radar',      'Still the hero. Now thinner, smaller dots, no halo or glow.'],
            ['Glass DNA',      'Surfaces still translucent. Just one elevation system instead of five.'],
            ['Typography',     'Nunito display, DM Sans body, JetBrains Mono meta. Used with more confidence, less variety.'],
            ['Dark first',     'Same canvas, same calm violet-black.'],
          ].map(([h, p], i) => (
            <div key={i} style={{ padding: '14px 0', borderTop: i ? `1px solid ${SURF.hairline}` : 'none' }}>
              <Title size={15} style={{ letterSpacing: -0.1 }}>{h}</Title>
              <Body size={12.5} color={SURF.tx3} style={{ marginTop: 4, lineHeight: 1.5 }}>{p}</Body>
            </div>
          ))}
        </div>

        {/* Removed / Tuned */}
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 18 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: '#FF99C5' }} />
            <Meta size={11} color="#FF99C5">Tuned down</Meta>
          </div>
          {[
            ['Neon glow',          'No more text-shadow halos on numbers, flames, or icons. Light should fall on data, not radiate from it.'],
            ['Aurora orbs',        'Reserved for the Today hero, with a defined fade-out band. Other screens get a clean canvas.'],
            ['Tinted everything',  'Cards lean neutral (rgba 0.04). Hue lives in 1–2 hairlines, dots, or a single bar — not the fill.'],
            ['Gamification noise', 'Streaks compressed to a tidy grid. Confetti specks gone. XP toasts arrive briefly and leave.'],
            ['Random radii',       '8 / 12 / 16 / 20 / 28 / pill. Five values, used consistently across every surface.'],
          ].map(([h, p], i) => (
            <div key={i} style={{ padding: '14px 0', borderTop: i ? `1px solid ${SURF.hairline}` : 'none' }}>
              <Title size={15} style={{ letterSpacing: -0.1 }}>{h}</Title>
              <Body size={12.5} color={SURF.tx3} style={{ marginTop: 4, lineHeight: 1.5 }}>{p}</Body>
            </div>
          ))}
        </div>
      </div>

      {/* Footer references */}
      <div style={{ position: 'absolute', left: 56, right: 56, bottom: 48, display: 'flex', alignItems: 'center', gap: 18, paddingTop: 24, borderTop: `1px solid ${SURF.hairline}` }}>
        <Meta size={11} color={SURF.tx3}>Reference posture</Meta>
        {[
          'Apple Fitness · rings',
          'Headspace · pacing',
          'Arc Browser · chrome',
          'Notion Calendar · type',
          'Linear · restraint',
          'Duolingo · warmth',
        ].map((r, i) => (
          <div key={r} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            {i > 0 && <div style={{ width: 3, height: 3, borderRadius: 2, background: SURF.tx4 }} />}
            <Body size={12} color={SURF.tx2} style={{ fontFamily: 'DM Sans' }}>{r}</Body>
          </div>
        ))}
      </div>
    </div>
  );
}

window.IntroCover = IntroCover;
