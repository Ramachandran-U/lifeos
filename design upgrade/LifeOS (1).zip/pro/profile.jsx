// Profile — refined. Quiet hero, hex radar as data, typographic settings list.
const { ProFrame, Surface, Display, Title, Body, Meta, Avatar, HexRadar, TabBar,
        Icon, Pressable, SURF, R, DOMAINS } = window;

function ProfileScreen() {
  const scores = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };

  return (
    <ProFrame time="9:41" sub="07 · me" label="Profile" footer={<div style={{ paddingBottom: 12 }}><TabBar active="profile" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Hero — Linear-like header */}
        <div style={{ marginTop: 10, display: 'flex', alignItems: 'center', gap: 14 }}>
          <Avatar initials="AR" pct={0.4} size={68} showLevel level={7} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <Title size={20} style={{ letterSpacing: -0.3 }}>Arjun Reddy</Title>
            <Meta size={9.5} color={SURF.tx3} style={{ marginTop: 4 }}>Navigator · joined Mar 28 · 47 days</Meta>
            <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
              <div style={{ padding: '3px 9px', borderRadius: R.pill, border: '1px solid rgba(127,184,255,0.28)', background: 'rgba(127,184,255,0.06)', fontFamily: 'DM Sans', fontWeight: 600, fontSize: 11, color: '#7FB8FF' }}>
                Data → ML
              </div>
              <div style={{ padding: '3px 9px', borderRadius: R.pill, border: '1px solid rgba(126,224,184,0.28)', background: 'rgba(126,224,184,0.06)', fontFamily: 'DM Sans', fontWeight: 600, fontSize: 11, color: '#7EE0B8' }}>
                75 kg
              </div>
            </div>
          </div>
        </div>

        {/* Balance — small radar + ordered bar list */}
        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ flex: '0 0 auto' }}>
              <HexRadar scores={scores} size={130} showLabels={false} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 7 }}>
              {Object.entries(scores).sort(([,a],[,b]) => b-a).map(([k,v]) => {
                const d = DOMAINS[k];
                return (
                  <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                    <div style={{ width: 5, height: 5, borderRadius: 3, background: d.hue }} />
                    <Body size={11.5} color={SURF.tx2} style={{ flex: 1, fontFamily: 'DM Sans' }}>{d.label}</Body>
                    <div style={{ width: 56, height: 2.5, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                      <div style={{ width: `${v}%`, height: '100%', background: d.hue }} />
                    </div>
                    <Meta size={10} color={SURF.tx2} style={{ width: 20, textAlign: 'right' }}>{v}</Meta>
                  </div>
                );
              })}
            </div>
          </div>
        </Surface>

        {/* Stats — calm row, no glow */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, border: `1px solid ${SURF.hairline}`, borderRadius: R.md, padding: '14px 0' }}>
          {[
            { l: 'Days',   v: '47',   sub: 'since Mar 28' },
            { l: 'Blocks', v: '342',  sub: 'completed'    },
            { l: 'XP',     v: '3.8k', sub: 'top 12%'      },
          ].map((s, i) => (
            <div key={s.l} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
              borderLeft: i ? `1px solid ${SURF.hairline}` : 'none',
              padding: '0 8px',
            }}>
              <Meta size={9}>{s.l}</Meta>
              <Display size={22} style={{ marginTop: 2 }}>{s.v}</Display>
              <Meta size={9} color={SURF.tx3} style={{ marginTop: 2 }}>{s.sub}</Meta>
            </div>
          ))}
        </div>

        {/* Settings — clean typographic list */}
        <div>
          <Title size={14} color={SURF.tx2} style={{ marginBottom: 10, fontWeight: 700 }}>Account & integrations</Title>
          <Surface level={1} padding={0} radius={R.md} style={{ overflow: 'hidden' }}>
            {[
              { i: '◇', l: 'Vision & goals',      sub: '8 goals · 32 nodes',         c: '#C9A0FF', live: true },
              { i: '☉', l: 'Google Calendar',     sub: '6 events synced today',      c: '#7FB8FF', live: true },
              { i: '✉', l: 'Gmail · finance',     sub: 'HDFC · ICICI · AXIS · 124 tx', c: '#F4C16A', live: true },
              { i: '⌥', l: 'Notifications',       sub: '6:30 morning · 8 PM streak', c: '#FFD66B' },
              { i: '⊘', l: 'Privacy & export',    sub: 'on-device · SQLite',          c: '#FF99C5' },
              { i: '↗', l: 'How it works',        sub: '6 engines · 9 AI functions', c: '#A584FF' },
            ].map((row, i, arr) => (
              <Pressable key={row.l} style={{ borderRadius: 0 }}>
                <div style={{
                  display: 'flex', alignItems: 'center', gap: 14, padding: '14px 14px',
                  borderTop: i ? `1px solid ${SURF.hairline}` : 'none',
                }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: 9,
                    background: SURF.s2, border: `1px solid ${SURF.hairline}`,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    color: row.c, fontFamily: 'Nunito', fontWeight: 800, fontSize: 14,
                  }}>{row.i}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <Title size={13.5} style={{ fontWeight: 700 }}>{row.l}</Title>
                    <Meta size={9.5} color={SURF.tx3} style={{ marginTop: 2, letterSpacing: 0.6 }}>{row.sub}</Meta>
                  </div>
                  {row.live && <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />}
                  <Icon name="chevron" size={14} color={SURF.tx3} />
                </div>
              </Pressable>
            ))}
          </Surface>
        </div>

        {/* Privacy footer */}
        <div style={{
          padding: '14px', borderRadius: R.md,
          border: `1px solid ${SURF.hairline}`,
          display: 'flex', gap: 12, alignItems: 'center',
        }}>
          <Icon name="leaf" size={18} color="#7EE0B8" strokeWidth={1.5} />
          <div style={{ flex: 1 }}>
            <Title size={12.5} style={{ fontWeight: 700 }}>Private by design</Title>
            <Body size={11} color={SURF.tx3} style={{ marginTop: 2 }}>Everything you log lives on this device. AI inference is the only outbound call.</Body>
          </div>
        </div>
      </div>
    </ProFrame>
  );
}

window.ProfileScreen = ProfileScreen;
