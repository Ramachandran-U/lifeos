// Rewards — refined. Gamification dialed DOWN.
// Quiet level card, streaks as a compact grid, badges restrained,
// quests as typographic rows. No confetti decorations, no glow text.
const { ProFrame, Surface, Display, Title, Body, Meta, Avatar, XpBar, TabBar,
        Icon, Pressable, SURF, R, DOMAINS } = window;

function RewardsScreen() {
  const streaks = [
    { l: 'Learn',   c: 47, hue: '#7FB8FF', best: true },
    { l: 'Workout', c: 12, hue: '#7EE0B8' },
    { l: 'Food',    c: 3,  hue: '#C9A0FF' },
    { l: 'Journal', c: 0,  hue: '#FFD66B', dim: true },
    { l: 'Social',  c: 0,  hue: '#FF99C5', dim: true },
  ];

  const badges = [
    { l: 'First Blueprint', g: '◆', hue: '#C9A0FF', earned: true },
    { l: 'Photo Logger',    g: '♥', hue: '#7EE0B8', earned: true },
    { l: '30-Day Flame',    g: '▲', hue: '#FF8C3C', earned: true },
    { l: 'Body Reader',     g: '♥', hue: '#FF99C5', earned: true },
    { l: 'Week One',        g: '●', hue: '#7FB8FF', earned: true },
    { l: 'Mastered Skill',  g: '▲', hue: '#A584FF', earned: false },
    { l: 'Life Balance',    g: '✦', hue: '#FFD66B', earned: false },
    { l: 'Goal Closer',     g: '◆', hue: '#C9A0FF', earned: false },
  ];

  return (
    <ProFrame time="9:41" sub="06 · rewards" label="Rewards" footer={<div style={{ paddingBottom: 12 }}><TabBar active="rewards" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 20 }}>
        {/* Header */}
        <div style={{ marginTop: 8 }}>
          <Meta color="#C5B3FF">Progress</Meta>
          <Display size={26} style={{ marginTop: 4 }}>Steady wins</Display>
          <Body size={12.5} color={SURF.tx2} style={{ marginTop: 4 }}>3,820 XP · top 12% this season</Body>
        </div>

        {/* Level — quiet, no confetti, single corner spark */}
        <Surface level={1} padding={18} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Avatar initials="AR" pct={0.4} size={56} showLevel level={7} />
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                <Title size={16}>Navigator</Title>
                <Meta size={9.5} color={SURF.tx3}>level 7</Meta>
              </div>
              <div style={{ marginTop: 8 }}>
                <XpBar pct={0.4} height={5} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
                <Meta size={9.5} color={SURF.tx3}>320 / 800 to L8</Meta>
                <Meta size={9.5} color={SURF.tx2}>+75 today</Meta>
              </div>
            </div>
          </div>
        </Surface>

        {/* Today's XP — single small typographic row, no chunky pills */}
        <div>
          <Meta>Today's xp · 75</Meta>
          <div style={{ display: 'flex', flexDirection: 'column', marginTop: 8 }}>
            {[
              { l: 'Wake routine',     v: 10, c: '#7EE0B8' },
              { l: 'Strength · push',  v: 10, c: '#7EE0B8' },
              { l: 'Food photo',       v: 20, c: '#C9A0FF' },
              { l: 'Goal task · spec', v: 15, c: '#C9A0FF' },
              { l: 'Resource · L4',    v: 20, c: '#FFD66B' },
            ].map((x, i, arr) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 2px',
                borderTop: i === 0 ? `1px solid ${SURF.hairline}` : 'none',
                borderBottom: i === arr.length - 1 ? 'none' : `1px solid ${SURF.hairline}`,
              }}>
                <div style={{ width: 4, height: 4, borderRadius: 2, background: x.c }} />
                <Body size={13} color={SURF.tx1} style={{ flex: 1, fontFamily: 'DM Sans', fontWeight: 500 }}>{x.l}</Body>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: SURF.tx2 }}>+{x.v} xp</span>
              </div>
            ))}
          </div>
        </div>

        {/* Streaks — compact horizontal row, not enormous bars.
            Use a single number per streak; one calm "best" marker on Learn. */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 10 }}>
            <Title size={15}>Streaks</Title>
            <div style={{ flex: 1 }} />
            <Meta size={9.5}>3 active · 1 grace</Meta>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
            {streaks.map(s => (
              <div key={s.l} style={{
                position: 'relative',
                padding: '12px 6px', borderRadius: R.md,
                background: s.dim ? SURF.s1 : SURF.s2,
                border: `1px solid ${SURF.hairline}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
              }}>
                {s.best && <div style={{ position: 'absolute', top: 5, right: 5, width: 4, height: 4, borderRadius: 2, background: '#FFD66B' }} />}
                <div style={{
                  fontFamily: 'Nunito', fontWeight: 800, fontSize: 18,
                  color: s.dim ? SURF.tx4 : SURF.tx1, lineHeight: 1, letterSpacing: -0.4,
                }}>{s.c || '—'}</div>
                <Meta size={9} color={s.dim ? SURF.tx4 : SURF.tx3} style={{ letterSpacing: 0.8 }}>{s.l}</Meta>
              </div>
            ))}
          </div>
        </div>

        {/* Quests — typographic, no big xp pills, color stays on the bar */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 10 }}>
            <Title size={15}>Quests</Title>
            <div style={{ flex: 1 }} />
            <Meta size={9.5}>2 daily · 1 weekly</Meta>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {[
              { l: 'Log 3 meals',         mod: 'health',   pct: 0.67, n: '2/3', xp: 30,  period: 'Daily' },
              { l: 'Finish one resource', mod: 'polymath', pct: 1.0,  n: '1/1', xp: 100, period: 'Daily', done: true },
              { l: '5 deep-work blocks',  mod: 'goal',     pct: 0.4,  n: '2/5', xp: 200, period: 'Weekly' },
            ].map((q, i, arr) => {
              const d = DOMAINS[q.mod];
              return (
                <div key={i} style={{
                  padding: '14px 4px', display: 'flex', alignItems: 'center', gap: 12,
                  borderTop: i === 0 ? `1px solid ${SURF.hairline}` : 'none',
                  borderBottom: i === arr.length - 1 ? `1px solid ${SURF.hairline}` : `1px solid ${SURF.hairline}`,
                }}>
                  <div style={{
                    width: 18, height: 18, borderRadius: 9,
                    border: `1.5px solid ${q.done ? d.hue : SURF.hairlineStrong}`,
                    background: q.done ? d.hue : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
                  }}>
                    {q.done && <svg width="10" height="10" viewBox="0 0 14 14"><path d="M3 7 L6 10 L11 4" stroke={SURF.bg} strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                      <Title size={13.5} style={{ fontWeight: 700, textDecoration: q.done ? 'line-through' : 'none', textDecorationColor: SURF.tx4 }}>{q.l}</Title>
                      <Meta size={9} color={SURF.tx3}>{q.period}</Meta>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                      <div style={{ flex: 1, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                        <div style={{ width: `${q.pct * 100}%`, height: '100%', background: d.hue }} />
                      </div>
                      <Meta size={9.5} color={SURF.tx3}>{q.n}</Meta>
                    </div>
                  </div>
                  <Meta size={10} color={SURF.tx2}>+{q.xp}</Meta>
                </div>
              );
            })}
          </div>
        </div>

        {/* Badges — smaller, no neon glow */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 10 }}>
            <Title size={15}>Badges</Title>
            <div style={{ flex: 1 }} />
            <Meta size={9.5}>5 / 8</Meta>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
            {badges.map((b, i) => (
              <div key={i} style={{
                aspectRatio: '1', borderRadius: R.md,
                background: b.earned ? SURF.s2 : SURF.s1,
                border: `1px solid ${b.earned ? b.hue + '44' : SURF.hairline}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
                opacity: b.earned ? 1 : 0.45,
              }}>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 18, color: b.earned ? b.hue : SURF.tx4 }}>{b.g}</div>
                <Meta size={8.5} color={b.earned ? SURF.tx2 : SURF.tx4} style={{ textAlign: 'center', letterSpacing: 0.4, padding: '0 4px' }}>{b.l}</Meta>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ProFrame>
  );
}

window.RewardsScreen = RewardsScreen;
