// Health — refined. Single calorie ring, restrained macros, typographic meal list.
const { ProFrame, Surface, Display, Title, Body, Meta, Ring, Sparkline, TabBar,
        Icon, Pressable, SURF, R, DOMAINS } = window;

function HealthScreen() {
  return (
    <ProFrame time="9:41" sub="03 · health" label="Health" footer={<div style={{ paddingBottom: 12 }}><TabBar active="goals" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 8 }}>
          <div>
            <Meta color="#7EE0B8">Health</Meta>
            <Display size={26} style={{ marginTop: 4 }}>Fueling well</Display>
            <Body size={12.5} color={SURF.tx2} style={{ marginTop: 4 }}>1,420 of 2,000 kcal · 580 to go</Body>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '6px 10px', borderRadius: R.pill, border: '1px solid rgba(126,224,184,0.28)', background: 'rgba(126,224,184,0.08)' }}>
            <Icon name="flame" size={11} color="#7EE0B8" strokeWidth={1.8} />
            <span style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: '#7EE0B8' }}>12d</span>
          </div>
        </div>

        {/* Ring hero — single ring, big focal number. No glow filter. */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0 2px' }}>
          <Ring
            size={210}
            stroke={11}
            gap={4}
            segments={[
              { value: 1420, max: 2000, color: '#7EE0B8' },
              { value: 92,   max: 140,  color: '#F4C16A' },
              { value: 165,  max: 220,  color: '#7FB8FF' },
            ]}
            center={
              <>
                <Meta size={9.5}>kcal left</Meta>
                <Display size={42} style={{ marginTop: 2 }}>580</Display>
                <Meta size={9.5} color="#7EE0B8" style={{ marginTop: 4 }}>on pace</Meta>
              </>
            }
          />
        </div>

        {/* Macros — horizontal trio, hairlines instead of colored boxes */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 0, border: `1px solid ${SURF.hairline}`, borderRadius: R.md, padding: '12px 4px' }}>
          {[
            { l: 'Protein', cur: 92,  max: 140, u: 'g', c: '#F4C16A' },
            { l: 'Carbs',   cur: 165, max: 220, u: 'g', c: '#7FB8FF' },
            { l: 'Fibre',   cur: 22,  max: 30,  u: 'g', c: '#FF99C5' },
          ].map((m, i) => (
            <div key={m.l} style={{
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              borderLeft: i ? `1px solid ${SURF.hairline}` : 'none',
              padding: '2px 8px',
            }}>
              <Meta size={9.5}>{m.l}</Meta>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 2 }}>
                <span style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 18, color: SURF.tx1, letterSpacing: -0.3 }}>{m.cur}</span>
                <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: SURF.tx3 }}>/{m.max}{m.u}</span>
              </div>
              <div style={{ width: 36, height: 2, borderRadius: 1, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                <div style={{ width: `${(m.cur/m.max)*100}%`, height: '100%', background: m.c }} />
              </div>
            </div>
          ))}
        </div>

        {/* Snap-meal CTA — quieter, no big colored button */}
        <Pressable>
          <Surface level={2} padding={14} radius={R.md} style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 38, height: 38, borderRadius: 12,
              background: 'rgba(126,224,184,0.10)', border: '1px solid rgba(126,224,184,0.24)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <Icon name="camera" size={18} color="#7EE0B8" strokeWidth={1.6} />
            </div>
            <div style={{ flex: 1 }}>
              <Title size={14}>Snap your meal</Title>
              <Body size={11.5} color={SURF.tx3} style={{ marginTop: 1 }}>AI recognises foods + macros · 2s</Body>
            </div>
            <Icon name="chevron" size={16} color={SURF.tx3} />
          </Surface>
        </Pressable>

        {/* Today's meals — typographic, no emoji */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 10 }}>
            <Title size={15}>Today</Title>
            <div style={{ flex: 1 }} />
            <Meta size={9.5}>3 logged</Meta>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {[
              { t: 'Oats, whey, banana',     time: '07:15', kcal: 470, p: 32 },
              { t: 'Chicken bowl + greens',  time: '12:45', kcal: 620, p: 48 },
              { t: 'Black coffee, oat milk', time: '15:20', kcal: 80,  p: 1 },
            ].map((m, i, arr) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '12px 2px',
                borderTop: i === 0 ? `1px solid ${SURF.hairline}` : 'none',
                borderBottom: `1px solid ${SURF.hairline}`,
              }}>
                <div style={{ width: 38, fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: SURF.tx3, letterSpacing: 0.8 }}>{m.time}</div>
                <div style={{ flex: 1 }}>
                  <Title size={13.5} style={{ fontWeight: 700 }}>{m.t}</Title>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <span style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: SURF.tx1 }}>{m.kcal}</span>
                  <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: SURF.tx3, marginLeft: 4 }}>kcal · {m.p}P</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Weight trend — Apple-Health-style minimal */}
        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'baseline' }}>
            <div>
              <Meta>Weight · 7 days</Meta>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 6 }}>
                <Display size={28}>78.4<span style={{ fontSize: 12, color: SURF.tx3, fontWeight: 600, marginLeft: 2 }}>kg</span></Display>
                <div style={{ display: 'flex', alignItems: 'center', gap: 2, color: '#7EE0B8' }}>
                  <Icon name="arrowDown" size={11} color="#7EE0B8" strokeWidth={2} />
                  <Meta size={10} color="#7EE0B8">1.2</Meta>
                </div>
              </div>
            </div>
            <div style={{ flex: 1 }} />
            <Meta size={9.5} color={SURF.tx3}>target 75 · 24 days</Meta>
          </div>
          <div style={{ marginTop: 12 }}>
            <Sparkline data={[79.6, 79.2, 79.0, 78.9, 78.7, 78.5, 78.4]} color="#7FB8FF" width={310} height={48} />
          </div>
        </Surface>

        {/* Blood report — single AI insight, quiet */}
        <Surface level={2} padding={16} radius={R.lg} accent="#FF99C5">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Icon name="sparkle" size={12} color="#FF99C5" strokeWidth={1.6} />
            <Meta color="#FF99C5">Blood report · 6 days ago</Meta>
          </div>
          <Body size={13.5} color={SURF.tx1} style={{ lineHeight: 1.5 }}>
            Vitamin D is <span style={{ color: '#F4C16A', fontWeight: 600 }}>low — 18 ng/mL</span>. Most other markers healthy. Try 10 min sun before 10 AM and 2000 IU.
          </Body>
          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <Pressable>
              <div style={{ padding: '8px 12px', borderRadius: R.sm, background: 'rgba(255,153,197,0.14)', border: '1px solid rgba(255,153,197,0.3)', fontFamily: 'DM Sans', fontWeight: 600, fontSize: 12, color: '#FF99C5' }}>
                Add 3 actions
              </div>
            </Pressable>
            <Pressable>
              <div style={{ padding: '8px 12px', borderRadius: R.sm, border: `1px solid ${SURF.hairline}`, fontFamily: 'DM Sans', fontWeight: 600, fontSize: 12, color: SURF.tx2 }}>
                See all 11 markers
              </div>
            </Pressable>
          </div>
        </Surface>
      </div>
    </ProFrame>
  );
}

window.HealthScreen = HealthScreen;
