// Interaction states — refined behavior, not loud showcases.
// Each artboard demonstrates a single moment of product maturity.
const { ProFrame, Surface, Display, Title, Body, Meta, Skel,
        HexRadar, Avatar, XpBar, TimelineBlock, TabBar, Ring, Sparkline,
        Icon, Pressable, MicFab, SURF, R, DOMAINS } = window;

// ─────────────────────────────────────────────────────────────
// STATE A — Today, scrolled. The hero collapses into a compact band.
// The radar shrinks to an inline summary; greeting becomes a quiet tag.
// Demonstrates: navigation continuity, scroll behavior, info pacing.
// ─────────────────────────────────────────────────────────────
function TodayScrolled() {
  return (
    <ProFrame time="9:41" sub="State · scrolled" label="Today / sticky" footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      {/* Collapsed sticky header */}
      <div style={{
        position: 'sticky', top: 0, zIndex: 5,
        background: 'rgba(11,7,18,0.85)',
        backdropFilter: 'blur(20px) saturate(140%)',
        WebkitBackdropFilter: 'blur(20px) saturate(140%)',
        borderBottom: `1px solid ${SURF.hairline}`,
        padding: '10px 20px',
        display: 'flex', alignItems: 'center', gap: 12,
        marginTop: 4,
      }}>
        <Avatar initials="AR" pct={0.42} size={32} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <Title size={14}>Today</Title>
          <Meta size={9}>balance 64 · 2 of 6 done</Meta>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ width: 24, height: 24, borderRadius: 12, border: `1px solid ${SURF.hairline}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <Icon name="search" size={12} color={SURF.tx2} />
          </div>
          <MicFab size={32} />
        </div>
      </div>

      <div style={{ padding: '14px 20px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* Live block — pinned visibility, NOW tag */}
        <Surface level={2} padding={14} radius={R.md} accent={DOMAINS.goal.hue}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Meta color="#C5B3FF">Live · deep work</Meta>
            <div style={{ flex: 1 }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 5, height: 5, borderRadius: 3, background: '#C5B3FF', animation: 'lifeos-breathe 2.6s ease-in-out infinite' }} />
              <Meta size={9.5} color="#C5B3FF">42m left</Meta>
            </div>
          </div>
          <Title size={15}>Spec for Q3 launch</Title>
          <Body size={11.5} color={SURF.tx3} style={{ marginTop: 4 }}>Started 09:18 · phone in dock</Body>
          {/* Linear progress */}
          <div style={{ marginTop: 12, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
            <div style={{ width: '62%', height: '100%', background: 'linear-gradient(90deg, #A584FF, #C5B3FF)' }} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
            <div style={{ flex: 1, padding: '8px 0', textAlign: 'center', borderRadius: R.sm, background: SURF.s2, border: `1px solid ${SURF.hairline}`, fontFamily: 'DM Sans', fontWeight: 600, fontSize: 12, color: SURF.tx1 }}>
              Pause
            </div>
            <div style={{ flex: 1, padding: '8px 0', textAlign: 'center', borderRadius: R.sm, background: 'rgba(165,132,255,0.16)', border: '1px solid rgba(165,132,255,0.32)', fontFamily: 'DM Sans', fontWeight: 600, fontSize: 12, color: '#C5B3FF' }}>
              Done early
            </div>
          </div>
        </Surface>

        {/* Up next */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <Title size={14}>Up next</Title>
            <div style={{ flex: 1 }} />
            <Meta size={9.5}>3 remaining</Meta>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            <TimelineBlock first time="12:30" title="Lunch · 600 kcal" module="health" />
            <TimelineBlock time="14:00" title="Andrew Ng · L4" module="polymath" />
            <TimelineBlock last time="16:00" title="ML mock · system design" module="career" />
          </div>
        </div>

        <Surface level={1} padding={14} radius={R.md} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <Icon name="sparkle" size={13} color="#C5B3FF" />
          <Body size={12} color={SURF.tx2} style={{ flex: 1, lineHeight: 1.45 }}>
            You're 8 minutes ahead of yesterday's pace.
          </Body>
        </Surface>
      </div>
    </ProFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// STATE B — Quick log sheet. A bottom sheet over a dimmed Today.
// Demonstrates: modal hierarchy, focus state, microinteraction polish.
// ─────────────────────────────────────────────────────────────
function QuickLogSheet() {
  const items = [
    { l: 'Meal',     i: 'camera',  c: '#7EE0B8', sub: 'snap or describe' },
    { l: 'Mood',     i: 'sun',     c: '#FFD66B', sub: 'one-tap dial'     },
    { l: 'Workout',  i: 'bolt',    c: '#7FB8FF', sub: 'auto-detected'    },
    { l: 'Spend',    i: 'plus',    c: '#F4C16A', sub: 'amount + category'},
    { l: 'Journal',  i: 'leaf',    c: '#C9A0FF', sub: '60s · voice or text'},
    { l: 'Resource', i: 'bell',    c: '#FF99C5', sub: 'paper · video · book'},
  ];
  return (
    <ProFrame time="9:41" sub="State · quick log" label="Sheet over today" footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      {/* Dimmed page behind — minimal preview */}
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 12, filter: 'brightness(0.45) saturate(0.85)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Good morning, Arjun</Title>
          </div>
        </div>
        <Display size={24} style={{ marginTop: 6 }}>One thing today.</Display>
        <Skel w="80%" h={20} r={6} style={{ marginTop: 4 }} />
        <Skel w="60%" h={20} r={6} />
        <Surface level={1} padding={16} radius={R.lg} style={{ marginTop: 6, height: 180 }} />
      </div>

      {/* Scrim */}
      <div style={{ position: 'absolute', inset: 0, background: 'rgba(8,4,16,0.55)', zIndex: 4 }} />

      {/* Sheet */}
      <div style={{
        position: 'absolute', left: 9, right: 9, bottom: 9, zIndex: 5,
        background: SURF.s4,
        borderTopLeftRadius: 32, borderTopRightRadius: 32,
        borderBottomLeftRadius: 38, borderBottomRightRadius: 38,
        backdropFilter: 'blur(28px) saturate(140%)',
        WebkitBackdropFilter: 'blur(28px) saturate(140%)',
        border: `1px solid ${SURF.hairlineStrong}`,
        boxShadow: '0 -12px 40px rgba(0,0,0,0.45)',
        padding: '14px 18px 22px',
      }}>
        {/* Drag handle */}
        <div style={{ width: 38, height: 4, borderRadius: 2, background: SURF.hairlineStrong, margin: '0 auto 14px' }} />
        <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 4 }}>
          <Title size={17}>Log something</Title>
          <div style={{ flex: 1 }} />
          <Meta size={9.5} color={SURF.tx3}>+20 xp</Meta>
        </div>
        <Body size={12} color={SURF.tx3} style={{ marginBottom: 14 }}>Pick what just happened.</Body>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {items.map((x, i) => (
            <Pressable key={i} pressed={i === 0}>
              <div style={{
                padding: '14px 8px', borderRadius: R.md,
                background: i === 0 ? 'rgba(126,224,184,0.12)' : SURF.s2,
                border: `1px solid ${i === 0 ? 'rgba(126,224,184,0.4)' : SURF.hairline}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
              }}>
                <Icon name={x.i} size={20} color={x.c} strokeWidth={1.6} />
                <Title size={12} style={{ marginTop: 2 }}>{x.l}</Title>
                <Meta size={8.5} color={SURF.tx3} style={{ textAlign: 'center', letterSpacing: 0.5 }}>{x.sub}</Meta>
              </div>
            </Pressable>
          ))}
        </div>

        {/* Voice option */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 16, padding: '12px 14px', borderRadius: R.md, border: `1px solid ${SURF.hairline}`, background: SURF.s1 }}>
          <MicFab listening />
          <div style={{ flex: 1 }}>
            <Title size={13}>Or just say it</Title>
            <Body size={11} color={SURF.tx3} style={{ marginTop: 2 }}>"Logged a 35 min run · felt great"</Body>
          </div>
        </div>

        <div style={{ marginTop: 14, display: 'flex', gap: 8 }}>
          <div style={{ flex: 1, padding: '12px 0', textAlign: 'center', borderRadius: R.md, border: `1px solid ${SURF.hairline}`, fontFamily: 'DM Sans', fontWeight: 600, fontSize: 13, color: SURF.tx2 }}>
            Cancel
          </div>
          <div style={{ flex: 2, padding: '12px 0', textAlign: 'center', borderRadius: R.md, background: '#E8E1FF', color: '#1A1028', fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5 }}>
            Continue · Meal
          </div>
        </div>
      </div>
    </ProFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// STATE C — Block completion. Tap-and-hold to complete; checkmark
// drawn live, gentle haptic ring, small xp toast slides in.
// Demonstrates: gesture feedback, microinteractions, haptic moments.
// ─────────────────────────────────────────────────────────────
function CompletionMoment() {
  return (
    <ProFrame time="9:41" sub="State · completion" label="Tap-hold to complete" footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Today's flow</Title>
          </div>
        </div>

        {/* Live block — completing */}
        <div style={{ position: 'relative', padding: '4px 0' }}>
          {/* Soft haptic ring */}
          <div style={{
            position: 'absolute', left: 38, top: 22, width: 60, height: 60, borderRadius: 30,
            border: `1px solid ${DOMAINS.health.hue}44`, transform: 'translate(-50%, -50%)',
            animation: 'lifeos-pulse 2.4s cubic-bezier(0.4,0,0.2,1) infinite',
          }} />
          <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{ width: 18, position: 'relative', flexShrink: 0, paddingTop: 16 }}>
              <div style={{
                width: 11, height: 11, borderRadius: 6,
                background: DOMAINS.health.hue,
                margin: '0 auto',
                boxShadow: `0 0 0 5px ${DOMAINS.health.hue}22`,
              }} />
            </div>
            <div style={{
              flex: 1,
              background: `linear-gradient(180deg, ${DOMAINS.health.hue}14, ${DOMAINS.health.hue}06)`,
              border: `1px solid ${DOMAINS.health.hue}44`,
              borderRadius: R.md,
              padding: '12px 14px',
              transform: 'scale(0.985)',
              transition: 'all 200ms',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Meta size={10} color={SURF.tx3}>07:00</Meta>
                <Title size={14.5} style={{ flex: 1 }}>Strength · push day</Title>
                {/* Live-drawing checkmark */}
                <div style={{ width: 22, height: 22, borderRadius: 11, background: DOMAINS.health.hue, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="14" height="14" viewBox="0 0 14 14">
                    <path d="M3 7 L6 10 L11 4" stroke={SURF.bg} strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round"
                      strokeDasharray="14" strokeDashoffset="2" />
                  </svg>
                </div>
              </div>
              {/* progress arc of long-press */}
              <div style={{ marginTop: 10, height: 2.5, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                <div style={{ width: '85%', height: '100%', background: DOMAINS.health.hue }} />
              </div>
              <Body size={10.5} color={SURF.tx3} style={{ marginTop: 6 }}>Hold to confirm · release to log</Body>
            </div>
          </div>
        </div>

        {/* XP toast */}
        <div style={{
          alignSelf: 'center',
          marginTop: -2,
          padding: '8px 14px', borderRadius: R.pill,
          background: 'rgba(126,224,184,0.14)',
          border: '1px solid rgba(126,224,184,0.36)',
          display: 'flex', alignItems: 'center', gap: 8,
          backdropFilter: 'blur(12px)',
        }}>
          <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
          <Meta color="#7EE0B8">+10 xp · health</Meta>
          <Meta size={9} color={SURF.tx3}>streak 13 →</Meta>
        </div>

        {/* Remainder of timeline, dimmed slightly */}
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: 6, opacity: 0.85 }}>
          <TimelineBlock first time="09:00" title="Deep work · spec" module="goal" />
          <TimelineBlock time="12:30" title="Lunch · 600 kcal" module="health" />
          <TimelineBlock time="14:00" title="Andrew Ng · L4" module="polymath" />
          <TimelineBlock last time="16:00" title="ML mock · system design" module="career" />
        </div>

        {/* Footnote — motion spec */}
        <Surface level={1} padding={12} radius={R.md} style={{ marginTop: 4 }}>
          <Meta color={SURF.tx3} size={9.5}>Motion</Meta>
          <Body size={11.5} color={SURF.tx2} style={{ marginTop: 4, lineHeight: 1.5 }}>
            Long-press 320 ms · spring (180, 24) · soft tick haptic on commit. The block fades to 55%; the XP chip slides up 12 px and dissolves at 1.6 s.
          </Body>
        </Surface>
      </div>
    </ProFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// STATE D — Empty state, day one. Calm, no streaks yet.
// Demonstrates: emotional intelligence, breathing space, intentional asymmetry.
// ─────────────────────────────────────────────────────────────
function EmptyDayOne() {
  return (
    <ProFrame time="9:41" sub="State · day 1" label="Empty / first morning" hero footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 22 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 14 }}>
          <Avatar initials="AR" pct={0} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Mon · Mar 28 · day 1</Meta>
            <Title size={18} style={{ marginTop: 2 }}>Welcome, Arjun</Title>
          </div>
        </div>

        {/* Hero — single gentle paragraph */}
        <div style={{ paddingTop: 18, paddingBottom: 10 }}>
          <Display size={28} style={{ letterSpacing: -0.5, lineHeight: 1.18 }}>
            Nothing to track yet.
          </Display>
          <Body size={14.5} color={SURF.tx2} style={{ marginTop: 14, lineHeight: 1.55, maxWidth: 280 }}>
            We won't ask you to fill in your life. Just pick <span style={{ color: SURF.tx1, fontWeight: 600 }}>one thing</span> you want to be better at. Tomorrow we'll show you a rhythm.
          </Body>
        </div>

        {/* Six gentle domain cards — choose one to begin */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
          {Object.entries(DOMAINS).map(([k, d], i) => (
            <Pressable key={k} pressed={i === 1}>
              <div style={{
                padding: '14px 14px', borderRadius: R.md,
                background: i === 1 ? `${d.hue}14` : SURF.s2,
                border: `1px solid ${i === 1 ? d.hue + '4D' : SURF.hairline}`,
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <div style={{
                  width: 26, height: 26, borderRadius: 13,
                  border: `1px solid ${d.hue}66`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  color: d.hue, fontFamily: 'Nunito', fontWeight: 800, fontSize: 13,
                }}>{d.glyph}</div>
                <div style={{ flex: 1 }}>
                  <Title size={13}>{d.label}</Title>
                  <Meta size={9} color={SURF.tx3} style={{ marginTop: 2 }}>start here</Meta>
                </div>
              </div>
            </Pressable>
          ))}
        </div>

        {/* Reassurance — Headspace-style ground line */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', borderRadius: R.md, border: `1px solid ${SURF.hairline}`, background: SURF.s1, marginTop: 6 }}>
          <Icon name="leaf" size={16} color="#7EE0B8" strokeWidth={1.5} />
          <Body size={11.5} color={SURF.tx2} style={{ flex: 1, lineHeight: 1.45 }}>
            Pick anything. You can move it tomorrow. Streaks start when you say so.
          </Body>
        </div>
      </div>
    </ProFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// STATE E — Loading. Skeletons, single shimmer pace, no spinner.
// Demonstrates: production-believable loading, calm motion.
// ─────────────────────────────────────────────────────────────
function LoadingState() {
  return (
    <ProFrame time="9:41" sub="State · loading" label="Skeleton" hero footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 18 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Skel w={42} h={42} r={21} />
          <div style={{ flex: 1 }}>
            <Skel w={80} h={9} r={4} />
            <Skel w={160} h={18} r={6} style={{ marginTop: 6 }} />
          </div>
          <Skel w={40} h={40} r={20} />
        </div>

        {/* Headline skeleton */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 4 }}>
          <Skel w="78%" h={22} r={8} />
          <Skel w="60%" h={22} r={8} />
        </div>

        {/* Radar surface skeleton */}
        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Skel w={120} h={120} r={60} />
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Skel w={60} h={9} r={3} />
              <Skel w={80} h={28} r={8} />
              <Skel w="100%" h={6} r={3} style={{ marginTop: 6 }} />
              <Skel w="80%" h={6} r={3} />
              <Skel w="60%" h={6} r={3} />
            </div>
          </div>
        </Surface>

        <Skel w={120} h={15} r={6} />

        {/* Timeline skeletons */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[0,1,2,3,4].map(i => (
            <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <Skel w={11} h={11} r={6} />
              <Skel w={42} h={10} r={4} />
              <Skel w={`${[60, 75, 50, 70, 65][i]}%`} h={14} r={6} />
            </div>
          ))}
        </div>

        {/* Footnote */}
        <div style={{ marginTop: 10, padding: '10px 14px', borderRadius: R.md, border: `1px solid ${SURF.hairline}`, background: SURF.s1 }}>
          <Meta size={9.5} color={SURF.tx3}>Motion</Meta>
          <Body size={11.5} color={SURF.tx2} style={{ marginTop: 4, lineHeight: 1.5 }}>
            One global shimmer · 1.8 s ease · staggered 60 ms per row. No spinners. Content fades in piece by piece.
          </Body>
        </div>
      </div>
    </ProFrame>
  );
}

Object.assign(window, { TodayScrolled, QuickLogSheet, CompletionMoment, EmptyDayOne, LoadingState });
