// Finance — refined. Calm summary, restrained arc, typographic transactions.
const { ProFrame, Surface, Display, Title, Body, Meta, TabBar, Icon, Pressable, SURF, R, DOMAINS } = window;

function FinanceScreen() {
  const goal = 1500000, saved = 412000;
  const pct = saved / goal;

  // Stacked bar buckets
  const buckets = [
    { l: 'Rent',   pct: 52, c: '#FF99C5' },
    { l: 'Food',   pct: 20, c: '#C9A0FF' },
    { l: 'Travel', pct: 15, c: '#7FB8FF' },
    { l: 'Misc',   pct: 13, c: '#F4C16A' },
  ];

  return (
    <ProFrame time="9:41" sub="04 · money" label="Finance" footer={<div style={{ paddingBottom: 12 }}><TabBar active="goals" /></div>}>
      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {/* Header */}
        <div style={{ marginTop: 8 }}>
          <Meta color="#F4C16A">Money</Meta>
          <Display size={26} style={{ marginTop: 4 }}>May at a glance</Display>
          <Body size={12.5} color={SURF.tx2} style={{ marginTop: 4 }}>13 days in · trending under budget</Body>
        </div>

        {/* In / Out / Saved — one calm row, hairlines, no rainbow */}
        <Surface level={1} padding={18} radius={R.lg}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr' }}>
            {[
              { l: 'Earned',  v: '₹1,42,000', tone: SURF.tx1 },
              { l: 'Spent',   v: '₹1,03,600', tone: SURF.tx1 },
              { l: 'Saved',   v: '₹38,400',   tone: '#7EE0B8', emphasis: true },
            ].map((s, i) => (
              <div key={i} style={{
                borderLeft: i ? `1px solid ${SURF.hairline}` : 'none',
                paddingLeft: i ? 14 : 0,
              }}>
                <Meta size={9.5}>{s.l}</Meta>
                <div style={{
                  fontFamily: 'Nunito', fontWeight: s.emphasis ? 800 : 700, fontSize: 17,
                  color: s.tone, marginTop: 4, letterSpacing: -0.2,
                }}>{s.v}</div>
              </div>
            ))}
          </div>
          {/* Stacked bar */}
          <div style={{ marginTop: 16, display: 'flex', height: 6, borderRadius: 3, overflow: 'hidden', background: SURF.hairline }}>
            {buckets.map((b, i) => (
              <div key={i} style={{ width: `${b.pct}%`, background: b.c, opacity: 0.85 }} />
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 10 }}>
            {buckets.map((b, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <div style={{ width: 5, height: 5, borderRadius: 3, background: b.c }} />
                <Body size={11} color={SURF.tx2} style={{ fontFamily: 'DM Sans' }}>{b.l}</Body>
                <Meta size={9.5} color={SURF.tx3}>{b.pct}%</Meta>
              </div>
            ))}
          </div>
        </Surface>

        {/* Down payment — restrained arc, milestone pins, no glow */}
        <Surface level={2} padding={16} radius={R.lg} accent="#F4C16A">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Meta color="#F4C16A">Down payment · Mumbai</Meta>
            <div style={{ flex: 1 }} />
            <Meta size={9.5} color={SURF.tx3}>eta apr 2028</Meta>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <Display size={28}>₹4.12<span style={{ fontSize: 14, color: SURF.tx3, fontWeight: 700 }}>L</span></Display>
            <Body size={12.5} color={SURF.tx3}>of ₹15L</Body>
            <div style={{ flex: 1 }} />
            <span style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 14, color: '#F4C16A' }}>{Math.round(pct * 100)}%</span>
          </div>
          {/* Linear progress with milestone ticks (calmer than the arc) */}
          <div style={{ marginTop: 14, position: 'relative' }}>
            <div style={{ height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
              <div style={{ width: `${pct * 100}%`, height: '100%', background: '#F4C16A' }} />
            </div>
            {[0.25, 0.5, 0.75].map(p => (
              <div key={p} style={{
                position: 'absolute', left: `${p * 100}%`, top: -3, transform: 'translateX(-50%)',
                width: 2, height: 10, borderRadius: 1,
                background: pct >= p ? '#FFD66B' : SURF.hairlineStrong,
              }} />
            ))}
            <div style={{ position: 'absolute', left: `${pct * 100}%`, top: -4, transform: 'translateX(-50%)', width: 12, height: 12, borderRadius: 6, background: '#FFD66B', border: `2.5px solid ${SURF.bg}` }} />
          </div>
          <Body size={12} color={SURF.tx2} style={{ marginTop: 14, lineHeight: 1.5 }}>
            At ₹38,400/mo you arrive <span style={{ color: '#7EE0B8', fontWeight: 600 }}>4 months early</span>. Bump SIP to ₹45k to land Jan 2028.
          </Body>
        </Surface>

        {/* AI insight — single restrained card */}
        <Surface level={2} padding={16} radius={R.lg} accent="#C9A0FF">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Icon name="sparkle" size={12} color="#C5B3FF" strokeWidth={1.6} />
            <Meta color="#C5B3FF">This week's spend</Meta>
          </div>
          <Body size={13.5} color={SURF.tx1} style={{ lineHeight: 1.5 }}>
            <span style={{ color: '#FF99C5', fontWeight: 600 }}>Food delivery up 38%</span> — 11 Swiggy orders. Try cooking 3× this week to claw back about ₹2,800.
          </Body>
          {/* mini bars */}
          <div style={{ display: 'flex', gap: 6, alignItems: 'flex-end', height: 44, marginTop: 14 }}>
            {[12, 8, 22, 18, 28, 14, 10].map((v, i) => (
              <div key={i} style={{ flex: 1, height: `${(v / 28) * 100}%`, borderRadius: 3, background: i === 4 ? '#FF99C5' : 'rgba(255,153,197,0.28)' }} />
            ))}
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
            {['M','T','W','T','F','S','S'].map((l, i) => (
              <Meta key={i} size={9} color={i === 4 ? '#FF99C5' : SURF.tx4} style={{ flex: 1, textAlign: 'center', letterSpacing: 0.6 }}>{l}</Meta>
            ))}
          </div>
        </Surface>

        {/* Transactions — typographic list, source pill on the right */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 10 }}>
            <Title size={15}>Recent</Title>
            <div style={{ flex: 1 }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: R.pill, border: '1px solid rgba(126,224,184,0.24)', background: 'rgba(126,224,184,0.06)' }}>
              <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
              <Meta size={9} color="#7EE0B8">Gmail live</Meta>
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {[
              { merchant: 'Swiggy',         cat: 'Food',      when: '1:42 PM',  amt: 412,    dir: 'out', bank: 'HDFC',  hue: '#C9A0FF' },
              { merchant: 'BookMyShow',     cat: 'Leisure',   when: '11:08 AM', amt: 480,    dir: 'out', bank: 'ICICI', hue: '#FF99C5' },
              { merchant: 'Salary · Vearc', cat: 'Income',    when: 'Yesterday',amt: 142000, dir: 'in',  bank: 'HDFC',  hue: '#7EE0B8' },
              { merchant: 'Uber',           cat: 'Travel',    when: 'Mon',      amt: 218,    dir: 'out', bank: 'AXIS',  hue: '#7FB8FF' },
              { merchant: 'BigBasket',      cat: 'Groceries', when: 'Sat',      amt: 1840,   dir: 'out', bank: 'HDFC',  hue: '#F4C16A' },
            ].map((t, i) => (
              <div key={i} style={{
                display: 'flex', alignItems: 'center', gap: 12,
                padding: '14px 4px',
                borderTop: i === 0 ? `1px solid ${SURF.hairline}` : 'none',
                borderBottom: `1px solid ${SURF.hairline}`,
              }}>
                <div style={{
                  width: 6, height: 6, borderRadius: 3, background: t.hue, flexShrink: 0,
                }} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <Title size={13.5} style={{ fontWeight: 700, letterSpacing: -0.05 }}>{t.merchant}</Title>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
                    <Meta size={9} color={SURF.tx3} style={{ letterSpacing: 0.6 }}>{t.cat}</Meta>
                    <div style={{ width: 2, height: 2, borderRadius: 1, background: SURF.tx4 }} />
                    <Meta size={9} color={SURF.tx3} style={{ letterSpacing: 0.6 }}>{t.when}</Meta>
                    <div style={{ width: 2, height: 2, borderRadius: 1, background: SURF.tx4 }} />
                    <Meta size={9} color={SURF.tx3} style={{ letterSpacing: 0.6 }}>{t.bank}</Meta>
                  </div>
                </div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 14, color: t.dir === 'in' ? '#7EE0B8' : SURF.tx1, letterSpacing: -0.1 }}>
                  {t.dir === 'in' ? '+' : '−'}₹{t.amt.toLocaleString('en-IN')}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ProFrame>
  );
}

window.FinanceScreen = FinanceScreen;
