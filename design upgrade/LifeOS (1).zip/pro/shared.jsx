// LifeOS · Aurora Refined v2 — shared primitives
// Refined toward Apple Fitness / Headspace / Linear sensibility while preserving DNA.
//
// Philosophy:
//  · color is data, not decoration — chips/cards lean neutral; hue marks meaning
//  · single elevation system (s1..s4), single radius scale, single grid (4/8/12)
//  · no neon glow on type; subtle aurora reserved for the Today hero only
//  · touch + focus states baked into every interactive primitive
//  · type: Nunito for display, DM Sans for body, JetBrains Mono sparingly for meta

const DOMAINS = {
  goal:     { hue: '#C9A0FF', label: 'Goals',   glyph: '◆', mark: 'G' },
  health:   { hue: '#7EE0B8', label: 'Health',  glyph: '♥', mark: 'H' },
  finance:  { hue: '#F4C16A', label: 'Money',   glyph: '◈', mark: 'M' },
  career:   { hue: '#7FB8FF', label: 'Career',  glyph: '▲', mark: 'C' },
  social:   { hue: '#FF99C5', label: 'Social',  glyph: '●', mark: 'S' },
  polymath: { hue: '#FFD66B', label: 'Mind',    glyph: '✦', mark: 'P' },
};

// Surface tokens (dark — primary mode)
const SURF = {
  bg:        '#0B0712',       // base canvas
  bgSoft:    '#100A1B',       // slightly lifted band (collapsed header, footer)
  s1:        'rgba(255,255,255,0.025)', // subtle pane
  s2:        'rgba(255,255,255,0.045)', // resting card
  s3:        'rgba(255,255,255,0.07)',  // pressed / hovered
  s4:        'rgba(20,12,32,0.92)',     // floating sheet
  hairline:  'rgba(255,255,255,0.07)',
  hairlineStrong: 'rgba(255,255,255,0.12)',
  tx1:       '#F4EFFF',
  tx2:       'rgba(244,239,255,0.66)',
  tx3:       'rgba(244,239,255,0.42)',
  tx4:       'rgba(244,239,255,0.28)',
};

// Radii — disciplined scale
const R = { xs: 8, sm: 12, md: 16, lg: 20, xl: 28, pill: 999 };

// ─────────────────────────────────────────────────────────────
// ProFrame — iOS-shaped phone, restrained Aurora at top only
// ─────────────────────────────────────────────────────────────
function ProFrame({ children, time = '9:41', label, sub, hero = false, scrollHint = false, footer }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 10 }}>
      {label && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginLeft: 4 }}>
          <div style={{ fontSize: 10.5, letterSpacing: 1.6, fontFamily: 'JetBrains Mono, ui-monospace, monospace', color: 'rgba(60,50,40,0.5)', textTransform: 'uppercase' }}>{sub}</div>
          <div style={{ fontSize: 16, fontFamily: 'Nunito, system-ui', fontWeight: 800, color: 'rgba(40,30,20,0.85)', letterSpacing: -0.2 }}>{label}</div>
        </div>
      )}
      <div style={{
        width: 390,
        background: SURF.bg,
        borderRadius: 54,
        padding: 9,
        // restrained device-level shadow + bezel
        boxShadow:
          '0 1px 0 0 rgba(255,255,255,0.06) inset, ' +
          '0 0 0 1px rgba(255,255,255,0.04), ' +
          '0 24px 60px rgba(8, 4, 18, 0.45), ' +
          '0 6px 18px rgba(8, 4, 18, 0.35)',
        border: '1px solid rgba(60, 50, 90, 0.28)',
        position: 'relative',
      }}>
        <div style={{
          position: 'relative',
          background: SURF.bg,
          borderRadius: 46,
          overflow: 'hidden',
          minHeight: 200,
        }}>
          {/* Restrained aurora — only when hero requested */}
          {hero && <ProAuroraTop />}
          {/* Status bar */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '14px 28px 6px', position: 'relative', zIndex: 5,
            fontFamily: '-apple-system, "SF Pro Display", system-ui', fontWeight: 600,
            fontSize: 15, color: SURF.tx1,
          }}>
            <span>{time}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width="17" height="11" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7" fill={SURF.tx1}/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7" fill={SURF.tx1}/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7" fill={SURF.tx1}/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7" fill={SURF.tx1}/></svg>
              <svg width="14" height="11" viewBox="0 0 17 12"><path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z" fill={SURF.tx1}/><path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z" fill={SURF.tx1}/><circle cx="8.5" cy="10.5" r="1.5" fill={SURF.tx1}/></svg>
              <svg width="24" height="11" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke={SURF.tx1} strokeOpacity="0.35" fill="none"/><rect x="2" y="2" width="20" height="9" rx="2" fill={SURF.tx1}/><path d="M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z" fill={SURF.tx1} fillOpacity="0.4"/></svg>
            </div>
          </div>
          {/* Notch */}
          <div style={{
            position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)',
            width: 122, height: 33, background: '#000', borderRadius: 22, zIndex: 6,
          }} />
          {/* Body */}
          <div style={{ position: 'relative', zIndex: 4, paddingBottom: 28, color: SURF.tx1 }}>
            {children}
          </div>
          {/* Footer overlay (e.g. tab bar) — passed as prop so it stays anchored */}
          {footer && (
            <div style={{ position: 'sticky', bottom: 0, zIndex: 6 }}>
              {footer}
            </div>
          )}
          {/* Home indicator */}
          <div style={{
            position: 'absolute', bottom: 7, left: '50%', transform: 'translateX(-50%)',
            width: 134, height: 5, borderRadius: 3,
            background: 'rgba(244,239,255,0.5)',
            zIndex: 7,
          }} />
        </div>
      </div>
    </div>
  );
}

function ProAuroraTop() {
  // Single, top-anchored, very low-intensity aurora wash.
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 1 }}>
      <div style={{
        position: 'absolute', top: -180, left: -80, width: 360, height: 360, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(165,132,255,0.22), rgba(165,132,255,0) 70%)',
        filter: 'blur(28px)',
      }} />
      <div style={{
        position: 'absolute', top: -120, right: -120, width: 320, height: 320, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(126,224,184,0.10), rgba(126,224,184,0) 70%)',
        filter: 'blur(36px)',
      }} />
      {/* fade-out band so aurora doesn't pollute body */}
      <div style={{
        position: 'absolute', top: 360, left: 0, right: 0, height: 120,
        background: `linear-gradient(180deg, rgba(11,7,18,0), ${SURF.bg})`,
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Surface — replaces GlassCard. Three elevation tiers, optional thread.
// ─────────────────────────────────────────────────────────────
function Surface({ children, level = 2, style = {}, padding = 16, radius = R.md, accent, pressed = false, onClick }) {
  const bg = level === 1 ? SURF.s1 : level === 2 ? SURF.s2 : level === 3 ? SURF.s3 : SURF.s4;
  return (
    <div onClick={onClick} style={{
      background: pressed ? SURF.s3 : bg,
      border: `1px solid ${SURF.hairline}`,
      borderRadius: radius,
      padding,
      position: 'relative',
      ...(accent ? { borderLeft: `2px solid ${accent}` } : {}),
      transition: 'transform 220ms cubic-bezier(0.2,0.7,0.2,1), background 180ms',
      transform: pressed ? 'scale(0.985)' : 'scale(1)',
      ...style,
    }}>
      {children}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Type — small components instead of repeating inline styles
// ─────────────────────────────────────────────────────────────
function Display({ children, size = 28, color = SURF.tx1, style = {} }) {
  return <div style={{ fontFamily: 'Nunito, system-ui', fontWeight: 900, fontSize: size, color, lineHeight: 1.04, letterSpacing: -0.4, ...style }}>{children}</div>;
}
function Title({ children, size = 17, color = SURF.tx1, style = {} }) {
  return <div style={{ fontFamily: 'Nunito, system-ui', fontWeight: 800, fontSize: size, color, lineHeight: 1.2, letterSpacing: -0.1, ...style }}>{children}</div>;
}
function Body({ children, size = 14, color = SURF.tx2, style = {} }) {
  return <div style={{ fontFamily: 'DM Sans, system-ui', fontWeight: 400, fontSize: size, color, lineHeight: 1.5, ...style }}>{children}</div>;
}
function Meta({ children, size = 10.5, color = SURF.tx3, style = {} }) {
  return <div style={{ fontFamily: 'JetBrains Mono, ui-monospace, monospace', fontWeight: 500, fontSize: size, color, letterSpacing: 1.2, textTransform: 'uppercase', ...style }}>{children}</div>;
}

// ─────────────────────────────────────────────────────────────
// Hex Radar — refined: thinner stroke, single muted fill, smaller dots, no halo
// ─────────────────────────────────────────────────────────────
function HexRadar({ scores, size = 240, showLabels = true }) {
  const cx = size / 2, cy = size / 2;
  const r = size * 0.36;
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  const angles = keys.map((_, i) => -Math.PI / 2 + (i * Math.PI / 3));
  const point = (i, scale) => [cx + Math.cos(angles[i]) * r * scale, cy + Math.sin(angles[i]) * r * scale];

  const polyPoints = keys.map((k, i) => {
    const [x, y] = point(i, (scores[k] ?? 0) / 100);
    return `${x},${y}`;
  }).join(' ');

  const labels = keys.map((k, i) => {
    const lr = r + 22;
    return { k, x: cx + Math.cos(angles[i]) * lr, y: cy + Math.sin(angles[i]) * lr, ...DOMAINS[k], score: scores[k] };
  });

  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <linearGradient id="hex-fill-refined" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#A584FF" stopOpacity="0.28" />
            <stop offset="1" stopColor="#7EE0B8" stopOpacity="0.22" />
          </linearGradient>
        </defs>
        {[0.33, 0.66, 1].map((s, gi) => {
          const pts = keys.map((_, i) => {
            const [x, y] = point(i, s);
            return `${x},${y}`;
          }).join(' ');
          return <polygon key={gi} points={pts} fill="none" stroke="rgba(244,239,255,0.07)" strokeWidth="1" />;
        })}
        {keys.map((_, i) => {
          const [x2, y2] = point(i, 1);
          return <line key={i} x1={cx} y1={cy} x2={x2} y2={y2} stroke="rgba(244,239,255,0.05)" strokeWidth="1" />;
        })}
        <polygon points={polyPoints} fill="url(#hex-fill-refined)" stroke="rgba(197,179,255,0.7)" strokeWidth="1.25" strokeLinejoin="round" />
        {keys.map((k, i) => {
          const [x, y] = point(i, (scores[k] ?? 0) / 100);
          return <circle key={k} cx={x} cy={y} r="3" fill={DOMAINS[k].hue} />;
        })}
      </svg>
      {showLabels && labels.map(l => (
        <div key={l.k} style={{
          position: 'absolute', left: l.x, top: l.y, transform: 'translate(-50%, -50%)',
          textAlign: 'center', pointerEvents: 'none',
        }}>
          <div style={{ fontSize: 9, letterSpacing: 1.4, color: SURF.tx3, fontFamily: 'JetBrains Mono, monospace', textTransform: 'uppercase' }}>{l.label}</div>
          <div style={{ fontSize: 13, fontWeight: 800, color: SURF.tx1, fontFamily: 'Nunito', marginTop: 1 }}>{l.score}</div>
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Avatar Ring — refined: no level chip glow, softer
// ─────────────────────────────────────────────────────────────
function Avatar({ initials = 'AR', pct = 0.4, size = 48, color = '#A584FF', showLevel, level }) {
  const r = size / 2 - 3;
  const c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} stroke="rgba(255,255,255,0.08)" strokeWidth="2.5" fill="none" />
        <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth="2.5" fill="none"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round" />
      </svg>
      <div style={{
        position: 'absolute', inset: 3, borderRadius: '50%',
        background: 'linear-gradient(140deg, #1A1028, #2A1E4A)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Nunito', fontWeight: 900, color: '#F4EFFF', fontSize: size * 0.34, letterSpacing: -0.5,
      }}>{initials}</div>
      {showLevel && (
        <div style={{
          position: 'absolute', bottom: -2, right: -2,
          background: '#0B0712', color: '#FFD66B',
          fontFamily: 'JetBrains Mono, monospace', fontWeight: 700, fontSize: 9,
          borderRadius: 999, padding: '2px 5px', minWidth: 16, textAlign: 'center',
          border: `1.5px solid #FFD66B`, lineHeight: 1,
        }}>L{level}</div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// XP Bar — flat, no glow, hairline tick at next milestone
// ─────────────────────────────────────────────────────────────
function XpBar({ pct = 0.4, height = 5, color = '#A584FF' }) {
  return (
    <div style={{ position: 'relative', height, borderRadius: height, background: 'rgba(255,255,255,0.07)', overflow: 'hidden' }}>
      <div style={{
        width: `${pct * 100}%`, height: '100%',
        background: color,
        borderRadius: height,
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TimelineBlock — refined RoutineBlock with vertical thread
// ─────────────────────────────────────────────────────────────
function TimelineBlock({ time, title, sub, module: mod, status = 'pending', live = false, first = false, last = false, pressed = false }) {
  const hue = DOMAINS[mod]?.hue ?? '#A584FF';
  const done = status === 'completed';
  return (
    <div style={{ display: 'flex', gap: 14, position: 'relative', paddingLeft: 2 }}>
      {/* Thread + dot */}
      <div style={{ width: 18, position: 'relative', flexShrink: 0 }}>
        {!first && <div style={{ position: 'absolute', left: 8, top: 0, width: 1, height: 16, background: SURF.hairline }} />}
        {!last  && <div style={{ position: 'absolute', left: 8, top: 22, bottom: -10, width: 1, background: SURF.hairline }} />}
        <div style={{
          position: 'absolute', left: 3, top: 16, width: 11, height: 11, borderRadius: 6,
          background: done ? hue : (live ? hue : SURF.bg),
          border: `1.5px solid ${done || live ? hue : SURF.hairlineStrong}`,
          ...(live ? { boxShadow: `0 0 0 4px ${hue}22` } : {}),
        }} />
      </div>
      {/* Block */}
      <div style={{
        flex: 1,
        background: live ? `${hue}0E` : (pressed ? SURF.s3 : SURF.s2),
        border: `1px solid ${live ? hue + '38' : SURF.hairline}`,
        borderRadius: R.md,
        padding: '12px 14px',
        opacity: done ? 0.55 : 1,
        transition: 'background 160ms, transform 200ms cubic-bezier(0.2,0.7,0.2,1)',
        transform: pressed ? 'scale(0.99)' : 'scale(1)',
        marginBottom: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: SURF.tx3, letterSpacing: 0.8,
            minWidth: 50,
          }}>{time}</div>
          <div style={{ flex: 1, fontFamily: 'Nunito', fontWeight: 700, fontSize: 14.5, color: SURF.tx1, textDecoration: done ? 'line-through' : 'none', textDecorationColor: SURF.tx3, letterSpacing: -0.1 }}>{title}</div>
          {live && <Meta size={9} color={hue} style={{ letterSpacing: 1.2 }}>NOW</Meta>}
          {done && (
            <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 7 L6 10 L11 4" stroke={hue} strokeWidth="2.2" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
          )}
        </div>
        {sub && <Body size={12} color={SURF.tx3} style={{ marginTop: 4, marginLeft: 60 }}>{sub}</Body>}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// TabBar — refined: minimal, single accent dot under active icon
// ─────────────────────────────────────────────────────────────
function TabBar({ active = 'today' }) {
  const tabs = [
    { k: 'today',   label: 'Today',   icon: 'M12 3 L21 12 L18 12 L18 20 L14 20 L14 14 L10 14 L10 20 L6 20 L6 12 L3 12 Z' },
    { k: 'goals',   label: 'Goals',   icon: 'M12 3 L4 12 L12 21 L20 12 Z' },
    { k: 'rewards', label: 'Rewards', icon: 'M12 2 L15 8.5 L22 9.5 L17 14.5 L18.5 22 L12 18.5 L5.5 22 L7 14.5 L2 9.5 L9 8.5 Z' },
    { k: 'explore', label: 'Explore', icon: 'M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z' },
    { k: 'profile', label: 'Me',      icon: 'M12 12 m -5 0 a 5 5 0 1 0 10 0 a 5 5 0 1 0 -10 0 M3 22 C3 17 7 14 12 14 C17 14 21 17 21 22 Z' },
  ];
  return (
    <div style={{
      margin: '0 14px 0',
      padding: '8px 6px',
      borderRadius: 24,
      background: 'rgba(16,10,26,0.78)',
      backdropFilter: 'blur(28px) saturate(140%)',
      WebkitBackdropFilter: 'blur(28px) saturate(140%)',
      border: `1px solid ${SURF.hairline}`,
      display: 'flex', justifyContent: 'space-around', alignItems: 'center',
      boxShadow: '0 8px 24px rgba(0,0,0,0.4)',
    }}>
      {tabs.map(t => {
        const on = t.k === active;
        const c = on ? SURF.tx1 : SURF.tx3;
        return (
          <div key={t.k} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, padding: '6px 8px', position: 'relative' }}>
            <svg width="22" height="22" viewBox="0 0 24 24"><path d={t.icon} fill={c} /></svg>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontWeight: 600, fontSize: 9.5, color: c, letterSpacing: 0.2 }}>{t.label}</div>
            {on && <div style={{ position: 'absolute', bottom: -2, left: '50%', transform: 'translateX(-50%)', width: 4, height: 4, borderRadius: 4, background: '#A584FF' }} />}
          </div>
        );
      })}
    </div>
  );
}

// Ring — multi-segment concentric (calorie style)
function Ring({ size = 220, stroke = 12, gap = 5, segments, center }) {
  const r0 = size / 2 - stroke / 2 - 2;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {segments.map((s, i) => {
          const rr = r0 - i * (stroke + gap);
          if (rr < 12) return null;
          const c = 2 * Math.PI * rr;
          const pct = Math.min(1, s.value / s.max);
          return (
            <g key={i}>
              <circle cx={size/2} cy={size/2} r={rr} stroke="rgba(255,255,255,0.05)" strokeWidth={stroke} fill="none" />
              <circle cx={size/2} cy={size/2} r={rr} stroke={s.color} strokeWidth={stroke} fill="none"
                strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round" />
            </g>
          );
        })}
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
        {center}
      </div>
    </div>
  );
}

// Sparkline — refined: thinner, no end-dot glow
function Sparkline({ data, color = '#A584FF', width = 280, height = 44, fill = true, lastDot = true }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 8) - 4;
    return [x, y];
  });
  const path = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'} ${x} ${y}`).join(' ');
  const area = `${path} L ${width} ${height} L 0 ${height} Z`;
  const id = `sp-${color.replace('#','')}`;
  return (
    <svg width={width} height={height}>
      {fill && (
        <>
          <defs>
            <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.22" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} fill={`url(#${id})`} />
        </>
      )}
      <path d={path} stroke={color} strokeWidth="1.75" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {lastDot && (() => {
        const [x, y] = points[points.length - 1];
        return <circle cx={x} cy={y} r="3" fill={color} stroke={SURF.bg} strokeWidth="1.5" />;
      })()}
    </svg>
  );
}

// Tiny inline icons used across screens
function Icon({ name, size = 16, color = 'currentColor', strokeWidth = 1.6 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', stroke: color, strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
  switch (name) {
    case 'mic':       return <svg {...common}><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3M8 21h8"/></svg>;
    case 'plus':      return <svg {...common}><path d="M12 5v14M5 12h14"/></svg>;
    case 'chevron':   return <svg {...common}><path d="M9 6l6 6-6 6"/></svg>;
    case 'sparkle':   return <svg {...common}><path d="M12 3l1.5 5L18 9.5l-4.5 1.5L12 16l-1.5-5L6 9.5 10.5 8z"/></svg>;
    case 'camera':    return <svg {...common}><rect x="3" y="7" width="18" height="13" rx="2.5"/><circle cx="12" cy="13" r="3.5"/><path d="M8 7l1.5-3h5L16 7"/></svg>;
    case 'flame':     return <svg {...common}><path d="M12 3c0 4-4 5-4 9a4 4 0 008 0c0-3-2-4-2-7-1 1-2 0-2-2z"/></svg>;
    case 'search':    return <svg {...common}><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.5-4.5"/></svg>;
    case 'check':     return <svg {...common}><path d="M5 12l4 4 10-10"/></svg>;
    case 'circle':    return <svg {...common}><circle cx="12" cy="12" r="9"/></svg>;
    case 'arrowUp':   return <svg {...common}><path d="M12 19V5M5 12l7-7 7 7"/></svg>;
    case 'arrowDown': return <svg {...common}><path d="M12 5v14M5 12l7 7 7-7"/></svg>;
    case 'bolt':      return <svg {...common}><path d="M13 3L4 14h7l-1 7 9-11h-7z"/></svg>;
    case 'play':      return <svg {...common}><path d="M7 5l12 7-12 7z" fill={color}/></svg>;
    case 'pause':     return <svg {...common}><rect x="6" y="5" width="4" height="14"/><rect x="14" y="5" width="4" height="14"/></svg>;
    case 'more':      return <svg {...common}><circle cx="6" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="18" cy="12" r="1"/></svg>;
    case 'leaf':      return <svg {...common}><path d="M5 20c0-9 7-15 16-15-1 9-7 15-16 15zM5 20l7-7"/></svg>;
    case 'moon':      return <svg {...common}><path d="M21 13a9 9 0 11-10-10 7 7 0 0010 10z"/></svg>;
    case 'sun':       return <svg {...common}><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2M5.6 5.6l1.4 1.4M17 17l1.4 1.4M5.6 18.4L7 17M17 7l1.4-1.4"/></svg>;
    case 'bell':      return <svg {...common}><path d="M6 8a6 6 0 0112 0c0 7 3 9 3 9H3s3-2 3-9zM10 21a2 2 0 004 0"/></svg>;
    default: return null;
  }
}

// Pressable wrapper — single source of tactile press feedback
function Pressable({ children, pressed = false, onClick, style = {}, radius = R.md }) {
  return (
    <div onClick={onClick} style={{
      cursor: 'pointer',
      borderRadius: radius,
      transform: pressed ? 'scale(0.97)' : 'scale(1)',
      transition: 'transform 220ms cubic-bezier(0.2,0.7,0.2,1)',
      ...style,
    }}>
      {children}
    </div>
  );
}

// FAB (microphone)
function MicFab({ size = 44, listening = false }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: size/2,
      background: listening ? 'rgba(165,132,255,0.18)' : SURF.s2,
      border: `1px solid ${listening ? 'rgba(165,132,255,0.5)' : SURF.hairline}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      position: 'relative',
    }}>
      {listening && (
        <div style={{
          position: 'absolute', inset: -6, borderRadius: '50%',
          border: '1px solid rgba(165,132,255,0.4)',
          animation: 'lifeos-pulse 2.4s cubic-bezier(0.4,0,0.2,1) infinite',
        }} />
      )}
      <Icon name="mic" size={18} color={listening ? '#C5B3FF' : SURF.tx2} strokeWidth={1.8} />
    </div>
  );
}

// Global stylesheet for keyframes + focus rings — injected once
function GlobalStyles() {
  React.useEffect(() => {
    if (document.getElementById('lifeos-pro-css')) return;
    const s = document.createElement('style');
    s.id = 'lifeos-pro-css';
    s.textContent = `
      @keyframes lifeos-pulse {
        0%   { transform: scale(1);   opacity: 0.7; }
        70%  { transform: scale(1.6); opacity: 0;   }
        100% { transform: scale(1.6); opacity: 0;   }
      }
      @keyframes lifeos-shimmer {
        0%   { background-position: -240px 0; }
        100% { background-position: 240px 0; }
      }
      @keyframes lifeos-breathe {
        0%,100% { transform: scale(1);   opacity: 0.85; }
        50%     { transform: scale(1.04); opacity: 1; }
      }
      .lifeos-skeleton {
        background: linear-gradient(90deg, rgba(255,255,255,0.03) 0%, rgba(255,255,255,0.08) 50%, rgba(255,255,255,0.03) 100%);
        background-size: 480px 100%;
        animation: lifeos-shimmer 1.8s linear infinite;
      }
    `;
    document.head.appendChild(s);
  }, []);
  return null;
}

// Skeleton block — for loading state demo
function Skel({ w = '100%', h = 14, r = 6, style = {} }) {
  return <div className="lifeos-skeleton" style={{ width: w, height: h, borderRadius: r, ...style }} />;
}

Object.assign(window, {
  DOMAINS, SURF, R,
  ProFrame, ProAuroraTop, Surface, GlobalStyles, Skel,
  Display, Title, Body, Meta,
  HexRadar, Avatar, XpBar, TimelineBlock, TabBar, Ring, Sparkline, Icon, Pressable, MicFab,
});
