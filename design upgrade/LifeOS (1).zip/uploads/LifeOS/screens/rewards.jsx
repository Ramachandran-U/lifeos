// Rewards screen — XP/level + streaks grid + badges + quests
// Dial UP gamification: bigger, brighter, more celebration energy
const { Frame, GlassCard, SectionLabel, AvatarRing, XpBar, StreakFlame, TabBar, DOMAINS, Glyph } = window;

function RewardsScreen({ theme = 'dark', density = 'cozy' }) {
  const isDark = theme !== 'light';
  const tx = isDark ? '#F4EFFF' : '#140828';
  const tx2 = isDark ? 'rgba(244,239,255,0.62)' : 'rgba(20,8,40,0.62)';
  const tx3 = isDark ? 'rgba(244,239,255,0.4)' : 'rgba(20,8,40,0.4)';

  const pad = density === 'compact' ? 16 : density === 'spacious' ? 26 : 20;
  const gap = density === 'compact' ? 12 : density === 'spacious' ? 18 : 14;

  const streaks = [
    { k: 'workout',  l: 'Workout',  c: 12, hue: '#7EE0B8' },
    { k: 'learn',    l: 'Learn',    c: 47, hue: '#7FB8FF', best: true },
    { k: 'food',     l: 'Food',     c: 3,  hue: '#C9A0FF' },
    { k: 'journal',  l: 'Journal',  c: 0,  hue: '#FFD66B', dim: true },
    { k: 'social',   l: 'Social',   c: 0,  hue: '#FF99C5', dim: true },
  ];
  const badges = [
    { k: 'first_blueprint', l: 'First Blueprint', glyph: '◆', earned: true, hue: '#C9A0FF' },
    { k: 'food_photo',      l: 'Photo Logger',    glyph: '♥', earned: true, hue: '#7EE0B8' },
    { k: 'streak_30',       l: '30-Day Flame',    glyph: '▲', earned: true, hue: '#FF8C3C' },
    { k: 'first_blood',     l: 'Body Reader',     glyph: '♥', earned: true, hue: '#FF99C5' },
    { k: 'week_1',          l: 'Week One',        glyph: '●', earned: true, hue: '#7FB8FF' },
    { k: 'skill_mastery',   l: 'Mastered Skill',  glyph: '▲', earned: false, hue: '#A584FF' },
    { k: 'life_balance',    l: 'Life Balance',    glyph: '✦', earned: false, hue: '#FFD66B' },
    { k: 'goal_complete',   l: 'Goal Closer',     glyph: '◆', earned: false, hue: '#C9A0FF' },
  ];

  return (
    <Frame theme={theme} sub="06 · rewards" label="Rewards">
      <div style={{ padding: `0 ${pad}px`, display: 'flex', flexDirection: 'column', gap }}>
        {/* Hero — Level & XP */}
        <div style={{
          marginTop: 4, padding: '18px 16px',
          borderRadius: 24,
          background: 'linear-gradient(135deg, rgba(165,132,255,0.22), rgba(255,214,107,0.12) 70%, rgba(165,132,255,0.06))',
          border: '1px solid rgba(165,132,255,0.35)',
          position: 'relative', overflow: 'hidden',
        }}>
          {/* Confetti speckles */}
          <div style={{ position: 'absolute', top: 8, right: 14, fontSize: 16 }}>✦</div>
          <div style={{ position: 'absolute', top: 30, right: 50, fontSize: 11, color: '#C9A0FF' }}>◆</div>
          <div style={{ position: 'absolute', top: 14, right: 80, fontSize: 9, color: '#7EE0B8' }}>●</div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <AvatarRing initials="AR" pct={0.4} level={7} size={68} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#C5B3FF', letterSpacing: 2 }}>LEVEL 7 · NAVIGATOR</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 22, color: tx, lineHeight: 1.05, marginTop: 4 }}>3,820 XP</div>
              <div style={{ marginTop: 6 }}>
                <XpBar pct={0.4} height={7} />
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 4 }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: tx3 }}>320/800 to L8</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 10, color: '#FFD66B' }}>+ 75 today</div>
              </div>
            </div>
          </div>
        </div>

        {/* Today's XP earnings */}
        <div>
          <SectionLabel color={tx3}>Today's XP · 75</SectionLabel>
          <div style={{ display: 'flex', gap: 6, marginTop: 8, overflowX: 'auto', paddingBottom: 4 }}>
            {[
              { l: 'Block · Workout',      v: 10, c: '#7EE0B8' },
              { l: 'Food photo',           v: 20, c: '#C9A0FF' },
              { l: 'Block · Wake routine', v: 10, c: '#7EE0B8' },
              { l: 'Goal task · Spec',     v: 15, c: '#C9A0FF' },
              { l: 'Resource · L4',        v: 20, c: '#FFD66B' },
            ].map((x, i) => (
              <div key={i} style={{
                padding: '8px 10px', borderRadius: 12,
                background: `${x.c}14`, border: `1px solid ${x.c}33`,
                flexShrink: 0,
              }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 8.5, color: tx2, letterSpacing: 0.4 }}>{x.l.toUpperCase()}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 14, color: x.c, marginTop: 2 }}>+{x.v}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Streaks */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx }}>Streaks</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3 }}>3 ACTIVE · 1 GRACE</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {streaks.map(s => (
              <div key={s.k} style={{
                padding: '12px 14px', borderRadius: 16,
                background: s.dim ? 'rgba(255,255,255,0.025)' : `linear-gradient(135deg, ${s.hue}1F, ${s.hue}08)`,
                border: `1px solid ${s.dim ? 'rgba(255,255,255,0.06)' : s.hue + '44'}`,
                display: 'flex', alignItems: 'center', gap: 12, position: 'relative', overflow: 'hidden',
              }}>
                <div style={{
                  width: 38, height: 38, borderRadius: 12,
                  background: s.dim ? 'rgba(255,255,255,0.04)' : `${s.hue}22`,
                  border: `1px solid ${s.dim ? 'rgba(255,255,255,0.08)' : s.hue + '55'}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <StreakFlame count={s.c} size="sm" dim={s.dim} />
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 14, color: s.dim ? tx2 : tx }}>{s.l}</div>
                    {s.best && (
                      <div style={{ padding: '1px 6px', borderRadius: 999, background: '#FFD66B', color: '#2A1E0A', fontFamily: 'Nunito', fontWeight: 900, fontSize: 8.5, letterSpacing: 0.5 }}>PERSONAL BEST</div>
                    )}
                  </div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3, marginTop: 2 }}>
                    {s.dim ? 'Start today · 1 tap to log' : `Last logged ${s.k === 'food' ? 'today' : 'yesterday'} · 1 grace day available`}
                  </div>
                </div>
                {!s.dim && (
                  <div style={{
                    fontFamily: 'Nunito', fontWeight: 900, fontSize: 26, color: s.hue, lineHeight: 1,
                    textShadow: `0 0 16px ${s.hue}88`,
                  }}>{s.c}</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Quests */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx }}>Quests</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3 }}>2 DAILY · 1 WEEKLY</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { l: 'Log 3 meals',          mod: 'health',   pct: 0.67, n: '2/3', xp: 30, period: 'DAILY' },
              { l: 'Finish one resource',  mod: 'polymath', pct: 1.0,  n: '1/1', xp: 100, period: 'DAILY', done: true },
              { l: '5 deep-work blocks',   mod: 'goal',     pct: 0.4,  n: '2/5', xp: 200, period: 'WEEKLY' },
            ].map((q, i) => {
              const d = DOMAINS[q.mod];
              return (
                <div key={i} style={{
                  padding: '12px 14px', borderRadius: 16,
                  background: q.done ? `linear-gradient(135deg, ${d.hue}33, ${d.hue}11)` : 'rgba(255,255,255,0.035)',
                  border: `1px solid ${q.done ? d.hue + '66' : d.hue + '33'}`,
                  position: 'relative',
                }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <div style={{
                      width: 28, height: 28, borderRadius: 9,
                      background: `${d.hue}22`, color: d.hue,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: 'Nunito', fontWeight: 900, fontSize: 14,
                    }}>{d.glyph}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
                        <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: tx }}>{q.l}</div>
                        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 0.5 }}>{q.period}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 6 }}>
                        <div style={{ flex: 1, height: 5, borderRadius: 3, background: 'rgba(255,255,255,0.08)', overflow: 'hidden' }}>
                          <div style={{ width: `${q.pct * 100}%`, height: '100%', background: d.hue, boxShadow: `0 0 8px ${d.hue}` }} />
                        </div>
                        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx2 }}>{q.n}</div>
                      </div>
                    </div>
                    <div style={{
                      padding: '4px 8px', borderRadius: 8,
                      background: '#FFD66B22', color: '#FFD66B',
                      fontFamily: 'Nunito', fontWeight: 900, fontSize: 11,
                    }}>+{q.xp} XP</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Badges */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx }}>Badges</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3 }}>5/8 EARNED</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
            {badges.map(b => (
              <div key={b.k} style={{
                aspectRatio: '1', borderRadius: 18,
                background: b.earned ? `radial-gradient(circle at 30% 30%, ${b.hue}33, ${b.hue}10)` : 'rgba(255,255,255,0.025)',
                border: `1.5px solid ${b.earned ? b.hue + '88' : 'rgba(255,255,255,0.06)'}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4,
                position: 'relative', overflow: 'hidden',
                opacity: b.earned ? 1 : 0.4,
              }}>
                {b.earned && (
                  <div style={{
                    position: 'absolute', inset: -2, borderRadius: 20,
                    background: `radial-gradient(circle at 50% 0%, ${b.hue}44, transparent 60%)`,
                    pointerEvents: 'none',
                  }} />
                )}
                <div style={{
                  fontSize: 22, color: b.hue, fontFamily: 'Nunito', fontWeight: 900,
                  filter: b.earned ? `drop-shadow(0 0 8px ${b.hue})` : 'none',
                }}>{b.glyph}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 9.5, color: tx2, textAlign: 'center', lineHeight: 1.1, padding: '0 4px' }}>{b.l}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <TabBar active="rewards" theme={theme} />
    </Frame>
  );
}

window.RewardsScreen = RewardsScreen;
