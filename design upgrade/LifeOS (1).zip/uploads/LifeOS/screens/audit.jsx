// Audit Cover — strategy + audit + roadmap, designed as a doc artboard
// Sits as the first artboard in the canvas
const { DOMAINS } = window;

function AuditCover() {
  return (
    <div style={{
      width: 920, padding: '36px 40px 44px', borderRadius: 22,
      background: 'linear-gradient(160deg, #0A0612 0%, #120A1E 100%)',
      color: '#F4EFFF',
      fontFamily: 'DM Sans, system-ui',
      position: 'relative', overflow: 'hidden',
      boxShadow: '0 30px 80px rgba(20,8,40,0.4), 0 0 0 1px rgba(255,255,255,0.06)',
    }}>
      {/* Aurora glow */}
      <div style={{ position: 'absolute', top: -80, right: -60, width: 360, height: 360, borderRadius: '50%', background: 'radial-gradient(circle, rgba(165,132,255,0.32), transparent 70%)', filter: 'blur(30px)' }} />
      <div style={{ position: 'absolute', bottom: -100, left: -60, width: 380, height: 380, borderRadius: '50%', background: 'radial-gradient(circle, rgba(126,224,184,0.16), transparent 70%)', filter: 'blur(30px)' }} />

      <div style={{ position: 'relative' }}>
        {/* Eyebrow */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {Object.values(DOMAINS).map(d => (
              <div key={d.glyph} style={{ color: d.hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 15 }}>{d.glyph}</div>
            ))}
          </div>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: 2.5, color: 'rgba(244,239,255,0.55)' }}>LIFEOS · REDESIGN BRIEF · v2</div>
        </div>

        {/* Title */}
        <div style={{
          fontFamily: 'Nunito, system-ui', fontWeight: 900,
          fontSize: 56, lineHeight: 1.02, letterSpacing: -1.2,
          maxWidth: 740,
        }}>
          Aurora Glass<br/>
          <span style={{ color: '#A584FF' }}>refined</span> <span style={{ color: 'rgba(244,239,255,0.4)', fontStyle: 'italic', fontWeight: 700 }}>— for the elite tier.</span>
        </div>

        <div style={{
          fontFamily: 'DM Sans, system-ui', fontSize: 17, lineHeight: 1.55, marginTop: 18, maxWidth: 720,
          color: 'rgba(244,239,255,0.78)',
        }}>
          The existing system has good bones: a 6-domain hex radar, gamification, voice, glyph-encoded color. This pass keeps the DNA and pushes it into territory that
          <span style={{ color: '#7EE0B8' }}> Headspace</span> would call calm and
          <span style={{ color: '#FF8C3C' }}> Duolingo</span> would call alive — without becoming either.
        </div>

        {/* Two columns: audit + moves */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 28, marginTop: 36 }}>
          {/* Audit */}
          <div>
            <SectionTitle label="01 · AUDIT" color="#FF99C5">What's friction today</SectionTitle>
            <AuditItem k="UI"   c="#C9A0FF" l="Visual hierarchy" body="Today screen stacks 8 unequal sections; hex radar competes with avatar + greeting + XP rail. No clear focal point." />
            <AuditItem k="UX"   c="#7FB8FF" l="Cognitive load"  body="Rewards tab packs streaks + quests + badges + level + XP earnings into one scroll. Users can't tell what's 'live' vs 'reference'." />
            <AuditItem k="MOT" c="#FFD66B" l="Motion vocabulary" body="Spring physics defined but motion lives in tap feedback only. No reward moments, no rhythm, no breath-pacing between sections." />
            <AuditItem k="COL" c="#F4C16A" l="Domain hues vs neutrals" body="Six saturated hues on dark glass — accessible, but the same intensity for everything competes for attention. Need an attention hierarchy." />
            <AuditItem k="GAM" c="#7EE0B8" l="Gamification visibility" body="XP & streaks live in chips; level-up overlay is the only celebratory beat. Daily wins are not celebrated. Habit loop has no 'aha' moment." />
            <AuditItem k="A11Y" c="#FF99C5" l="Accessibility" body="62% text-on-glass passes AA but not AAA; glyph + color is the only color-blind path. Some chips ride below 4.5:1." />
          </div>

          {/* Moves */}
          <div>
            <SectionTitle label="02 · MOVES" color="#7EE0B8">What this redesign does</SectionTitle>
            <Move n="1" l="Hex Radar as the face" body="Promote it from a 36px chip to the screen's hero. Center the avg score inside. Tap any vertex to dive into that domain." />
            <Move n="2" l="Routine = breathing timeline" body="Active block gets a soft pulse + glow, time bar, and 'NOW' tag. Past blocks fade gracefully. Future blocks are quiet." />
            <Move n="3" l="Celebrate streaks bigger" body="Streaks become a 5-cell grid with named fires + personal-best ribbon. Each cell is tappable to log immediately." />
            <Move n="4" l="One AI voice, throughout" body="Daily briefing, weekly insight, blood report, spending alert — all share the same '✦' AI sigil + violet halo treatment. One voice, six lenses." />
            <Move n="5" l="Headspace breath, Duolingo tap" body="Soft 600ms entries between sections (Headspace). Springy 180/22 on every tap (Duolingo). No motion lives without purpose." />
            <Move n="6" l="Goal arcs, not bars" body="Finance milestone is a literal sun-arc — milestones as pinned stops. Reaching one casts light." />
            <Move n="7" l="Privacy as a feature, visible" body="Profile gets a 'private by design' band — every screen with sensitive data carries a discreet on-device dot." />
          </div>
        </div>

        {/* System tokens at a glance */}
        <div style={{ marginTop: 36 }}>
          <SectionTitle label="03 · SYSTEM" color="#A584FF">Refined Aurora Glass tokens</SectionTitle>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 10, marginTop: 14 }}>
            {Object.entries(DOMAINS).map(([k, d]) => (
              <div key={k} style={{
                padding: 12, borderRadius: 14,
                background: `linear-gradient(180deg, ${d.hue}1F, ${d.hue}06)`,
                border: `1px solid ${d.hue}55`,
              }}>
                <div style={{ color: d.hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 22 }}>{d.glyph}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, marginTop: 6 }}>{d.label}</div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: 'rgba(244,239,255,0.5)', marginTop: 3, letterSpacing: 0.5 }}>{d.hue}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Type + motion + radii */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 18, marginTop: 18 }}>
          <TokenCard label="TYPE">
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 26, lineHeight: 1 }}>Nunito · Black</div>
            <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 16, marginTop: 4 }}>Nunito · ExtraBold</div>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontWeight: 400, fontSize: 13, marginTop: 4, color: 'rgba(244,239,255,0.7)' }}>DM Sans — body & UI</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, marginTop: 6, color: 'rgba(244,239,255,0.55)' }}>JETBRAINS MONO · LABELS</div>
          </TokenCard>
          <TokenCard label="MOTION">
            <Row k="Tap"     v="spring 180/22"    c="#FF8C3C" />
            <Row k="Overlay" v="spring 120/18"    c="#A584FF" />
            <Row k="Enter"   v="timing 600 ease"  c="#7EE0B8" />
            <Row k="Reward"  v="spring 260/24 +confetti" c="#FFD66B" />
          </TokenCard>
          <TokenCard label="RADII · GLASS">
            <Row k="Card"   v="22"  c="#C5B3FF" />
            <Row k="Button" v="14"  c="#C5B3FF" />
            <Row k="Pill"   v="999" c="#C5B3FF" />
            <Row k="Blur"   v="20 / 28 px" c="#C5B3FF" />
          </TokenCard>
        </div>

        {/* Priority matrix */}
        <div style={{ marginTop: 36 }}>
          <SectionTitle label="04 · ROADMAP" color="#FFD66B">Priority matrix</SectionTitle>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginTop: 14 }}>
            <Quadrant title="High impact · Low effort" color="#7EE0B8" items={[
              'Hex radar hero on Today',
              'Live block "NOW" pulse',
              'Streak grid + personal best ribbon',
              'AI sigil unification (✦ + violet)',
            ]} />
            <Quadrant title="High impact · High effort" color="#A584FF" items={[
              'Domain tap-to-zoom from radar',
              'Reward moment system (level-up, badge, streak save)',
              'Adaptive briefing tone (morning · midday · evening)',
            ]} />
            <Quadrant title="Quick wins" color="#FFD66B" items={[
              'XP chip morph to ring at 90%',
              'Streak grace day language ("1 save left")',
              'Empty-state copy on each tab',
            ]} />
            <Quadrant title="Later / experimental" color="#FF99C5" items={[
              'Orbit / Crown radar variants (see Tweaks)',
              'Voice-first morning ritual',
              'Friend-streak co-op (Phase 2)',
            ]} />
          </div>
        </div>

        {/* Footer */}
        <div style={{
          marginTop: 36, paddingTop: 18, borderTop: '1px dashed rgba(244,239,255,0.18)',
          display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap',
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'rgba(244,239,255,0.55)', letterSpacing: 0.5,
        }}>
          <span>→ Scroll right for the 5 redesigned screens.</span>
          <span style={{ color: 'rgba(244,239,255,0.3)' }}>·</span>
          <span>Toggle <span style={{ color: '#FFD66B' }}>Tweaks</span> for theme · density · gamification · radar variants · motion.</span>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({ label, color, children }) {
  return (
    <div>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, letterSpacing: 2, color, marginBottom: 6 }}>{label}</div>
      <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 24, color: '#F4EFFF', letterSpacing: -0.3 }}>{children}</div>
    </div>
  );
}

function AuditItem({ k, c, l, body }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '14px 0', borderBottom: '1px solid rgba(244,239,255,0.06)' }}>
      <div style={{
        flex: '0 0 auto', width: 38, height: 22, borderRadius: 6,
        background: `${c}1A`, border: `1px solid ${c}44`, color: c,
        fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, fontWeight: 600,
        display: 'flex', alignItems: 'center', justifyContent: 'center', letterSpacing: 0.5,
      }}>{k}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: '#F4EFFF' }}>{l}</div>
        <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: 'rgba(244,239,255,0.65)', lineHeight: 1.45, marginTop: 3 }}>{body}</div>
      </div>
    </div>
  );
}

function Move({ n, l, body }) {
  return (
    <div style={{ display: 'flex', gap: 10, padding: '14px 0', borderBottom: '1px solid rgba(244,239,255,0.06)' }}>
      <div style={{
        flex: '0 0 auto', width: 22, height: 22, borderRadius: 999,
        background: '#7EE0B822', border: '1px solid #7EE0B855', color: '#7EE0B8',
        fontFamily: 'Nunito', fontSize: 11, fontWeight: 900,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
      }}>{n}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: '#F4EFFF' }}>{l}</div>
        <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: 'rgba(244,239,255,0.65)', lineHeight: 1.45, marginTop: 3 }}>{body}</div>
      </div>
    </div>
  );
}

function TokenCard({ label, children }) {
  return (
    <div style={{
      padding: 14, borderRadius: 16,
      background: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.06)',
    }}>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: 2, color: 'rgba(244,239,255,0.45)', marginBottom: 8 }}>{label}</div>
      {children}
    </div>
  );
}

function Row({ k, v, c }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '4px 0' }}>
      <div style={{ width: 6, height: 6, borderRadius: 3, background: c }} />
      <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12.5, color: '#F4EFFF', flex: 1 }}>{k}</div>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: 'rgba(244,239,255,0.6)' }}>{v}</div>
    </div>
  );
}

function Quadrant({ title, color, items }) {
  return (
    <div style={{
      padding: 14, borderRadius: 16,
      background: `linear-gradient(160deg, ${color}10, transparent)`,
      border: `1px solid ${color}33`,
    }}>
      <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, letterSpacing: 1.5, color, marginBottom: 8 }}>{title.toUpperCase()}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {items.map((it, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ width: 4, height: 4, borderRadius: 2, background: color, flexShrink: 0 }} />
            <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13, color: '#F4EFFF' }}>{it}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.AuditCover = AuditCover;
