// Shared primitives for LifeOS redesign mockups
// Aurora Glass DNA — refined for elite tier
// Exports to window: Frame, HexRadar, AvatarRing, XpBar, StreakFlame,
// RoutineBlock, DomainChip, Glyph, GlassCard, SectionLabel, AuroraBg

const DOMAINS = {
  goal:     { hue: '#C9A0FF', label: 'Goals',    glyph: '◆' },
  health:   { hue: '#7EE0B8', label: 'Health',   glyph: '♥' },
  finance:  { hue: '#F4C16A', label: 'Money',    glyph: '◈' },
  career:   { hue: '#7FB8FF', label: 'Career',   glyph: '▲' },
  social:   { hue: '#FF99C5', label: 'Social',   glyph: '●' },
  polymath: { hue: '#FFD66B', label: 'Mind',     glyph: '✦' },
};

// ─────────────────────────────────────────────────────────────
// Phone Frame — tall, auto-height, iOS-shaped, notched
// Renders a 390-wide phone, contents grow vertically, status + home indicator
// keep it readable as a device mock without locking to 844px.
// ─────────────────────────────────────────────────────────────
function Frame({ children, time = '9:41', label, sub, theme = 'dark', density = 'cozy' }) {
  const isDark = theme !== 'light';
  const bg = isDark ? '#0A0612' : '#FAF7FF';
  const fg = isDark ? '#F4EFFF' : '#140828';
  const padScale = density === 'compact' ? 0.85 : density === 'spacious' ? 1.18 : 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 10 }}>
      {label && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 2, marginLeft: 4 }}>
          <div style={{ fontSize: 11, letterSpacing: 1.4, fontFamily: 'JetBrains Mono, ui-monospace, monospace', color: 'rgba(60,50,40,0.55)', textTransform: 'uppercase' }}>{sub}</div>
          <div style={{ fontSize: 18, fontFamily: 'Nunito, system-ui', fontWeight: 800, color: 'rgba(40,30,20,0.85)' }}>{label}</div>
        </div>
      )}
      <div style={{
        width: 390,
        background: bg,
        borderRadius: 54,
        padding: 10,
        boxShadow: '0 30px 80px rgba(20, 8, 40, 0.35), 0 0 0 1.5px rgba(255,255,255,0.06), inset 0 0 0 1px rgba(0,0,0,0.4)',
        border: '1px solid rgba(80,60,140,0.35)',
        position: 'relative',
      }}>
        <div style={{
          position: 'relative',
          background: bg,
          borderRadius: 46,
          overflow: 'hidden',
          minHeight: 200,
        }} data-density={density} data-theme={theme}>
          {/* Aurora bg */}
          <AuroraBg theme={theme} />
          {/* Status bar */}
          <div style={{
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            padding: '14px 28px 6px', position: 'relative', zIndex: 5,
            fontFamily: '-apple-system, "SF Pro Display", system-ui', fontWeight: 600,
            fontSize: 15, color: fg,
          }}>
            <span>{time}</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <svg width="17" height="11" viewBox="0 0 19 12"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7" fill={fg}/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7" fill={fg}/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7" fill={fg}/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7" fill={fg}/></svg>
              <svg width="14" height="11" viewBox="0 0 17 12"><path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z" fill={fg}/><path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z" fill={fg}/><circle cx="8.5" cy="10.5" r="1.5" fill={fg}/></svg>
              <svg width="24" height="11" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke={fg} strokeOpacity="0.35" fill="none"/><rect x="2" y="2" width="20" height="9" rx="2" fill={fg}/><path d="M25 4.5V8.5C25.8 8.2 26.5 7.2 26.5 6.5C26.5 5.8 25.8 4.8 25 4.5Z" fill={fg} fillOpacity="0.4"/></svg>
            </div>
          </div>
          {/* Notch */}
          <div style={{
            position: 'absolute', top: 8, left: '50%', transform: 'translateX(-50%)',
            width: 122, height: 33, background: '#000', borderRadius: 22, zIndex: 6,
          }} />
          {/* Body */}
          <div style={{ position: 'relative', zIndex: 4, paddingBottom: 32, color: fg, '--pad': `${padScale}` }}>
            {children}
          </div>
          {/* Home indicator */}
          <div style={{
            position: 'absolute', bottom: 7, left: '50%', transform: 'translateX(-50%)',
            width: 134, height: 5, borderRadius: 3,
            background: isDark ? 'rgba(255,255,255,0.55)' : 'rgba(20,8,40,0.5)',
            zIndex: 6,
          }} />
        </div>
      </div>
    </div>
  );
}

// Aurora background — soft glowing orbs behind content
function AuroraBg({ theme = 'dark' }) {
  const isDark = theme !== 'light';
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none', zIndex: 1 }}>
      <div style={{
        position: 'absolute', top: -120, left: -80, width: 320, height: 320, borderRadius: '50%',
        background: isDark
          ? 'radial-gradient(circle, rgba(165,132,255,0.35), rgba(165,132,255,0) 70%)'
          : 'radial-gradient(circle, rgba(165,132,255,0.25), rgba(165,132,255,0) 70%)',
        filter: 'blur(20px)',
      }} />
      <div style={{
        position: 'absolute', top: 80, right: -100, width: 280, height: 280, borderRadius: '50%',
        background: isDark
          ? 'radial-gradient(circle, rgba(126,224,184,0.20), rgba(126,224,184,0) 70%)'
          : 'radial-gradient(circle, rgba(126,224,184,0.18), rgba(126,224,184,0) 70%)',
        filter: 'blur(20px)',
      }} />
      <div style={{
        position: 'absolute', bottom: -100, left: -60, width: 360, height: 360, borderRadius: '50%',
        background: isDark
          ? 'radial-gradient(circle, rgba(255,153,197,0.16), rgba(255,153,197,0) 70%)'
          : 'radial-gradient(circle, rgba(255,153,197,0.16), rgba(255,153,197,0) 70%)',
        filter: 'blur(28px)',
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Glass Card — frosted, bordered, soft inner glow
// ─────────────────────────────────────────────────────────────
function GlassCard({ children, style = {}, accent, padding = 18, radius = 22, theme = 'dark', onClick }) {
  const isDark = theme !== 'light';
  return (
    <div onClick={onClick} style={{
      background: isDark ? 'rgba(255,255,255,0.045)' : 'rgba(255,255,255,0.7)',
      backdropFilter: 'blur(20px)',
      border: `1px solid ${isDark ? 'rgba(255,255,255,0.08)' : 'rgba(20,8,40,0.08)'}`,
      borderRadius: radius,
      padding,
      position: 'relative',
      overflow: 'hidden',
      ...(accent ? { borderLeft: `3px solid ${accent}` } : {}),
      ...style,
    }}>
      {accent && (
        <div style={{
          position: 'absolute', top: 0, left: 0, right: 0, height: 70,
          background: `radial-gradient(ellipse at top left, ${accent}22, transparent 70%)`,
          pointerEvents: 'none',
        }} />
      )}
      <div style={{ position: 'relative' }}>{children}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Section Label — small monospace caps
// ─────────────────────────────────────────────────────────────
function SectionLabel({ children, color = 'rgba(244,239,255,0.5)', icon }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6,
      fontSize: 10.5, letterSpacing: 1.6, color, textTransform: 'uppercase',
      fontFamily: 'JetBrains Mono, ui-monospace, monospace', fontWeight: 500,
    }}>
      {icon}
      {children}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Hex Radar — hero piece. 6 domains arranged as hexagon vertices.
// Variants: 'web' (default), 'orbit' (concentric rings), 'crown' (bars)
// ─────────────────────────────────────────────────────────────
function HexRadar({ scores, size = 260, variant = 'web', glow = true }) {
  const cx = size / 2, cy = size / 2;
  const r = size * 0.38;
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  const angles = keys.map((_, i) => -Math.PI / 2 + (i * Math.PI / 3));

  const point = (i, scale) => {
    const a = angles[i];
    return [cx + Math.cos(a) * r * scale, cy + Math.sin(a) * r * scale];
  };

  const labels = keys.map((k, i) => {
    const a = angles[i];
    const lr = r + 22;
    return { k, x: cx + Math.cos(a) * lr, y: cy + Math.sin(a) * lr, ...DOMAINS[k], score: scores[k] };
  });

  if (variant === 'orbit') {
    return <RadarOrbit scores={scores} size={size} />;
  }
  if (variant === 'crown') {
    return <RadarCrown scores={scores} size={size} />;
  }

  // Web variant — main
  const polyPoints = keys.map((k, i) => {
    const scale = (scores[k] ?? 0) / 100;
    const [x, y] = point(i, scale);
    return `${x},${y}`;
  }).join(' ');

  const gridScales = [0.25, 0.5, 0.75, 1];

  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <defs>
          <radialGradient id="hex-glow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor="#A584FF" stopOpacity="0.45" />
            <stop offset="1" stopColor="#A584FF" stopOpacity="0" />
          </radialGradient>
          <linearGradient id="hex-fill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#A584FF" stopOpacity="0.55" />
            <stop offset="1" stopColor="#7EE0B8" stopOpacity="0.45" />
          </linearGradient>
        </defs>
        {glow && <circle cx={cx} cy={cy} r={r * 1.1} fill="url(#hex-glow)" />}
        {/* Grid hexes */}
        {gridScales.map((s, gi) => {
          const pts = keys.map((_, i) => {
            const [x, y] = point(i, s);
            return `${x},${y}`;
          }).join(' ');
          return <polygon key={gi} points={pts} fill="none" stroke="rgba(244,239,255,0.10)" strokeWidth="1" />;
        })}
        {/* Spokes */}
        {keys.map((_, i) => {
          const [x2, y2] = point(i, 1);
          return <line key={i} x1={cx} y1={cy} x2={x2} y2={y2} stroke="rgba(244,239,255,0.07)" strokeWidth="1" />;
        })}
        {/* Filled polygon */}
        <polygon points={polyPoints} fill="url(#hex-fill)" stroke="#C5B3FF" strokeWidth="1.5" strokeLinejoin="round" opacity="0.9" />
        {/* Domain dots */}
        {keys.map((k, i) => {
          const scale = (scores[k] ?? 0) / 100;
          const [x, y] = point(i, scale);
          return (
            <g key={k}>
              <circle cx={x} cy={y} r="6" fill={DOMAINS[k].hue} opacity="0.25" />
              <circle cx={x} cy={y} r="3.5" fill={DOMAINS[k].hue} />
            </g>
          );
        })}
      </svg>
      {/* Labels */}
      {labels.map(l => (
        <div key={l.k} style={{
          position: 'absolute', left: l.x, top: l.y, transform: 'translate(-50%, -50%)',
          textAlign: 'center', pointerEvents: 'none',
        }}>
          <div style={{ fontSize: 13, fontWeight: 800, color: l.hue, fontFamily: 'Nunito, system-ui', lineHeight: 1 }}>{l.glyph}</div>
          <div style={{ fontSize: 9, letterSpacing: 1, color: 'rgba(244,239,255,0.55)', marginTop: 2, fontFamily: 'JetBrains Mono, monospace', textTransform: 'uppercase' }}>{l.label}</div>
          <div style={{ fontSize: 13, fontWeight: 800, color: 'rgba(244,239,255,0.95)', fontFamily: 'Nunito', marginTop: 1 }}>{l.score}</div>
        </div>
      ))}
    </div>
  );
}

function RadarOrbit({ scores, size = 260 }) {
  const cx = size / 2, cy = size / 2;
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size}>
        <defs>
          <radialGradient id="orbit-glow"><stop offset="0" stopColor="#A584FF" stopOpacity="0.4"/><stop offset="1" stopColor="#A584FF" stopOpacity="0"/></radialGradient>
        </defs>
        <circle cx={cx} cy={cy} r={size * 0.42} fill="url(#orbit-glow)" />
        {keys.map((k, i) => {
          const a = -Math.PI / 2 + i * Math.PI / 3;
          const rOuter = size * 0.42;
          const len = ((scores[k] ?? 0) / 100) * rOuter;
          const x1 = cx + Math.cos(a) * (rOuter - len);
          const y1 = cy + Math.sin(a) * (rOuter - len);
          const x2 = cx + Math.cos(a) * rOuter;
          const y2 = cy + Math.sin(a) * rOuter;
          return (
            <g key={k}>
              <line x1={cx} y1={cy} x2={x2} y2={y2} stroke="rgba(244,239,255,0.08)" strokeWidth="1" />
              <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={DOMAINS[k].hue} strokeWidth="6" strokeLinecap="round" opacity="0.9" />
            </g>
          );
        })}
        <circle cx={cx} cy={cy} r="22" fill="rgba(10,6,18,0.85)" stroke="rgba(255,255,255,0.15)" />
      </svg>
      {keys.map((k, i) => {
        const a = -Math.PI / 2 + i * Math.PI / 3;
        const x = cx + Math.cos(a) * (size * 0.5);
        const y = cy + Math.sin(a) * (size * 0.5);
        return (
          <div key={k} style={{ position: 'absolute', left: x, top: y, transform: 'translate(-50%, -50%)', textAlign: 'center', pointerEvents: 'none' }}>
            <div style={{ fontSize: 11, color: DOMAINS[k].hue, fontFamily: 'Nunito', fontWeight: 800 }}>{DOMAINS[k].glyph} {scores[k]}</div>
          </div>
        );
      })}
    </div>
  );
}

function RadarCrown({ scores, size = 260 }) {
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  const maxH = size * 0.55;
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, height: size, justifyContent: 'center', width: size }}>
      {keys.map(k => {
        const h = ((scores[k] ?? 0) / 100) * maxH;
        return (
          <div key={k} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, width: 36 }}>
            <div style={{ fontSize: 11, color: 'rgba(244,239,255,0.85)', fontFamily: 'Nunito', fontWeight: 800 }}>{scores[k]}</div>
            <div style={{
              width: 14, height: h, borderRadius: 7,
              background: `linear-gradient(to top, ${DOMAINS[k].hue}, ${DOMAINS[k].hue}88)`,
              boxShadow: `0 0 16px ${DOMAINS[k].hue}55`,
            }} />
            <div style={{ fontSize: 13, color: DOMAINS[k].hue, fontFamily: 'Nunito', fontWeight: 800 }}>{DOMAINS[k].glyph}</div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Avatar Ring — initials w/ progress arc
// ─────────────────────────────────────────────────────────────
function AvatarRing({ initials = 'A', pct = 0.6, level = 7, size = 56, color = '#A584FF' }) {
  const r = size / 2 - 4;
  const c = 2 * Math.PI * r;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} stroke="rgba(255,255,255,0.08)" strokeWidth="3" fill="none" />
        <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth="3" fill="none"
          strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round" />
      </svg>
      <div style={{
        position: 'absolute', inset: 4, borderRadius: '50%',
        background: 'linear-gradient(135deg, #1A1028, #2A1E4A)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: 'Nunito', fontWeight: 900, color: '#F4EFFF', fontSize: size * 0.34,
      }}>{initials}</div>
      {/* Level chip */}
      <div style={{
        position: 'absolute', bottom: -2, right: -2,
        background: '#FFD66B', color: '#2A1E0A',
        fontFamily: 'Nunito', fontWeight: 900, fontSize: 10,
        borderRadius: 999, padding: '2px 6px', minWidth: 18, textAlign: 'center',
        boxShadow: '0 2px 8px rgba(255,214,107,0.5)', border: '2px solid #120A1E',
      }}>{level}</div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// XP Bar — gradient progress with shimmer
// ─────────────────────────────────────────────────────────────
function XpBar({ pct = 0.6, height = 6, color = '#A584FF', glow = true }) {
  return (
    <div style={{
      height, borderRadius: height,
      background: 'rgba(255,255,255,0.08)', overflow: 'hidden', position: 'relative',
    }}>
      <div style={{
        width: `${pct * 100}%`, height: '100%',
        background: `linear-gradient(90deg, ${color}, #C5B3FF)`,
        borderRadius: height,
        boxShadow: glow ? `0 0 12px ${color}88` : 'none',
      }} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Streak Flame — gradient flame icon + count
// ─────────────────────────────────────────────────────────────
function StreakFlame({ count = 7, size = 'md', dim = false }) {
  const fontSize = size === 'lg' ? 22 : size === 'sm' ? 13 : 16;
  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      <FlameIcon size={fontSize + 4} dim={dim} />
      <span style={{
        fontFamily: 'Nunito', fontWeight: 900, fontSize, color: dim ? 'rgba(244,239,255,0.4)' : '#FF8C3C',
        textShadow: dim ? 'none' : '0 0 12px rgba(255,140,60,0.5)',
      }}>{count}</span>
    </div>
  );
}

function FlameIcon({ size = 18, dim = false }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24">
      <defs>
        <linearGradient id={`flame-${dim ? 'd' : 'l'}`} x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor={dim ? '#3A2A1A' : '#FF4D2D'} />
          <stop offset="0.5" stopColor={dim ? '#4A3A2A' : '#FF8C3C'} />
          <stop offset="1" stopColor={dim ? '#5A4A3A' : '#FFC23A'} />
        </linearGradient>
      </defs>
      <path d="M12 2 C12 6 8 7 8 12 C8 16 10 19 12 22 C14 19 16 16 16 12 C16 9 14 8 14 5 C13 6 12 5 12 2 Z M10 14 C10 16 11 17.5 12 19 C13 17.5 14 16 14 14 C14 12.5 13 12 12.5 10 C12 11 11 11.5 10 14 Z" fill={`url(#flame-${dim ? 'd' : 'l'})`} />
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Routine Block — time + title + module color + status
// ─────────────────────────────────────────────────────────────
function RoutineBlock({ time, title, module: mod, status = 'pending', live = false, theme = 'dark' }) {
  const hue = DOMAINS[mod]?.hue ?? '#A584FF';
  const glyph = DOMAINS[mod]?.glyph ?? '◇';
  const done = status === 'completed';
  const isDark = theme !== 'light';
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '14px 16px',
      borderRadius: 18,
      background: live
        ? `linear-gradient(135deg, ${hue}22, ${hue}08)`
        : (isDark ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.6)'),
      border: `1px solid ${live ? hue + '55' : (isDark ? 'rgba(255,255,255,0.06)' : 'rgba(20,8,40,0.06)')}`,
      position: 'relative', overflow: 'hidden',
      opacity: done ? 0.55 : 1,
    }}>
      {live && (
        <div style={{
          position: 'absolute', left: 0, top: 0, bottom: 0, width: 3,
          background: hue, boxShadow: `0 0 12px ${hue}`,
        }} />
      )}
      <div style={{
        width: 36, height: 36, borderRadius: 12,
        background: `linear-gradient(135deg, ${hue}33, ${hue}11)`,
        border: `1px solid ${hue}44`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 16,
        flexShrink: 0,
      }}>{glyph}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontFamily: 'Nunito', fontWeight: 800, fontSize: 15,
          color: isDark ? '#F4EFFF' : '#140828',
          textDecoration: done ? 'line-through' : 'none',
        }}>{title}</div>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11,
          color: isDark ? 'rgba(244,239,255,0.55)' : 'rgba(20,8,40,0.55)',
          letterSpacing: 0.6, marginTop: 2,
        }}>
          {time}{live && <span style={{ color: hue, marginLeft: 8 }}>● NOW</span>}
        </div>
      </div>
      <CheckCircle done={done} hue={hue} />
    </div>
  );
}

function CheckCircle({ done, hue }) {
  return (
    <div style={{
      width: 26, height: 26, borderRadius: 13,
      border: `1.5px solid ${done ? hue : 'rgba(244,239,255,0.25)'}`,
      background: done ? hue : 'transparent',
      display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
    }}>
      {done && (
        <svg width="14" height="14" viewBox="0 0 14 14"><path d="M3 7 L6 10 L11 4" stroke="#0A0612" strokeWidth="2.5" fill="none" strokeLinecap="round" strokeLinejoin="round" /></svg>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Domain Chip + Glyph
// ─────────────────────────────────────────────────────────────
function DomainChip({ domain, value, label }) {
  const d = DOMAINS[domain] || {};
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '6px 12px', borderRadius: 999,
      background: `${d.hue}1A`, border: `1px solid ${d.hue}44`,
    }}>
      <span style={{ color: d.hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 12 }}>{d.glyph}</span>
      <span style={{ color: 'rgba(244,239,255,0.92)', fontFamily: 'Nunito', fontWeight: 700, fontSize: 12 }}>{label || d.label}</span>
      {value !== undefined && <span style={{ color: d.hue, fontFamily: 'JetBrains Mono, monospace', fontSize: 11, fontWeight: 600 }}>{value}</span>}
    </div>
  );
}

function Glyph({ domain, size = 14 }) {
  const d = DOMAINS[domain] || {};
  return <span style={{ color: d.hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: size }}>{d.glyph}</span>;
}

// ─────────────────────────────────────────────────────────────
// Bottom Tab Bar
// ─────────────────────────────────────────────────────────────
function TabBar({ active = 'today', theme = 'dark' }) {
  const isDark = theme !== 'light';
  const tabs = [
    { k: 'today',   label: 'Today',   icon: <TabIcon path="M12 3 L21 12 L18 12 L18 20 L14 20 L14 14 L10 14 L10 20 L6 20 L6 12 L3 12 Z" /> },
    { k: 'goals',   label: 'Goals',   icon: <TabIcon path="M12 3 L4 12 L12 21 L20 12 Z" /> },
    { k: 'rewards', label: 'Rewards', icon: <TabIcon path="M12 2 L15 8.5 L22 9.5 L17 14.5 L18.5 22 L12 18.5 L5.5 22 L7 14.5 L2 9.5 L9 8.5 Z" /> },
    { k: 'explore', label: 'Explore', icon: <TabIcon path="M12 2 L14 10 L22 12 L14 14 L12 22 L10 14 L2 12 L10 10 Z" /> },
    { k: 'profile', label: 'Me',      icon: <TabIcon path="M12 12 m -5 0 a 5 5 0 1 0 10 0 a 5 5 0 1 0 -10 0 M3 22 C3 17 7 14 12 14 C17 14 21 17 21 22 Z" /> },
  ];
  return (
    <div style={{
      margin: '12px 16px 0',
      padding: '10px 12px',
      borderRadius: 28,
      background: isDark ? 'rgba(18,10,30,0.85)' : 'rgba(255,255,255,0.85)',
      backdropFilter: 'blur(28px)',
      border: `1px solid ${isDark ? 'rgba(255,255,255,0.08)' : 'rgba(20,8,40,0.08)'}`,
      display: 'flex', justifyContent: 'space-around', alignItems: 'center',
      boxShadow: '0 10px 30px rgba(0,0,0,0.3)',
    }}>
      {tabs.map(t => {
        const on = t.k === active;
        const c = on ? '#A584FF' : (isDark ? 'rgba(244,239,255,0.42)' : 'rgba(20,8,40,0.42)');
        return (
          <div key={t.k} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, position: 'relative', padding: '4px 6px' }}>
            {on && (
              <div style={{
                position: 'absolute', inset: 0, borderRadius: 16,
                background: 'rgba(165,132,255,0.14)',
                border: '1px solid rgba(165,132,255,0.3)',
              }} />
            )}
            <div style={{ position: 'relative', color: c }}>{t.icon}</div>
            <div style={{ position: 'relative', fontFamily: 'Nunito', fontWeight: 700, fontSize: 9.5, color: c, letterSpacing: 0.3 }}>{t.label}</div>
          </div>
        );
      })}
    </div>
  );
}

function TabIcon({ path }) {
  return <svg width="20" height="20" viewBox="0 0 24 24"><path d={path} fill="currentColor" /></svg>;
}

// ─────────────────────────────────────────────────────────────
// Ring (donut) — for calorie ring, etc.
// ─────────────────────────────────────────────────────────────
function Ring({ size = 200, stroke = 14, segments, label, sub, center }) {
  // segments: [{ value, color, max }] — drawn concentrically? We instead stack
  // one big ring with concentric inner rings.
  const r = size / 2 - stroke / 2 - 2;
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        {segments.map((s, i) => {
          const rr = r - i * (stroke + 4);
          if (rr < 10) return null;
          const c = 2 * Math.PI * rr;
          const pct = Math.min(1, s.value / s.max);
          return (
            <g key={i}>
              <circle cx={size/2} cy={size/2} r={rr} stroke="rgba(255,255,255,0.07)" strokeWidth={stroke} fill="none" />
              <circle cx={size/2} cy={size/2} r={rr} stroke={s.color} strokeWidth={stroke} fill="none"
                strokeDasharray={c} strokeDashoffset={c * (1 - pct)} strokeLinecap="round"
                style={{ filter: `drop-shadow(0 0 8px ${s.color}88)` }} />
            </g>
          );
        })}
      </svg>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 2 }}>
        {center}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Tiny Sparkline / Bar / Line chart helpers
// ─────────────────────────────────────────────────────────────
function Sparkline({ data, color = '#A584FF', width = 200, height = 50, fill = true }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const points = data.map((v, i) => {
    const x = (i / (data.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 6) - 3;
    return [x, y];
  });
  const path = points.map(([x, y], i) => `${i === 0 ? 'M' : 'L'} ${x} ${y}`).join(' ');
  const area = `${path} L ${width} ${height} L 0 ${height} Z`;
  return (
    <svg width={width} height={height}>
      {fill && (
        <>
          <defs>
            <linearGradient id={`sp-${color.replace('#','')}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.4" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} fill={`url(#sp-${color.replace('#','')})`} />
        </>
      )}
      <path d={path} stroke={color} strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {points.map(([x, y], i) => i === points.length - 1 ? (
        <circle key={i} cx={x} cy={y} r="3.5" fill={color} stroke="#0A0612" strokeWidth="1.5" />
      ) : null)}
    </svg>
  );
}

function BarChart({ data, color = '#7EE0B8', width = 260, height = 80, highlight }) {
  const max = Math.max(...data.map(d => d.v));
  const barW = (width - (data.length - 1) * 6) / data.length;
  return (
    <svg width={width} height={height + 14}>
      {data.map((d, i) => {
        const h = (d.v / max) * height;
        const x = i * (barW + 6);
        const y = height - h;
        const isHi = highlight === i;
        return (
          <g key={i}>
            <rect x={x} y={y} width={barW} height={h} rx={barW / 3} fill={isHi ? color : color + '55'} />
            <text x={x + barW / 2} y={height + 12} fontSize="9" fontFamily="JetBrains Mono, monospace" fill="rgba(244,239,255,0.5)" textAnchor="middle">{d.l}</text>
          </g>
        );
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// Annotation pin — little overlay note for the audit screens
// ─────────────────────────────────────────────────────────────
function Annotation({ children, color = '#FFD66B', x, y, n }) {
  return (
    <div style={{
      position: 'absolute', left: x, top: y, zIndex: 50, display: 'flex', gap: 8, alignItems: 'flex-start',
      transform: 'translate(-100%, 0)',
    }}>
      <div style={{
        background: 'rgba(254,244,168,0.95)', color: '#5a4a2a',
        fontFamily: 'JetBrains Mono, monospace', fontSize: 11, lineHeight: 1.35,
        padding: '8px 10px', borderRadius: 8, maxWidth: 220,
        boxShadow: '0 6px 24px rgba(0,0,0,0.25)',
        border: '1px solid rgba(0,0,0,0.08)',
        textAlign: 'right',
      }}>{children}</div>
      <div style={{
        width: 20, height: 20, borderRadius: '50%',
        background: color, color: '#2A1E0A',
        fontFamily: 'Nunito', fontWeight: 900, fontSize: 11,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        boxShadow: `0 0 12px ${color}88`,
      }}>{n}</div>
    </div>
  );
}

Object.assign(window, {
  DOMAINS, Frame, AuroraBg, GlassCard, SectionLabel,
  HexRadar, AvatarRing, XpBar, StreakFlame, FlameIcon,
  RoutineBlock, DomainChip, Glyph, TabBar, Ring, Sparkline, BarChart, Annotation,
});
