// Profile screen — identity, journey, settings entry-points
const { Frame, GlassCard, SectionLabel, AvatarRing, XpBar, HexRadar, TabBar, DOMAINS } = window;

function ProfileScreen({ theme = 'dark', density = 'cozy' }) {
  const isDark = theme !== 'light';
  const tx = isDark ? '#F4EFFF' : '#140828';
  const tx2 = isDark ? 'rgba(244,239,255,0.62)' : 'rgba(20,8,40,0.62)';
  const tx3 = isDark ? 'rgba(244,239,255,0.4)' : 'rgba(20,8,40,0.4)';

  const pad = density === 'compact' ? 16 : density === 'spacious' ? 26 : 20;
  const gap = density === 'compact' ? 12 : density === 'spacious' ? 18 : 14;

  const scores = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };

  return (
    <Frame theme={theme} sub="07 · profile" label="Profile">
      <div style={{ padding: `0 ${pad}px`, display: 'flex', flexDirection: 'column', gap }}>
        {/* Hero card */}
        <div style={{
          marginTop: 4, padding: 20, borderRadius: 24,
          background: 'linear-gradient(150deg, rgba(165,132,255,0.18), rgba(126,224,184,0.06) 70%)',
          border: '1px solid rgba(165,132,255,0.28)',
          position: 'relative', overflow: 'hidden',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <AvatarRing initials="AR" pct={0.4} level={7} size={80} />
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 22, color: tx, lineHeight: 1.1 }}>Arjun Reddy</div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3, letterSpacing: 1, marginTop: 4, textTransform: 'uppercase' }}>L7 navigator · joined mar 28</div>
              <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                <div style={{ padding: '3px 8px', borderRadius: 999, background: 'rgba(127,184,255,0.16)', border: '1px solid rgba(127,184,255,0.4)', fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#7FB8FF' }}>▲ DATA ANALYST → ML</div>
                <div style={{ padding: '3px 8px', borderRadius: 999, background: 'rgba(126,224,184,0.16)', border: '1px solid rgba(126,224,184,0.4)', fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#7EE0B8' }}>♥ 75 KG TARGET</div>
              </div>
            </div>
          </div>
        </div>

        {/* Domain scores breakdown */}
        <GlassCard theme={theme}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <div style={{ flex: '0 0 auto' }}>
              <HexRadar scores={scores} size={140} glow={false} />
            </div>
            <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5, paddingTop: 4 }}>
              {Object.entries(scores).sort(([,a], [,b]) => b - a).map(([k, v]) => {
                const d = DOMAINS[k];
                return (
                  <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ color: d.hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 12, width: 14 }}>{d.glyph}</div>
                    <div style={{ flex: 1, height: 4, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
                      <div style={{ width: `${v}%`, height: '100%', background: d.hue }} />
                    </div>
                    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx2, width: 24, textAlign: 'right' }}>{v}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </GlassCard>

        {/* Journey stats */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {[
            { l: 'DAYS ON',  v: '47', sub: 'since Mar 28',  c: '#A584FF' },
            { l: 'BLOCKS',   v: '342', sub: 'completed',     c: '#7EE0B8' },
            { l: 'XP TOTAL', v: '3.8k', sub: 'top 12%',      c: '#FFD66B' },
          ].map(s => (
            <div key={s.l} style={{
              padding: '12px 12px', borderRadius: 14,
              background: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.06)',
            }}>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 1.2 }}>{s.l}</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 22, color: s.c, lineHeight: 1.05, marginTop: 4 }}>{s.v}</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 10.5, color: tx2, marginTop: 2 }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* Settings list */}
        <div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx, marginBottom: 8 }}>Account & integrations</div>
          <div style={{ borderRadius: 18, background: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.06)', overflow: 'hidden' }}>
            {[
              { i: '◇', l: 'Vision & goals',       sub: '8 active goals · 32 nodes', c: '#C9A0FF', dot: '#7EE0B8' },
              { i: '☉', l: 'Google Calendar',      sub: 'connected · 6 events synced', c: '#7FB8FF', dot: '#7EE0B8' },
              { i: '✉', l: 'Gmail · finance ingest', sub: 'HDFC + ICICI + AXIS · 124 tx',  c: '#F4C16A', dot: '#7EE0B8' },
              { i: '⚙', l: 'Notifications',         sub: 'daily 6:30 · streak 8 PM',     c: '#FFD66B', dot: null },
              { i: '⚐', l: 'Privacy & data export', sub: 'all data on-device · SQLite',  c: '#FF99C5', dot: null },
              { i: '↗', l: 'Help & how it works',  sub: '6 engines · 9 AI functions',   c: '#A584FF', dot: null },
            ].map((row, i, arr) => (
              <div key={row.l} style={{
                display: 'flex', alignItems: 'center', gap: 12, padding: '14px 14px',
                borderTop: i ? '1px solid rgba(255,255,255,0.04)' : 'none',
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 10,
                  background: `${row.c}1A`, color: row.c, border: `1px solid ${row.c}33`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontFamily: 'Nunito', fontWeight: 900, fontSize: 15,
                }}>{row.i}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: tx }}>{row.l}</div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3, marginTop: 2, letterSpacing: 0.3 }}>{row.sub}</div>
                </div>
                {row.dot && (
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <div style={{ width: 6, height: 6, borderRadius: 3, background: row.dot, boxShadow: `0 0 6px ${row.dot}` }} />
                  </div>
                )}
                <div style={{ color: tx3, fontSize: 16 }}>›</div>
              </div>
            ))}
          </div>
        </div>

        {/* Privacy footer */}
        <div style={{
          padding: '12px 14px', borderRadius: 16,
          background: 'rgba(126,224,184,0.06)', border: '1px solid rgba(126,224,184,0.18)',
          display: 'flex', gap: 10, alignItems: 'center',
        }}>
          <div style={{ fontSize: 20, color: '#7EE0B8' }}>♥</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: tx }}>Private by design</div>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 10.5, color: tx2, marginTop: 1 }}>Everything you log lives on this device. AI inference is the only outbound call.</div>
          </div>
        </div>
      </div>

      <TabBar active="profile" theme={theme} />
    </Frame>
  );
}

window.ProfileScreen = ProfileScreen;
