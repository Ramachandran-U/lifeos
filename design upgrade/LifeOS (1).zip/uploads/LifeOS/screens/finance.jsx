// Finance screen — AI plan + Gmail-ingested transactions + milestone
const { Frame, GlassCard, SectionLabel, BarChart, TabBar, DOMAINS, Glyph } = window;

function FinanceScreen({ theme = 'dark', density = 'cozy' }) {
  const isDark = theme !== 'light';
  const tx = isDark ? '#F4EFFF' : '#140828';
  const tx2 = isDark ? 'rgba(244,239,255,0.62)' : 'rgba(20,8,40,0.62)';
  const tx3 = isDark ? 'rgba(244,239,255,0.4)' : 'rgba(20,8,40,0.4)';

  const pad = density === 'compact' ? 16 : density === 'spacious' ? 26 : 20;
  const gap = density === 'compact' ? 12 : density === 'spacious' ? 18 : 14;

  // Goal milestone — Home down payment
  const goal = 1500000;
  const saved = 412000;
  const pct = saved / goal;

  return (
    <Frame theme={theme} sub="04 · money" label="Finance">
      <div style={{ padding: `0 ${pad}px`, display: 'flex', flexDirection: 'column', gap }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 4 }}>
          <div>
            <SectionLabel color="#F4C16A" icon={<Glyph domain="finance" size={11} />}>Money</SectionLabel>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 28, color: tx, lineHeight: 1.05, marginTop: 4 }}>This month</div>
          </div>
          <div style={{
            padding: '6px 10px', borderRadius: 999,
            background: 'rgba(244,193,106,0.14)', border: '1px solid rgba(244,193,106,0.4)',
            color: '#F4C16A', fontFamily: 'Nunito', fontWeight: 900, fontSize: 11, letterSpacing: 0.5,
          }}>+ ₹38,400 SAVED</div>
        </div>

        {/* Big in/out/saved */}
        <GlassCard theme={theme} padding={18}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 0 }}>
            {[
              { l: 'IN',    v: '₹1,42,000', c: '#7EE0B8' },
              { l: 'OUT',   v: '₹1,03,600', c: '#FF99C5' },
              { l: 'SAVED', v: '₹38,400',   c: '#F4C16A' },
            ].map((s, i) => (
              <div key={i} style={{ borderLeft: i ? '1px solid rgba(255,255,255,0.07)' : 'none', paddingLeft: i ? 12 : 0 }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 1.4 }}>{s.l}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 17, color: s.c, lineHeight: 1.1, marginTop: 4 }}>{s.v}</div>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 14, height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.06)', overflow: 'hidden', display: 'flex' }}>
            <div style={{ width: '52%', background: 'linear-gradient(90deg, #FF99C5, #FF99C599)' }} />
            <div style={{ width: '20%', background: 'linear-gradient(90deg, #C9A0FF, #C9A0FF99)' }} />
            <div style={{ width: '15%', background: 'linear-gradient(90deg, #7FB8FF, #7FB8FF99)' }} />
            <div style={{ width: '13%', background: 'linear-gradient(90deg, #F4C16A, #F4C16A99)' }} />
          </div>
          <div style={{ display: 'flex', gap: 10, marginTop: 8, flexWrap: 'wrap' }}>
            {[
              { l: 'Rent · 52%',   c: '#FF99C5' },
              { l: 'Food · 20%',   c: '#C9A0FF' },
              { l: 'Travel · 15%', c: '#7FB8FF' },
              { l: 'Misc · 13%',   c: '#F4C16A' },
            ].map((x, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                <div style={{ width: 6, height: 6, borderRadius: 2, background: x.c }} />
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: tx2, letterSpacing: 0.3 }}>{x.l}</div>
              </div>
            ))}
          </div>
        </GlassCard>

        {/* Milestone — Home down payment */}
        <GlassCard theme={theme} accent="#F4C16A">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <SectionLabel color="#F4C16A" icon={<span>◈</span>}>Down payment · Mumbai</SectionLabel>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3 }}>ETA APR 2028</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 26, color: tx }}>₹4.12L</div>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: tx2 }}>of ₹15L</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 14, color: '#F4C16A' }}>{Math.round(pct * 100)}%</div>
          </div>
          {/* Sun-arc progress */}
          <div style={{ marginTop: 12, position: 'relative' }}>
            <svg width="100%" height="60" viewBox="0 0 320 60">
              <defs>
                <linearGradient id="arc-bg" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0" stopColor="#F4C16A" stopOpacity="0.2" />
                  <stop offset="1" stopColor="#F4C16A" stopOpacity="0.05" />
                </linearGradient>
                <linearGradient id="arc-fg" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0" stopColor="#F4C16A" />
                  <stop offset="1" stopColor="#FFD66B" />
                </linearGradient>
              </defs>
              <path d="M 10 55 Q 160 -20 310 55" stroke="url(#arc-bg)" strokeWidth="8" fill="none" strokeLinecap="round" />
              <path d="M 10 55 Q 160 -20 310 55" stroke="url(#arc-fg)" strokeWidth="8" fill="none" strokeLinecap="round"
                    strokeDasharray="380" strokeDashoffset={380 * (1 - pct)} style={{ filter: 'drop-shadow(0 0 8px rgba(244,193,106,0.6))' }} />
              {/* Milestone pins */}
              {[0.25, 0.5, 0.75].map((p, i) => {
                const t = p;
                const x = 10 + (310 - 10) * t;
                // approximate y from parabola
                const y = 55 - 75 * 4 * t * (1 - t);
                const reached = pct >= p;
                return <circle key={i} cx={x} cy={y} r="4" fill={reached ? '#FFD66B' : 'rgba(244,193,106,0.25)'} stroke="#0A0612" strokeWidth="2" />;
              })}
              <circle cx={10 + (310 - 10) * pct} cy={55 - 75 * 4 * pct * (1 - pct)} r="7" fill="#FFD66B" stroke="#0A0612" strokeWidth="2.5" style={{ filter: 'drop-shadow(0 0 8px #FFD66B)' }} />
            </svg>
          </div>
          <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: tx2, marginTop: 4 }}>
            At ₹38,400/mo you arrive <span style={{ color: '#7EE0B8', fontWeight: 700 }}>4 months early</span>. Bump SIP to ₹45k to reach by Jan 2028.
          </div>
        </GlassCard>

        {/* AI Weekly Insight */}
        <GlassCard theme={theme} accent="#A584FF">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <SectionLabel color="#C5B3FF" icon={<span>✦</span>}>AI · This week's spend</SectionLabel>
          </div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 14, color: tx, lineHeight: 1.45 }}>
            <span style={{ color: '#FF99C5' }}>Food delivery jumped 38%</span> vs last week — 11 Swiggy orders. Try cooking 3× this week to claw back ₹2,800.
          </div>
          <div style={{ marginTop: 12 }}>
            <BarChart
              data={[
                { v: 12, l: 'M' }, { v: 8, l: 'T' }, { v: 22, l: 'W' },
                { v: 18, l: 'T' }, { v: 28, l: 'F' }, { v: 14, l: 'S' }, { v: 10, l: 'S' },
              ]}
              color="#FF99C5" width={310} height={70} highlight={4}
            />
          </div>
        </GlassCard>

        {/* Transactions — Gmail-ingested */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx }}>Recent · auto-ingested</div>
            <div style={{ flex: 1 }} />
            <div style={{
              padding: '3px 8px', borderRadius: 999,
              background: 'rgba(126,224,184,0.12)', border: '1px solid rgba(126,224,184,0.3)',
              fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#7EE0B8', letterSpacing: 0.5,
              display: 'flex', alignItems: 'center', gap: 4,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
              GMAIL LIVE
            </div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { merchant: 'Swiggy',      cat: 'Food',    when: 'Today 1:42 PM', amt: 412, dir: 'out', bank: 'HDFC', emoji: '🍱', hue: '#C9A0FF' },
              { merchant: 'BookMyShow',  cat: 'Leisure', when: 'Today 11:08 AM', amt: 480, dir: 'out', bank: 'ICICI', emoji: '🎬', hue: '#FF99C5' },
              { merchant: 'Salary · Vearc', cat: 'Income', when: 'Yesterday',     amt: 142000, dir: 'in', bank: 'HDFC', emoji: '💼', hue: '#7EE0B8' },
              { merchant: 'Uber',        cat: 'Travel',  when: 'Yesterday',      amt: 218, dir: 'out', bank: 'AXIS', emoji: '🚗', hue: '#7FB8FF' },
              { merchant: 'BigBasket',   cat: 'Groceries', when: 'Sat',         amt: 1840, dir: 'out', bank: 'HDFC', emoji: '🛒', hue: '#F4C16A' },
            ].map((t, i) => (
              <div key={i} style={{
                padding: '11px 12px', borderRadius: 14,
                background: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.06)',
                display: 'flex', alignItems: 'center', gap: 10,
              }}>
                <div style={{
                  width: 30, height: 30, borderRadius: 9,
                  background: `${t.hue}1A`, border: `1px solid ${t.hue}33`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 15, flexShrink: 0,
                }}>{t.emoji}</div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: tx }}>{t.merchant}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 2 }}>
                    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: t.hue, letterSpacing: 0.5 }}>{t.cat.toUpperCase()}</div>
                    <div style={{ width: 2, height: 2, borderRadius: 1, background: tx3 }} />
                    <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 0.5 }}>{t.when} · {t.bank}</div>
                  </div>
                </div>
                <div style={{
                  fontFamily: 'Nunito', fontWeight: 900, fontSize: 14,
                  color: t.dir === 'in' ? '#7EE0B8' : tx,
                }}>
                  {t.dir === 'in' ? '+' : '−'}₹{t.amt.toLocaleString('en-IN')}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <TabBar active="goals" theme={theme} />
    </Frame>
  );
}

window.FinanceScreen = FinanceScreen;
