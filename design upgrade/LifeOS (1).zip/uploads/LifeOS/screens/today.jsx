// Today screen — refined Aurora Glass DNA
// Hero hex radar + breathing routine timeline + briefing
// eslint-disable-next-line no-unused-vars
const { Frame, GlassCard, SectionLabel, HexRadar, AvatarRing, XpBar, StreakFlame,
        RoutineBlock, DomainChip, Glyph, TabBar, DOMAINS } = window;

function TodayScreen({ theme = 'dark', radarVariant = 'web', density = 'cozy', gamification = 'full' }) {
  const isDark = theme !== 'light';
  const tx = isDark ? '#F4EFFF' : '#140828';
  const tx2 = isDark ? 'rgba(244,239,255,0.62)' : 'rgba(20,8,40,0.62)';
  const tx3 = isDark ? 'rgba(244,239,255,0.4)' : 'rgba(20,8,40,0.4)';
  const showGam = gamification !== 'off';
  const fullGam = gamification === 'full';

  const scores = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };
  const avg = Math.round(Object.values(scores).reduce((a, b) => a + b, 0) / 6);

  const pad = density === 'compact' ? 16 : density === 'spacious' ? 26 : 20;
  const gap = density === 'compact' ? 12 : density === 'spacious' ? 18 : 14;

  return (
    <Frame theme={theme} time="9:41" sub="01 · home" label="Today">
      <div style={{ padding: `0 ${pad}px`, display: 'flex', flexDirection: 'column', gap }}>
        {/* Top row — avatar + voice */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
          <AvatarRing initials="AR" pct={0.42} level={7} size={48} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 19, color: tx, lineHeight: 1.1 }}>Good morning, Arjun</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3, letterSpacing: 1, marginTop: 3, textTransform: 'uppercase' }}>Tuesday · May 13 · day 47</div>
          </div>
          <div style={{
            width: 40, height: 40, borderRadius: 20,
            background: 'rgba(165,132,255,0.14)', border: '1px solid rgba(165,132,255,0.4)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
          }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <rect x="9" y="2" width="6" height="13" rx="3" fill="#A584FF" />
              <path d="M5 11 C5 15 8 18 12 18 C16 18 19 15 19 11 M12 18 V22 M8 22 H16" stroke="#A584FF" strokeWidth="1.6" strokeLinecap="round" fill="none" />
            </svg>
          </div>
        </div>

        {/* XP rail */}
        {showGam && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: tx3, letterSpacing: 1.2 }}>L7 → L8</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 11, color: '#FFD66B' }}>320/800 XP</div>
              </div>
              <XpBar pct={0.4} height={5} />
            </div>
          </div>
        )}

        {/* Hex radar hero */}
        <div style={{
          margin: '4px -4px 0',
          padding: '16px 0 8px',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          position: 'relative',
        }}>
          <HexRadar scores={scores} size={300} variant={radarVariant} />
          <div style={{
            position: 'absolute', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0,
            pointerEvents: 'none',
          }}>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 2, textTransform: 'uppercase' }}>Life Balance</div>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 38, color: tx, lineHeight: 1, marginTop: 2 }}>{avg}</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: '#7EE0B8', letterSpacing: 1, marginTop: 3 }}>▲ 4 this week</div>
          </div>
        </div>

        {/* Daily briefing */}
        <GlassCard accent="#A584FF" theme={theme}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <SectionLabel color="#C5B3FF" icon={<span style={{ fontSize: 13 }}>✦</span>}>Daily briefing</SectionLabel>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3 }}>9:02 AM</div>
          </div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 16, color: tx, lineHeight: 1.4 }}>
            Three blocks queued. Your <span style={{ color: '#7FB8FF' }}>ML mock interview</span> at 4 PM is the make-or-break for this week's career streak.
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
            <DomainChip domain="career" value="2/3" />
            <DomainChip domain="health" value="—" />
            <DomainChip domain="polymath" value="40m" />
          </div>
        </GlassCard>

        {/* Streak rail — Duolingo-flavoured tactile chips */}
        {showGam && (
          <div>
            <SectionLabel color={tx3} icon={<svg width="11" height="11" viewBox="0 0 24 24"><path d="M12 2 C12 6 8 7 8 12 C8 16 10 19 12 22 C14 19 16 16 16 12 C16 9 14 8 14 5 C13 6 12 5 12 2 Z" fill="#FF8C3C" /></svg>}>Streaks · 5</SectionLabel>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6, marginTop: 8 }}>
              {[
                { l: 'Workout',  c: 12, on: true,  hue: '#7EE0B8' },
                { l: 'Learn',    c: 47, on: true,  hue: '#7FB8FF', best: true },
                { l: 'Food',     c: 3,  on: true,  hue: '#C9A0FF' },
                { l: 'Journal',  c: 0,  on: false, hue: '#FFD66B' },
                { l: 'Social',   c: 0,  on: false, hue: '#FF99C5' },
              ].map((s, i) => (
                <div key={i} style={{
                  padding: '10px 8px', borderRadius: 14,
                  background: s.on ? `linear-gradient(180deg, ${s.hue}1F, ${s.hue}0A)` : (isDark ? 'rgba(255,255,255,0.025)' : 'rgba(20,8,40,0.04)'),
                  border: `1px solid ${s.on ? s.hue + '44' : (isDark ? 'rgba(255,255,255,0.06)' : 'rgba(20,8,40,0.06)')}`,
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                  position: 'relative',
                }}>
                  {s.best && <div style={{ position: 'absolute', top: -5, right: -5, background: '#FFD66B', borderRadius: 999, fontSize: 8, padding: '1px 5px', fontWeight: 900, color: '#2A1E0A', fontFamily: 'Nunito' }}>BEST</div>}
                  <StreakFlame count={s.c} size="sm" dim={!s.on} />
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 8.5, color: tx3, letterSpacing: 0.5, textTransform: 'uppercase' }}>{s.l}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Routine — section header */}
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginTop: 4 }}>
          <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 18, color: tx, lineHeight: 1 }}>Today's flow</div>
          <div style={{ flex: 1 }} />
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#7EE0B8', letterSpacing: 1 }}>2/6 done</div>
        </div>

        {/* Timeline of routine blocks */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <RoutineBlock theme={theme} time="06:30 – 07:00" title="Wake · sun light · 16oz water" module="health" status="completed" />
          <RoutineBlock theme={theme} time="07:00 – 07:45" title="Strength training · Push day"  module="health" status="completed" />
          <RoutineBlock theme={theme} time="09:00 – 11:30" title="Deep work — Spec for Q3 launch" module="goal" status="pending" live />
          <RoutineBlock theme={theme} time="12:30 – 13:00" title="Lunch · 600 kcal · 35g protein"  module="health" status="pending" />
          <RoutineBlock theme={theme} time="14:00 – 15:00" title="Andrew Ng · Sequence Models · L4" module="polymath" status="pending" />
          <RoutineBlock theme={theme} time="16:00 – 16:45" title="ML mock interview · System design" module="career" status="pending" />
        </div>

        {/* Evening wrap nudge */}
        <GlassCard theme={theme} accent="#FFD66B" style={{ marginTop: 4 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 36, height: 36, borderRadius: 18,
              background: 'rgba(255,214,107,0.16)', border: '1px solid rgba(255,214,107,0.4)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: '#FFD66B', fontFamily: 'Nunito', fontWeight: 900, fontSize: 18,
            }}>✦</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 14, color: tx }}>Wrap up the day at 9 PM</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11.5, color: tx2, marginTop: 2 }}>60 seconds · sets up tomorrow's plan</div>
            </div>
            <div style={{ color: tx3, fontSize: 18 }}>›</div>
          </div>
        </GlassCard>
      </div>

      <TabBar active="today" theme={theme} />
    </Frame>
  );
}

window.TodayScreen = TodayScreen;
