// Health screen — calorie ring hero, macros, photo food log
const { Frame, GlassCard, SectionLabel, Ring, Sparkline, BarChart, TabBar, DOMAINS, Glyph } = window;

function HealthScreen({ theme = 'dark', density = 'cozy' }) {
  const isDark = theme !== 'light';
  const tx = isDark ? '#F4EFFF' : '#140828';
  const tx2 = isDark ? 'rgba(244,239,255,0.62)' : 'rgba(20,8,40,0.62)';
  const tx3 = isDark ? 'rgba(244,239,255,0.4)' : 'rgba(20,8,40,0.4)';

  const pad = density === 'compact' ? 16 : density === 'spacious' ? 26 : 20;
  const gap = density === 'compact' ? 12 : density === 'spacious' ? 18 : 14;

  return (
    <Frame theme={theme} sub="03 · health" label="Health">
      <div style={{ padding: `0 ${pad}px`, display: 'flex', flexDirection: 'column', gap }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 4 }}>
          <div>
            <SectionLabel color="#7EE0B8" icon={<Glyph domain="health" size={11} />}>Health</SectionLabel>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 28, color: tx, lineHeight: 1.05, marginTop: 4 }}>Fueling well</div>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: tx2, marginTop: 3 }}>1,420 of 2,000 kcal · 580 to go</div>
          </div>
          <div style={{
            padding: '6px 10px', borderRadius: 999,
            background: 'rgba(126,224,184,0.14)', border: '1px solid rgba(126,224,184,0.4)',
            color: '#7EE0B8', fontFamily: 'Nunito', fontWeight: 900, fontSize: 11, letterSpacing: 0.5,
          }}>STREAK · 12d</div>
        </div>

        {/* Ring hero */}
        <div style={{ display: 'flex', justifyContent: 'center', padding: '4px 0' }}>
          <Ring
            size={230}
            stroke={14}
            segments={[
              { value: 1420, max: 2000, color: '#7EE0B8' },
              { value: 92,   max: 140,  color: '#F4C16A' },
              { value: 165,  max: 220,  color: '#7FB8FF' },
              { value: 22,   max: 30,   color: '#FF99C5' },
            ]}
            center={
              <>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 2 }}>KCAL LEFT</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 38, color: tx, lineHeight: 1, marginTop: 2 }}>580</div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#7EE0B8', marginTop: 4 }}>on track</div>
              </>
            }
          />
        </div>

        {/* Macros legend */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 8 }}>
          {[
            { l: 'Cals',    cur: 1420, max: 2000, u: '',  c: '#7EE0B8' },
            { l: 'Protein', cur: 92,   max: 140,  u: 'g', c: '#F4C16A' },
            { l: 'Carb',    cur: 165,  max: 220,  u: 'g', c: '#7FB8FF' },
            { l: 'Fibre',   cur: 22,   max: 30,   u: 'g', c: '#FF99C5' },
          ].map(m => (
            <div key={m.l} style={{
              padding: '10px 8px', borderRadius: 14,
              background: 'rgba(255,255,255,0.04)',
              border: `1px solid ${m.c}33`,
              display: 'flex', flexDirection: 'column', gap: 2, alignItems: 'flex-start',
            }}>
              <div style={{ width: 6, height: 6, borderRadius: 3, background: m.c, boxShadow: `0 0 8px ${m.c}` }} />
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 1, marginTop: 2 }}>{m.l.toUpperCase()}</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx, lineHeight: 1 }}>{m.cur}<span style={{ fontSize: 10, color: tx3, fontWeight: 700 }}>{m.u}</span></div>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3 }}>/{m.max}{m.u}</div>
            </div>
          ))}
        </div>

        {/* Photo food log */}
        <GlassCard theme={theme} accent="#7EE0B8" padding={16}>
          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            <div style={{
              width: 56, height: 56, borderRadius: 16,
              background: 'linear-gradient(135deg, #2A4A3A, #1F3A2E)',
              display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0,
              border: '1px solid rgba(126,224,184,0.3)',
            }}>
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="6" width="18" height="14" rx="2.5" stroke="#7EE0B8" strokeWidth="1.5" />
                <circle cx="12" cy="13" r="3.5" stroke="#7EE0B8" strokeWidth="1.5" />
                <path d="M8 6 L9 4 L15 4 L16 6" stroke="#7EE0B8" strokeWidth="1.5" />
              </svg>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 15, color: tx }}>Snap your meal</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11.5, color: tx2, marginTop: 2 }}>AI recognises foods + macros in 2s · +20 XP</div>
            </div>
            <div style={{
              padding: '8px 14px', borderRadius: 12,
              background: '#7EE0B8', color: '#0A1F18',
              fontFamily: 'Nunito', fontWeight: 900, fontSize: 12,
            }}>LOG</div>
          </div>
        </GlassCard>

        {/* Recent meals — Headspace soft list */}
        <div>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 8 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: tx }}>Today's meals</div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3 }}>3 logged</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {[
              { t: 'Oats + whey + banana', sub: '07:15 · 470 kcal · 32g P', emoji: '🥣' },
              { t: 'Chicken bowl + greens', sub: '12:45 · 620 kcal · 48g P', emoji: '🥗' },
              { t: 'Black coffee · oat milk',sub: '15:20 · 80 kcal',         emoji: '☕' },
            ].map((m, i) => (
              <div key={i} style={{
                padding: '12px 14px', borderRadius: 16,
                background: 'rgba(255,255,255,0.035)', border: '1px solid rgba(255,255,255,0.06)',
                display: 'flex', alignItems: 'center', gap: 12,
              }}>
                <div style={{
                  width: 32, height: 32, borderRadius: 10,
                  background: 'rgba(126,224,184,0.1)', border: '1px solid rgba(126,224,184,0.25)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 18,
                }}>{m.emoji}</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: tx }}>{m.t}</div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: tx3, marginTop: 2, letterSpacing: 0.3 }}>{m.sub}</div>
                </div>
                <div style={{ color: tx3, fontSize: 18 }}>›</div>
              </div>
            ))}
          </div>
        </div>

        {/* Weight trend */}
        <GlassCard theme={theme}>
          <div style={{ display: 'flex', alignItems: 'baseline' }}>
            <div>
              <SectionLabel color="#7FB8FF">Weight · 7 days</SectionLabel>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 6 }}>
                <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 26, color: tx, lineHeight: 1 }}>78.4<span style={{ fontSize: 12, color: tx3, fontWeight: 700 }}>kg</span></div>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: '#7EE0B8' }}>↓ 1.2 kg</div>
              </div>
            </div>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3 }}>TARGET 75 KG · 24 DAYS</div>
          </div>
          <div style={{ marginTop: 10 }}>
            <Sparkline data={[79.6, 79.2, 79.0, 78.9, 78.7, 78.5, 78.4]} color="#7FB8FF" width={310} height={50} />
          </div>
        </GlassCard>

        {/* Blood report card — AI parsed */}
        <GlassCard theme={theme} accent="#FF99C5">
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <SectionLabel color="#FF99C5" icon={<span>✦</span>}>AI · Blood report</SectionLabel>
            <div style={{ flex: 1 }} />
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: tx3, letterSpacing: 0.5 }}>UPLOADED 6 DAYS AGO</div>
          </div>
          <div style={{ fontFamily: 'Nunito', fontWeight: 700, fontSize: 14, color: tx, lineHeight: 1.45 }}>
            Vitamin D is <span style={{ color: '#F4C16A' }}>low (18 ng/mL)</span>. Most other markers are healthy. Consider 10 min sun before 10 AM and 2000 IU supplementation.
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
            <div style={{ padding: '5px 9px', borderRadius: 999, background: 'rgba(255,153,197,0.14)', border: '1px solid rgba(255,153,197,0.35)', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#FF99C5' }}>3 ACTIONS QUEUED</div>
            <div style={{ padding: '5px 9px', borderRadius: 999, background: 'rgba(126,224,184,0.1)', border: '1px solid rgba(126,224,184,0.3)', fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#7EE0B8' }}>11 MARKERS OK</div>
          </div>
        </GlassCard>
      </div>

      <TabBar active="goals" theme={theme} />
    </Frame>
  );
}

window.HealthScreen = HealthScreen;
