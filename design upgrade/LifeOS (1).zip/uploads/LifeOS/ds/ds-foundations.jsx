// Foundations: principles, color, typography, spacing, radii, elevation
const { DS, Section, Sub, Reason, TokenCard, Swatch, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function Foundations() {
  return (
    <>
      {/* ───────────────────────────────────────────────── PRINCIPLES */}
      <Section id="principles" eyebrow="01 · PRINCIPLES" title="Design language"
        lede="Six principles. Every decision below is downstream of these. When something feels off, check it against these first.">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <Principle n="1" color="#A584FF" glyph="✦" title="Synthesise, don't accumulate"
            body="The product's promise is one livable plan, not six engines bolted together. Every screen must answer 'what's next?' before it answers 'what is everything?'. Information density submits to information hierarchy."
          />
          <Principle n="2" color="#7EE0B8" glyph="♥" title="Breath, not blast"
            body="Calm by default; expressive at peaks. Long sessions need air between elements (Headspace). Reward moments are loud (Duolingo). Nothing in between competes for attention."
          />
          <Principle n="3" color="#F4C16A" glyph="◈" title="Glyph + colour, always"
            body="The six domain hues never carry meaning alone — they ride with the glyph (◆ ♥ ◈ ▲ ● ✦). Color-blind robustness, screen-reader robustness, dark-mode robustness all flow from this one rule."
          />
          <Principle n="4" color="#7FB8FF" glyph="▲" title="Earn motion"
            body="Motion guides attention or confirms action. Nothing animates because it can. Reward moments are the only exception — and even those serve memory consolidation, not vibes."
          />
          <Principle n="5" color="#FF99C5" glyph="●" title="Tactile over passive"
            body="Every meaningful tap returns force feedback (visual + haptic). Streaks, blocks, food log, XP — interactions land with weight. Passive UI feels like surveillance; tactile UI feels like agency."
          />
          <Principle n="6" color="#FFD66B" glyph="◆" title="Privacy as substance"
            body="On-device is a feature, not a footnote. Every screen that touches sensitive data carries a visible signal. Trust is built one detail at a time."
          />
        </div>
        <Reason
          ux="Principles are the cheapest design tool we have — they eliminate decisions before they're made. P1 alone kills 80% of dashboard-style proposals."
          psych="Calm + reward (P2) maps directly to the dopamine-without-anxiety loop that defines healthy habit apps. Surveillance feeling (P5) is what most life-tracking tools fail."
          impl="Each principle has a measurable test in code: P3 → grep for hue references without paired glyph; P4 → audit Reanimated callers without a state change. CI can enforce P3."
        />
      </Section>

      {/* ───────────────────────────────────────────────── COLOR */}
      <Section id="color" eyebrow="02 · COLOR" title="Color tokens"
        lede="Aurora Glass is a violet-anchored dark-first palette. Domain hues are tuned to equal perceived lightness so no domain shouts louder than another. Light mode is a 1:1 token swap — never a semantic re-spec.">

        <Sub title="Domain hues" hint="6 · paired with glyph · equal L* ≈ 78">
          <Grid cols={6} gap={10}>
            {[
              { c: '#C9A0FF', l: 'Goals',    v: 'goal · ◆' },
              { c: '#7EE0B8', l: 'Health',   v: 'health · ♥' },
              { c: '#F4C16A', l: 'Money',    v: 'finance · ◈' },
              { c: '#7FB8FF', l: 'Career',   v: 'career · ▲' },
              { c: '#FF99C5', l: 'Social',   v: 'social · ●' },
              { c: '#FFD66B', l: 'Mind',     v: 'polymath · ✦' },
            ].map(s => <Swatch key={s.l} color={s.c} label={s.l} value={`${s.v}\n${s.c}`} />)}
          </Grid>
          <Reason
            ux="Each hue carries one and only one domain. A user who learns 'green = health' on day 1 never re-learns it. Cross-domain widgets (Today, Rewards) become a visual legend by default."
            psych="Calibrating to equal perceived lightness prevents the 'finance-gold-always-pops' problem — gold is intrinsically more luminous than blue at the same hex saturation. Equal L* keeps domains democratic."
            impl="OKLCH-defined at L=0.78 / C=0.13 / H=[290, 165, 80, 240, 350, 90]. When adding a new domain, place its hue on the L=0.78 / C=0.13 ring; never pick from a color picker."
          />
        </Sub>

        <Sub title="Semantic & gamification" hint="reserved meaning">
          <Grid cols={6} gap={10}>
            <Swatch color="#31E0A3" label="Success" value="success\n#31E0A3" />
            <Swatch color="#FFC23A" label="Warning" value="warning\n#FFC23A" />
            <Swatch color="#FF5577" label="Error"   value="error\n#FF5577" />
            <Swatch color="#FFD66B" label="XP"      value="xp\n#FFD66B" />
            <Swatch color="#FF8C3C" label="Streak"  value="streak\n#FF8C3C" />
            <Swatch color="#C5B3FF" label="Badge"   value="badge\n#C5B3FF" />
          </Grid>
          <Reason
            ux="Semantic colors must NEVER overlap domain hues. A user who sees orange should know it's a streak (or warning), never an unfamiliar domain."
            psych="XP gold and streak flame use yellow→orange territory because those wavelengths are evolutionarily 'achievement' coded (sunlight, fire). Don't fight biology."
            impl="Semantic tokens live in a separate file from domain tokens. A lint rule forbids importing a semantic name where a domain is expected and vice versa."
          />
        </Sub>

        <Sub title="Surface hierarchy" hint="dark mode · 4 levels">
          <Grid cols={4} gap={10}>
            <Swatch color="#0A0612" label="Background" value="bg\n#0A0612" note="root canvas" />
            <Swatch color="#120A1E" label="Surface"    value="surface\n#120A1E" note="sheets, modals" />
            <Swatch color="#1A1028" label="Surface Alt" value="surface-alt\n#1A1028" note="pressed/raised" />
            <Swatch color="rgba(255,255,255,0.045)" label="Card (glass)" value="card\nrgba 4.5%" note="all content cards" />
          </Grid>
          <Reason
            ux="Four surfaces, four roles — no more. The card is always a translucent glass layer floating over the surface gradient; ambiguity between 'card' and 'surface' is what makes most dark UIs feel flat."
            psych="Depth perception in dark mode comes from translucency, not shadow. Translucent cards over a soft aurora gradient create a single legible parallax — black-on-black dies in OLED smear."
            impl="Card is rgba over surface (not bg) so a sheet'd modal correctly nests. Backdrop-filter blur(20px) at the card level; if unsupported, fall back to a 6% solid tint."
          />
        </Sub>

        <Sub title="Text on surface" hint="contrast pairings">
          <Grid cols={3} gap={10}>
            <Swatch color="#F4EFFF" label="Primary text"   value="text-primary\n#F4EFFF" contrast={{ pass: true,  label: 'AA on #120A1E · 14.8:1' }} />
            <Swatch color="rgba(244,239,255,0.65)" label="Secondary text" value="text-secondary\n62% F4EFFF" contrast={{ pass: true, label: 'AA · 8.4:1' }} note="body, helper copy" />
            <Swatch color="rgba(244,239,255,0.4)" label="Tertiary / muted" value="text-muted\n40% F4EFFF" contrast={{ pass: true, label: 'AA Large · 4.8:1' }} note="13px min" />
          </Grid>
          <Reason
            ux="Three text alphas. Anything muted (40%) must use ≥13px and ≥600 weight, or it fails AA on cards."
            psych="Warm-white (#F4EFFF has a violet tint, not paper white) reduces blue-light strain at night — when LifeOS users are most likely journaling or reflecting."
            impl="Tokens emit both rgba and the 8-digit hex; native React Native picks rgba (compositor-friendly), web picks hex. Never mix-paint a color and alpha via inline opacity — it breaks blur layers."
          />
        </Sub>

        <Sub title="State adaptation" hint="dark ↔ light">
          <SpecTable rows={[
            { name: 'background',     value: '#0A0612 → #FAF7FF', note: 'Light mode preserves a 2% violet tint so brand identity carries.' },
            { name: 'surface',        value: '#120A1E → #F2ECFC', note: 'Sheets read as risen above the canvas in both modes.' },
            { name: 'card',           value: 'rgba w/4.5% → rgba w/70%', note: 'Glass alpha inverts. In light mode the white floats over violet, vs. white below in dark.' },
            { name: 'domain hues',    value: 'unchanged',         note: 'Hues are L*=0.78 — they read on both surfaces without re-tinting.' },
            { name: 'text-primary',   value: '#F4EFFF → #140828', note: 'Both have a 1% violet tint; never use pure white or pure black.' },
            { name: 'shadows',        value: 'glow-blue → cast',  note: 'Dim aurora glows (dark) → soft cast shadows below cards (light).' },
            { name: 'border',         value: 'rgba 8% → rgba 10%', note: 'Light mode borders are slightly heavier to make glass legible without the dark contrast.' },
          ]} />
          <Reason
            ux="Tokens flip; meaning doesn't. A 'success' is green in both modes, just calibrated to L*."
            psych="Light mode is for utility / public spaces; dark is for evening flow. The product spends ~70% of usage in dark — calibrate dark first."
            impl="One CSS variable swap on the root flips themes in <16ms — no per-component conditional renders. Card translucency is the only spot where the swap must rebuild a layer; group blurred cards under one wrapper to keep this cheap."
          />
        </Sub>

        <Sub title="Attention hierarchy" hint="what gets bright">
          <SpecTable rows={[
            { name: 'Hero',         value: 'L 0.78 + glow',     note: 'One per screen. Hex radar, calorie ring, level XP — the answer to "what is this screen?"' },
            { name: 'Live',         value: 'Domain hue + pulse', note: 'The single currently-active element (now-block, in-flight quest). Pulse uses motion, not just color.' },
            { name: 'Earned',       value: 'L 0.78 + drop-shadow', note: 'Badges, streaks, completions. Static glow signals "already yours".' },
            { name: 'Reference',    value: 'L 0.62 muted hue',   note: 'Past completions, locked badges, future blocks — present but quiet.' },
            { name: 'Background',   value: 'L 0.18 neutral',     note: 'Surface gradient + aurora orbs at <10% alpha — always behind, never in front.' },
          ]} />
        </Sub>
      </Section>

      {/* ───────────────────────────────────────────────── TYPOGRAPHY */}
      <Section id="type" eyebrow="03 · TYPOGRAPHY" title="Type scale & pairings"
        lede="Two type families do all the work. Nunito (display, headings) brings warmth and approachability; DM Sans (body, UI) brings clarity. JetBrains Mono is reserved for labels, timestamps, and numerals where rhythm matters more than warmth.">

        <Sub title="Families" hint="3 · scoped use">
          <Grid cols={3}>
            <TokenCard
              sample={<div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 36, color: DS.tx, lineHeight: 1 }}>Aa Bb 9</div>}
              name="Nunito" value="display · headings · numerals" sub="700 / 800 / 900 — warmth, never reaches a hard serif. Used for level scores, hero counters, screen titles." />
            <TokenCard
              sample={<div style={{ fontFamily: 'DM Sans', fontWeight: 500, fontSize: 22, color: DS.tx, lineHeight: 1.1 }}>The quick brown fox</div>}
              name="DM Sans" value="body · UI · labels" sub="400 / 500 / 700 — the workhorse. Briefings, helper copy, button labels, list rows." />
            <TokenCard
              sample={<div style={{ fontFamily: 'JetBrains Mono', fontWeight: 500, fontSize: 18, color: DS.tx, letterSpacing: 1 }}>06:30 AM · L7 · +75 XP</div>}
              name="JetBrains Mono" value="labels · numerics · stamps" sub="400 / 500 — timestamps, XP deltas, section eyebrows. Never used for prose." />
          </Grid>
          <Reason
            ux="Three families is the ceiling. Adding a fourth (e.g. a serif for 'AI quote' moods) tempting but breaks the unified voice that makes AI feel like one assistant, not several."
            psych="Nunito's rounded terminals read as 'kind' — exactly what you want narrating someone's life. A geometric sans (Inter, Helvetica) would feel clinical."
            impl="@expo-google-fonts/nunito + dm-sans + jetbrains-mono. Preload all three before the splash dismisses; the FOUT on a hero number is jarring."
          />
        </Sub>

        <Sub title="Type scale" hint="step · 1.18 · 11 → 48">
          <div style={{ borderRadius: 16, border: `1px solid ${DS.border}`, background: DS.card, padding: 14 }}>
            {[
              { token: 'hero',     size: 48, weight: 900, font: 'Nunito',     label: '48 · 900',  usage: 'Onboarding hero · level-up overlay', sample: 'Today is yours' },
              { token: 'display',  size: 38, weight: 900, font: 'Nunito',     label: '38 · 900',  usage: 'Hex radar centerpiece · domain detail score', sample: '78' },
              { token: 'h1',       size: 28, weight: 900, font: 'Nunito',     label: '28 · 900',  usage: 'Tab title · "Today"',           sample: 'Good morning, Arjun' },
              { token: 'h2',       size: 22, weight: 800, font: 'Nunito',     label: '22 · 800',  usage: 'Card hero (Profile name, ring center)', sample: 'Fueling well' },
              { token: 'h3',       size: 18, weight: 800, font: 'Nunito',     label: '18 · 800',  usage: 'Section title (Today\'s flow, Streaks)', sample: 'Today\'s flow' },
              { token: 'body-lg',  size: 16, weight: 700, font: 'Nunito',     label: '16 · 700',  usage: 'Briefing copy · routine block titles', sample: 'Three blocks queued.' },
              { token: 'body',     size: 14, weight: 400, font: 'DM Sans',    label: '14 · 400',  usage: 'Helper copy · descriptions', sample: 'AI recognises foods + macros in 2s.' },
              { token: 'caption',  size: 12, weight: 500, font: 'DM Sans',    label: '12 · 500',  usage: 'Meta · status · chip text', sample: 'on track · 2/3 done' },
              { token: 'micro',    size: 10.5, weight: 500, font: 'JBMono',   label: '10.5 · 500 · 1.6tr', usage: 'Eyebrows · timestamps · XP deltas', sample: 'STREAK · 12d  ·  +20 XP' },
            ].map((t, i) => (
              <div key={t.token} style={{ display: 'grid', gridTemplateColumns: '110px 90px 1fr 1fr', alignItems: 'baseline', padding: '10px 6px', borderTop: i ? `1px solid ${DS.border}` : 'none', gap: 14 }}>
                <Code>{t.token}</Code>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.tx3 }}>{t.label}</div>
                <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: DS.tx2, lineHeight: 1.4 }}>{t.usage}</div>
                <div style={{
                  fontFamily: t.font === 'JBMono' ? 'JetBrains Mono, monospace' : (t.font === 'Nunito' ? 'Nunito, system-ui' : 'DM Sans, system-ui'),
                  fontWeight: t.weight, fontSize: t.size, color: DS.tx, lineHeight: 1.05,
                  letterSpacing: t.font === 'JBMono' ? 1.6 : (t.size > 28 ? -0.5 : 0),
                  textTransform: t.font === 'JBMono' ? 'uppercase' : 'none',
                }}>{t.sample}</div>
              </div>
            ))}
          </div>
          <Reason
            ux="A 9-step scale, geometric ratio ~1.2. Below 11px is forbidden in this product — a life-management app can't ask users to squint at their own data."
            psych="The jump from body (14) to body-lg (16) is small but psychologically loud: 16px copy reads as 'this is the thing'. The briefing card uses it intentionally."
            impl="Tokens emit pixels (RN doesn't do rem). Line-height is a multiplier: 1.05 for display, 1.4 for body, 1.55 for prose blocks. Hardcode line-height in tokens — never let it inherit."
          />
        </Sub>

        <Sub title="Numerals" hint="tabular · always">
          <div style={{
            padding: 18, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`,
            display: 'flex', gap: 24, alignItems: 'center', flexWrap: 'wrap',
          }}>
            <div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 30, fontVariantNumeric: 'tabular-nums', color: DS.tx, lineHeight: 1 }}>1,420<span style={{ color: DS.tx3, fontSize: 14 }}> /2000 kcal</span></div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 30, fontVariantNumeric: 'tabular-nums', color: DS.tx, lineHeight: 1, marginTop: 6 }}>1,389<span style={{ color: DS.tx3, fontSize: 14 }}> /2000 kcal</span></div>
            </div>
            <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13, color: DS.tx2, flex: 1, minWidth: 220, lineHeight: 1.45 }}>
              All numerics ride on <Code>font-variant-numeric: tabular-nums</Code>. A calorie ticking from 1420 to 1389 must not visually shift the layout — otherwise the eye keeps tracking back to confirm.
            </div>
          </div>
          <Reason
            ux="Tabular figures make charts, tables, and counters readable without rendering them as <pre>."
            psych="A jumping number reads as instability. A locked column reads as trust."
            impl="Apply once globally on a <Text variant='numeric'> wrapper or via styled-components/atomic util — never per-component."
          />
        </Sub>
      </Section>

      {/* ───────────────────────────────────────────────── SPACING */}
      <Section id="spacing" eyebrow="04 · SPACING" title="Spacing & layout"
        lede="A 4-pt grid, 7 steps. Everything snaps to it — paddings, gaps, offsets, icon sizes. No 6px, no 18px, no 'just one more pixel'.">

        <Sub title="Scale" hint="4pt base · 7 steps">
          <Grid cols={7} gap={10}>
            {[
              { t: 'xs',   v: 4 },
              { t: 'sm',   v: 8 },
              { t: 'md',   v: 16 },
              { t: 'lg',   v: 24 },
              { t: 'xl',   v: 32 },
              { t: 'xxl',  v: 48 },
              { t: 'xxxl', v: 64 },
            ].map(s => (
              <div key={s.t} style={{
                padding: 12, borderRadius: 12, background: DS.card, border: `1px solid ${DS.border}`,
                display: 'flex', flexDirection: 'column', gap: 8, alignItems: 'flex-start',
              }}>
                <div style={{ width: s.v, height: s.v, background: '#A584FF', borderRadius: 3, boxShadow: '0 0 12px rgba(165,132,255,0.5)' }} />
                <div>
                  <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx }}>{s.t}</div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: DS.tx3 }}>{s.v}px</div>
                </div>
              </div>
            ))}
          </Grid>
          <Reason
            ux="Limited choice = consistent rhythm. A reviewer can spot a non-grid spacing at 100ft."
            psych="The 4pt grid produces 'breathing' rhythms (4 → 8 → 16) that feel physical. Geometric scales (Fibonacci) feel arbitrary in dense UI."
            impl="Token names map to a single integer; consumers compose (paddingX={spacing.md}). Forbid raw numbers in component styles via lint rule."
          />
        </Sub>

        <Sub title="Density modes" hint="3 · user-tweakable">
          <SpecTable rows={[
            { name: 'Compact',   value: '× 0.85', note: 'Pro mode. Routine fits 9 blocks above the fold. Min 13px body. Default on iPad/web tablet.' },
            { name: 'Cozy',      value: '× 1.00', note: 'Default. Routine fits 6 blocks above the fold. The shipping experience.' },
            { name: 'Spacious',  value: '× 1.18', note: 'Headspace mode. Routine fits 4 blocks above the fold. Default for users 55+ or with accessibility settings on.' },
          ]} />
          <Reason
            ux="A density toggle is more honest than '20 different settings'. One dial users can find and trust."
            psych="The same screen at three densities reads as three different emotional postures: 'I'm efficient' / 'I'm steady' / 'I'm relaxed'. Let users self-state."
            impl="Density multiplies only paddings + gaps. Type, radii, icons stay fixed — otherwise compact density turns into 'unreadable' rather than 'efficient'."
          />
        </Sub>

        <Sub title="Layout grid" hint="mobile · 4-col · 24 gutter">
          <Reason
            ux="On mobile (390 portrait) we use a 4-column 24/16 gutter. Hero items span 4. Cards span 4. Two-up rows span 2+2. There is no 'span 3'."
            psych="Even subdivisions feel intentional. The eye rejects 1+3 splits as 'a thing and some stuff'."
            impl="React Native: a Stack composer takes <Cols n=2 /> children at this breakpoint. Web: CSS grid with grid-template-columns: repeat(4, 1fr) and gap: 16."
          />
        </Sub>

        <Sub title="Page padding" hint="screen edge → content">
          <SpecTable rows={[
            { name: 'Phone portrait', value: '20px', note: 'Standard tab screens. Matches iOS list inset perceptually.' },
            { name: 'Phone landscape', value: '32px', note: 'Wider line-length comfort.' },
            { name: 'Modal sheet',    value: '24px', note: 'Slightly more than tab screens — modal feels lifted.' },
            { name: 'Toast / overlay', value: '16px from notch · 20px sides', note: 'Top safe area + 16; never under the notch.' },
          ]} />
        </Sub>
      </Section>

      {/* ───────────────────────────────────────────────── RADII */}
      <Section id="radii" eyebrow="05 · RADII" title="Corner geometry"
        lede="One curve, four sizes. Aurora Glass is recognisable by its consistently soft, slightly-larger-than-expected radii. Sharp corners are reserved for system dividers and the device frame.">
        <Sub title="Scale">
          <Grid cols={5} gap={12}>
            {[
              { t: 'pill',    v: 999, sample: 'chips, streaks, tags' },
              { t: 'card',    v: 22,  sample: 'all content cards' },
              { t: 'control', v: 14,  sample: 'buttons, inputs, FAB' },
              { t: 'tile',    v: 10,  sample: 'small status badges' },
              { t: 'hairline',v: 4,   sample: 'progress bars, dividers' },
            ].map(r => (
              <TokenCard key={r.t}
                sample={<div style={{ width: '100%', height: 56, borderRadius: r.v === 999 ? 28 : r.v, background: 'linear-gradient(135deg, rgba(165,132,255,0.25), rgba(165,132,255,0.05))', border: '1px solid rgba(165,132,255,0.3)' }} />}
                name={r.t} value={`${r.v}px`} sub={r.sample} />
            ))}
          </Grid>
        </Sub>
        <Reason
          ux="Card 22 > button 14 > pill 999 maintains visual containment: pills sit inside cards; buttons inside cards; cards inside the screen."
          psych="Generous radii (>=20 on cards) read as 'soft and trustworthy' — the Headspace-end of the lever. Tight radii (<8) read as 'system and precise' — wrong tone for life data."
          impl="Always set borderRadius and overflow:hidden together when the card contains a glow or gradient. React Native + iOS shadow + overflow:hidden requires a separate shadow wrapper."
        />
      </Section>

      {/* ───────────────────────────────────────────────── ELEVATION */}
      <Section id="elevation" eyebrow="06 · ELEVATION" title="Elevation & shadow"
        lede="Dark-mode depth is built from translucency + glow, not cast shadow. Light-mode is the inverse — soft cast shadows, no glow. Tokens encode both modes; consumers never write a raw box-shadow.">

        <Sub title="Levels" hint="0 / 1 / 2 / 3">
          <Grid cols={4} gap={12}>
            {[
              { l: '0 · ground',  z: 0, sample: 'background canvas, footer band',
                style: {} },
              { l: '1 · card',    z: 1, sample: 'all content cards',
                style: { background: 'rgba(255,255,255,0.045)', border: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(20px)' } },
              { l: '2 · sheet',   z: 2, sample: 'bottom sheet, AI chat',
                style: { background: 'rgba(26,16,40,0.92)', border: '1px solid rgba(255,255,255,0.10)', boxShadow: '0 -20px 60px rgba(0,0,0,0.5)' } },
              { l: '3 · overlay', z: 3, sample: 'level-up, AchievementToast',
                style: { background: 'linear-gradient(135deg, rgba(165,132,255,0.18), rgba(255,214,107,0.10))', border: '1px solid rgba(165,132,255,0.4)', boxShadow: '0 30px 80px rgba(20,8,40,0.6), 0 0 60px rgba(165,132,255,0.4)' } },
            ].map(e => (
              <div key={e.l} style={{ padding: 12, borderRadius: 14, background: DS.card, border: `1px solid ${DS.border}` }}>
                <div style={{ height: 76, borderRadius: 12, ...e.style, display: 'flex', alignItems: 'center', justifyContent: 'center', color: DS.tx, fontFamily: 'Nunito', fontWeight: 800, fontSize: 13 }}>
                  z = {e.z}
                </div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx, marginTop: 8 }}>{e.l}</div>
                <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: DS.tx2, marginTop: 3 }}>{e.sample}</div>
              </div>
            ))}
          </Grid>
        </Sub>

        <Sub title="Glow as elevation" hint="dark mode only">
          <Reason
            ux="In dark mode, a brand-violet glow at 30% alpha reads as 'lifted'. A cast shadow reads as 'a sticker'. Pick glow."
            psych="OLED screens render rgba glow halos perceptually (the eye fills in soft luminance gradients) better than they render hard black shadows (which look like dead pixels)."
            impl="Glow is implemented as a sibling ::before pseudo-element with filter:blur(20px) — not a box-shadow. Box-shadow on RN/Android performs poorly with blur radius >12."
          />
          <CodeBlock language="css/web">{`/* Aurora glow — level 3 only */
.aurora-glow::before {
  content: '';
  position: absolute; inset: -1px;
  border-radius: inherit;
  background: radial-gradient(circle at 50% 0%,
                rgba(165,132,255,0.45), transparent 60%);
  filter: blur(20px);
  pointer-events: none;
  z-index: -1;
}`}</CodeBlock>
        </Sub>
      </Section>
    </>
  );
}

window.Foundations = Foundations;
