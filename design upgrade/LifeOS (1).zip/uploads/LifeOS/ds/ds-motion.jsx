// Motion + animation tokens
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function MotionSection() {
  return (
    <>
      <Section id="motion" eyebrow="07 · MOTION" title="Motion principles & tokens"
        lede="Motion exists to guide attention or confirm action. Everything has a named token; nothing is hand-tuned per component. Two physical motions (springs) and four time-based motions cover every case.">

        <Sub title="Four philosophies" hint="never break these">
          <Grid cols={2} gap={12}>
            <Principle n="M1" color="#FF8C3C" glyph="⚡" title="Tap = spring"
              body="Anything a finger touches answers with a stiffness/damping spring. Time-based animations on tap feel like a recording, not a reaction." />
            <Principle n="M2" color="#7EE0B8" glyph="∼" title="Transition = timing"
              body="Section reveals, opacity changes, screen swaps use timing curves. Springs on layout transitions overshoot and feel chaotic." />
            <Principle n="M3" color="#A584FF" glyph="↗" title="Magnitude matches significance"
              body="A list reorder is 180/22 (tight). A level-up overlay is 120/18 (soft, lingering). A reward toast is 260/24 (snappy, urgent). Magnitude = emotional weight." />
            <Principle n="M4" color="#FF99C5" glyph="✕" title="No motion = a decision"
              body="Loading skeletons don't shimmer unless data is >300ms away. Empty states don't loop. Persistent motion in peripheral vision is the #1 productivity killer." />
          </Grid>
        </Sub>

        <Sub title="Spring tokens" hint="React Native Reanimated">
          <SpecTable rows={[
            { name: 'spring.standard', value: 'stiffness 180 · damping 22', note: 'Default tap. Routine block check, streak log, chip select, list item press.' },
            { name: 'spring.soft',     value: 'stiffness 120 · damping 18', note: 'Large surfaces. Bottom sheet enter, modal scale, hero ring fill.' },
            { name: 'spring.snappy',   value: 'stiffness 260 · damping 24', note: 'Reward beats. XP toast, badge mint, streak save flash. Always paired with a brief sound (if enabled).' },
            { name: 'spring.gentle',   value: 'stiffness 90 · damping 16',  note: 'Breath. Hero radar entry, AI-briefing card morph. Only used once per screen view.' },
          ]} />
          <CodeBlock language="tsx">{`// src/theme/motion.ts
export const SPRING = {
  standard: { stiffness: 180, damping: 22 },
  soft:     { stiffness: 120, damping: 18 },
  snappy:   { stiffness: 260, damping: 24 },
  gentle:   { stiffness:  90, damping: 16 },
} as const;

// Usage with Reanimated
const scale = useSharedValue(1);
const onPressIn  = () => { scale.value = withSpring(0.96, SPRING.standard); };
const onPressOut = () => { scale.value = withSpring(1,    SPRING.standard); };`}</CodeBlock>
        </Sub>

        <Sub title="Timing tokens" hint="ms · easing">
          <SpecTable rows={[
            { name: 'timing.fast',   value: '150ms · ease-out',          note: 'Tap feedback, hover-on (web). Background tint shifts.' },
            { name: 'timing.normal', value: '300ms · cubic [.4,0,.2,1]', note: 'Tab swap, screen push, sheet fade. The "standard transition".' },
            { name: 'timing.slow',   value: '600ms · cubic [.2,.7,.3,1]',note: 'Hero entry (FadeInDown stagger), AI-briefing reveal. Headspace breath beat.' },
            { name: 'timing.epic',   value: '1200ms · cubic + bounce',   note: 'Level-up confetti, badge mint sequence. Reserved.' },
          ]} />
          <Reason
            ux="Fast (150) feels instant, Normal (300) feels considered, Slow (600) feels deliberate. Anything between is mush."
            psych="600ms is the limit of perceived 'flow' — past that, users sense waiting. Reserve epic timings for moments users are happy to wait through (rewards)."
            impl="Tokens emit { duration, easing } objects compatible with both Reanimated withTiming and CSS transition shorthand. No raw ms values in code."
          />
        </Sub>

        <Sub title="Stagger & rhythm" hint="entrance choreography">
          <SpecTable rows={[
            { name: 'List entry',     value: 'item N delay = N × 40ms (cap 6)', note: 'Routine blocks, transaction rows, badge grid. Past 6 items, the rest enter instantly to avoid waiting.' },
            { name: 'Section reveal', value: 'section N delay = N × 100ms',     note: 'Today screen sections fade in top-to-bottom on first paint. After first paint, no re-stagger on data update.' },
            { name: 'Hero settle',    value: 'delay 200ms · timing.slow',       note: 'Hex radar polygon morphs to today\'s shape after avatar lands.' },
            { name: 'Reward chain',   value: 'XP → ring → toast → (badge)',     note: 'Awards always stagger 250ms apart so users can read each beat. Never bundle into one flash.' },
          ]} />
          <Reason
            ux="Stagger turns a wall of cards into a sequence; a sequence is easier to read."
            psych="The 40ms inter-item delay matches the saccade rhythm of natural reading — UI 'reads itself' to the user without rushing."
            impl="Use Reanimated FadeInDown.delay(idx * 40) capped via Math.min(idx, 5). On data refresh, mark items with stable keys so React doesn't replay the entry."
          />
        </Sub>

        <Sub title="Reward moment system" hint="celebration choreography">
          <div style={{
            padding: 18, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`,
            display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 12,
          }}>
            {[
              { t: '0ms',     l: 'Trigger', sub: 'User completes action', c: '#A584FF' },
              { t: '80ms',    l: 'Haptic', sub: 'iOS impactLight / Android medium', c: '#FF99C5' },
              { t: '120ms',   l: 'Source flash', sub: 'Element borders glow domain hue', c: '#7EE0B8' },
              { t: '250ms',   l: 'XP chip flies', sub: 'Chip rises 24px → fades to XP rail', c: '#FFD66B' },
              { t: '500ms',   l: 'XP rail pulse', sub: 'Bar fills + 1 frame brightness pop', c: '#A584FF' },
              { t: '750ms',   l: 'Streak save?', sub: 'If applicable: flame intensifies', c: '#FF8C3C' },
              { t: '1000ms',  l: 'Badge?', sub: 'If unlocked: corner toast spring in', c: '#C5B3FF' },
              { t: '1500ms',  l: 'Level up?', sub: 'If crossing: full-screen overlay', c: '#FFD66B' },
            ].map((s, i) => (
              <div key={i} style={{ padding: 12, borderRadius: 12, background: 'rgba(255,255,255,0.025)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: s.c, letterSpacing: 1 }}>{s.t}</div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx, marginTop: 4 }}>{s.l}</div>
                <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11.5, color: DS.tx2, marginTop: 3, lineHeight: 1.4 }}>{s.sub}</div>
              </div>
            ))}
          </div>
          <Reason
            ux="The reward sequence resolves left-to-right and never piles up. A user can interrupt mid-sequence (tap another block) without breaking the queue — pending rewards drain into the rail."
            psych="Spaced-out rewards (vs. one super-burst) extend the dopamine moment by ~400ms — measurably increases self-reported satisfaction without being manipulative because each beat reflects real progress."
            impl="Reward queue is a Zustand store with `pending: Reward[]`. A scheduler drains it 250ms apart. Replay never; if app backgrounds, drain instantly on resume so rewards don't surprise users out of context."
          />
        </Sub>

        <Sub title="Motion intensity (user preference)" hint="user-tweakable · respects reduce-motion">
          <SpecTable rows={[
            { name: 'Off',    value: '× 0', note: 'No motion. Reward sequence collapses to a single flash. Honors prefers-reduced-motion automatically.' },
            { name: 'Subtle', value: '× 0.5', note: 'Halved spring stiffness, doubled damping, half-stagger. Recommended for users 65+ or with vestibular sensitivity.' },
            { name: 'Normal', value: '× 1.0', note: 'Default. The shipping experience.' },
            { name: 'Bold',   value: '× 1.4', note: 'Snappier springs, longer staggers, fuller reward chain. For users who told us "I love feedback".' },
          ]} />
          <Reason
            ux="Motion is the most polarizing design choice. A user-controlled dial preempts the entire debate."
            psych="prefers-reduced-motion isn't a special case — it's a real preference held by ~7% of users. Honor it by default, expose the dial for everyone else."
            impl="A motion multiplier is read by a Reanimated useDerivedValue scaling all spring/timing tokens before withSpring. Toggle reflects in real time, no relaunch needed."
          />
        </Sub>

        <Sub title="What never moves" hint="discipline list">
          <SpecTable rows={[
            { name: 'Background gradients',  value: 'static', note: 'Aurora orbs are baked. Animated gradients drain battery and pull attention with no payoff.' },
            { name: 'Numeric counters',      value: 'static', note: 'Don\'t roll the calorie count from 1420 to 1432. Snap. (Exception: XP rail in the reward sequence.)' },
            { name: 'List rows mid-data',    value: 'static', note: 'Once a transaction renders, it never re-animates. Re-animation reads as a glitch.' },
            { name: 'Tab bar',               value: 'static', note: 'The dock is the anchor. Animating it makes the screen feel like it\'s drifting.' },
            { name: 'Skeletons under 300ms', value: 'static', note: 'If data lands in <300ms, render a solid placeholder. Shimmer only when wait is real.' },
          ]} />
        </Sub>
      </Section>
    </>
  );
}

window.MotionSection = MotionSection;
