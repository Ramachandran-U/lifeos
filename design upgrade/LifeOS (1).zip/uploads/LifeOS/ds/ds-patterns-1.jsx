// Interaction patterns, gestures, haptics
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function PatternsInteraction() {
  return (
    <Section id="patterns" eyebrow="11 · PATTERNS" title="Interaction patterns"
      lede="Patterns are how molecules behave under user touch. Each pattern is a contract: any component using it inherits the same behaviour, copy and feedback rules.">

      <Sub title="One-tap log" hint="streaks · food · routine blocks">
        <Reason
          ux="The single most-frequent action in the app is 'I did the thing'. It must be reachable in one tap from any surface and confirmed in <200ms."
          psych="Friction at the moment of completion is what kills habit apps. The user just earned something — don't make them tap twice."
          impl="<OneTapLog kind='streak' streakKey='workout' /> wraps optimistic UI + haptic + XP queue. Calling code never writes to the DB directly."
        />
      </Sub>

      <Sub title="Long-press menu" hint="routine block · transaction · meal">
        <Reason
          ux="Long-press (400ms) reveals a contextual menu: edit, reschedule, delete, mark-private. Never the primary action — that's a tap."
          psych="Long-press is power-user territory. Surface a hint after 1500ms of first hover on web, never on mobile (discoverable via the kebab menu)."
          impl="useLongPress hook returns { onLongPress, isPressing } so the press feedback (scale 0.97 + tint) is shared with regular tap."
        />
      </Sub>

      <Sub title="Swipe right = complete · left = skip" hint="routine timeline only">
        <Reason
          ux="On the routine timeline, swipe right marks the block done; swipe left marks skipped (no XP, no streak penalty). 80px threshold + spring snap-back if released early."
          psych="A skip is a valid life event. The app must give users a 'I'm not doing this and that's fine' option that doesn't feel like failure."
          impl="React Native Gesture Handler PanGestureHandler with snap thresholds. Reduce-motion users get explicit buttons instead of the swipe."
        />
      </Sub>

      <Sub title="Pull-to-AI" hint="Today screen only">
        <Reason
          ux="Pull down on Today past 120px triggers 'Ask LifeOS' — overlay opens to voice mode. Standard pull-to-refresh under 120px stays."
          psych="Two pull thresholds = two intents. Light pull means 'I'm checking', deep pull means 'I'm asking'. Discoverable via a hint tooltip on first 3 sessions."
          impl="Single PanGesture with two threshold callbacks. The 'AI' label fades in at 80px and locks at 120px."
        />
      </Sub>
    </Section>
  );
}

window.PatternsInteraction = PatternsInteraction;
