// Components + states + iconography
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function ComponentsSection() {
  return (
    <>
      {/* ───────────────────────────────────────────────── COMPONENT PHILOSOPHY */}
      <Section id="components" eyebrow="08 · COMPONENTS" title="Component philosophy"
        lede="Atoms compose into molecules compose into organisms. Each level has stricter constraints. Atoms have ~3 props; molecules have ~7; organisms own their layout and consume context. Every component renders only what it owns — never paints into adjacent space.">

        <Sub title="Three layers" hint="atomic → composed → contextual">
          <Grid cols={3} gap={12}>
            <Principle n="L1" color="#7EE0B8" glyph="◇" title="Atoms"
              body="Stateless. Pure props in, pixels out. Examples: Text, Pill, Glyph, Icon, AvatarRing, XpBar, FlameIcon. ~20 atoms total." />
            <Principle n="L2" color="#7FB8FF" glyph="◈" title="Molecules"
              body="Compose atoms; manage local state (hover, press). Examples: RoutineBlock, StreakCard, QuestCard, TransactionRow, MetricCard. ~25 molecules." />
            <Principle n="L3" color="#A584FF" glyph="✦" title="Organisms"
              body="Compose molecules; consume stores, navigate. Examples: HexRadarHero, RoutineTimeline, RewardsGrid, FinanceTransactionList. Tied to screens." />
          </Grid>
          <Reason
            ux="Predictable depth = predictable behavior. A reviewer can guess what a component will do from its layer alone."
            psych="Designers and engineers share a vocabulary. 'It's a molecule' is a debug-able statement."
            impl="src/components/{atoms,molecules,organisms}. Lint rule: atoms can't import stores; molecules can't import navigation. CI fails on inversion."
          />
        </Sub>

        <Sub title="Component inventory" hint="ship list">
          <SpecTable rows={[
            { name: 'Text · Heading',  value: 'atom · 9 sizes', note: 'Wraps Nunito + DM Sans + JBMono families and tokenized sizes. No raw font props in calling code.' },
            { name: 'Pill',            value: 'atom · 3 tones', note: 'Default · accent · dim. Holds a glyph + optional value. Used as DomainChip, StatusChip, AIChip.' },
            { name: 'Glyph',           value: 'atom · 6 hues',  note: 'Single character (◆♥◈▲●✦) at one of 4 sizes. Used wherever a domain is referenced.' },
            { name: 'AvatarRing',      value: 'atom',           note: 'Initials + level chip + progress arc. Two sizes (48 nav, 80 hero).' },
            { name: 'XpBar',           value: 'atom',           note: 'Width-pct + glow. Two heights (5, 7). Animates on award only.' },
            { name: 'StreakFlame',     value: 'atom',           note: 'Flame icon + count. Dim variant for not-started streaks.' },
            { name: 'FAB',             value: 'atom',           note: 'Single floating action (voice mic). 40×40 glass pill.' },
            { name: 'GlassCard',       value: 'molecule',       note: 'The universal container. Accent prop adds a left border and a top-left glow.' },
            { name: 'RoutineBlock',    value: 'molecule',       note: 'Time + title + module glyph + status circle. Live variant has pulse.' },
            { name: 'StreakCard',      value: 'molecule',       note: 'Flame + label + count + best-ribbon. Tappable for one-shot log.' },
            { name: 'QuestCard',       value: 'molecule',       note: 'Progress bar + XP chip + period badge. Done variant fills card with hue.' },
            { name: 'TransactionRow',  value: 'molecule',       note: 'Merchant + cat + amount + bank. Income vs spend tinted differently.' },
            { name: 'MealRow',         value: 'molecule',       note: 'Emoji + name + macros + chevron. Soft Headspace list style.' },
            { name: 'BadgeTile',       value: 'molecule',       note: 'Square glow tile. Earned vs locked variants. Tap → modal.' },
            { name: 'DailyBriefing',   value: 'molecule',       note: 'AI sigil + briefing copy + chip row. Always the first content card on Today.' },
            { name: 'MetricCard',      value: 'molecule',       note: 'Eyebrow + big numeral + delta. 3-up grid uses these.' },
            { name: 'HexRadar',        value: 'organism',       note: 'Hero radar with 3 variants (web/orbit/crown). Tap on a vertex zooms into that domain.' },
            { name: 'CalorieRing',     value: 'organism',       note: '4-segment concentric ring with center stats. Health screen hero.' },
            { name: 'RoutineTimeline', value: 'organism',       note: 'Sorted list of RoutineBlock with current-time indicator and edit affordance.' },
            { name: 'RewardsGrid',     value: 'organism',       note: 'Streaks + Quests + Badges + XP rail layout. Owns scrolling.' },
            { name: 'VoiceSheet',      value: 'organism',       note: 'Full-screen bottom sheet with waveform + transcript + close.' },
            { name: 'TabBar',          value: 'organism',       note: 'Glass pill dock. 5 destinations, glow on active.' },
          ]} />
        </Sub>
      </Section>

      {/* ───────────────────────────────────────────────── STATES */}
      <Section id="states" eyebrow="09 · STATES" title="Component states"
        lede="Every interactive component implements all eight states. Stateless components implement none. There is no in-between.">

        <Sub title="The eight states" hint="rest · hover · press · focus · loading · disabled · success · error">
          <ButtonStateMatrix />
          <Reason
            ux="A user must always know what state a control is in. The most common failure: 'is the button loading or did my tap not register?'"
            psych="Pressed states with visible ack (scale down + haptic) build trust faster than any other UI choice. Users learn the app is responsive in the first 5 taps."
            impl="State variants live as discriminated unions in props (state: 'rest' | 'loading' | 'success' | 'error'). Hover/press are managed by Pressable; focus by the platform."
          />
        </Sub>

        <Sub title="Input states" hint="text · select">
          <InputStateMatrix />
        </Sub>

        <Sub title="Card / row states" hint="rest · hover · press · selected · live · done · dim">
          <CardStateMatrix />
          <Reason
            ux="Cards have 7 visual states because they're the most-touched surface in the app. Rest, hover (web), press (mobile), selected (multi-select), live (active block now), done (completed), dim (locked/skipped)."
            psych="The 'done' state must feel earned, not dead. Strikethrough + 55% opacity reads as 'past you did this' — not 'this is gone'."
            impl="A useCardState() hook returns the visual props for a card given its semantic state. Saves us from N×7 style sheets."
          />
        </Sub>

        <Sub title="Loading patterns" hint="<300ms = nothing · ≥300ms = skeleton · ≥3s = inline reason">
          <SpecTable rows={[
            { name: 'Instant',           value: '< 300ms',   note: 'No skeleton. Show the previous state until data lands. Skeletons here register as flicker.' },
            { name: 'Skeleton block',    value: '300ms – 3s', note: 'Shape-matched rectangles + faint shimmer. Skeleton matches final layout to avoid layout-shift.' },
            { name: 'Inline AI reason',  value: '3s – 15s',  note: 'For AI calls. "Synthesising your week…" + spinning ✦. Reuse this exact copy across screens.' },
            { name: 'Optimistic update', value: 'always',     note: 'Routine block check, XP award, meal log render before the DB write returns. Roll back on failure with a soft toast.' },
          ]} />
        </Sub>

        <Sub title="Empty states" hint="never just 'nothing here'">
          <EmptyStateMatrix />
          <Reason
            ux="Empty states are the most underused conversion surface in apps. Each one is a chance to teach: what is this place, what does it become full of, what's one step to start."
            psych="A blank space reads as broken. A space with a glyph + a single CTA reads as 'I'm new, not empty'."
            impl="Empty-state copy lives in src/copy/empty.ts with screen-specific keys. CTAs are real navigation actions, not dummy buttons."
          />
        </Sub>
      </Section>

      {/* ───────────────────────────────────────────────── ICONOGRAPHY */}
      <Section id="iconography" eyebrow="10 · ICONOGRAPHY" title="Glyph & icon system"
        lede="The product has two icon vocabularies, used by strict rule. Domain glyphs (◆♥◈▲●✦) are the soul; line icons (Ionicons) are the chrome. Never blend them in the same context.">

        <Sub title="Domain glyphs" hint="unicode · 6 · semantic">
          <Grid cols={6} gap={10}>
            {[
              { g: '◆', l: 'Goals',    c: '#C9A0FF', cp: 'U+25C6' },
              { g: '♥', l: 'Health',   c: '#7EE0B8', cp: 'U+2665' },
              { g: '◈', l: 'Money',    c: '#F4C16A', cp: 'U+25C8' },
              { g: '▲', l: 'Career',   c: '#7FB8FF', cp: 'U+25B2' },
              { g: '●', l: 'Social',   c: '#FF99C5', cp: 'U+25CF' },
              { g: '✦', l: 'Mind/AI',  c: '#FFD66B', cp: 'U+2726' },
            ].map(d => (
              <TokenCard key={d.l}
                sample={<div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 36, color: d.c, lineHeight: 1, filter: `drop-shadow(0 0 12px ${d.c}66)` }}>{d.g}</div>}
                name={d.l} value={d.cp} sub="" />
            ))}
          </Grid>
          <Reason
            ux="Six glyphs the user memorises in week 1. After that, the app never needs to label a domain — the glyph is sufficient."
            psych="Symbols are pre-linguistic. They carry meaning faster than any word — by week 2, users see ♥ and feel 'health' without reading."
            impl="Unicode means no asset pipeline, no font fallback, no licensing. They render identically across iOS/Android/web. Always render through Glyph component so size + hue stay locked."
          />
        </Sub>

        <Sub title="Glyph dual-use: AI sigil" hint="✦ is overloaded by design">
          <div style={{ padding: 18, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`, display: 'flex', gap: 18, alignItems: 'center' }}>
            <div style={{
              fontFamily: 'Nunito', fontWeight: 900, fontSize: 56, color: '#FFD66B', lineHeight: 1,
              filter: 'drop-shadow(0 0 16px rgba(255,214,107,0.6))',
            }}>✦</div>
            <div style={{ flex: 1 }}>
              <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 16, color: DS.tx }}>The Polymath glyph IS the AI sigil</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13.5, color: DS.tx2, marginTop: 6, lineHeight: 1.5 }}>
                Mind = AI = curiosity. The product treats them as one thing. Daily Briefing, Weekly Insight, AI Blood Report, Spending Alert, Routine Generation — all carry the ✦ sigil with a violet halo. One assistant, six lenses.
              </div>
            </div>
          </div>
          <Reason
            ux="A user should never wonder 'is this the AI talking?'. The sigil is the unmistakable signal."
            psych="Folding AI into 'mind' subtly positions the assistant as augmentation rather than authority — the user's own curiosity, externalised."
            impl="A <AISignal /> component wraps the glyph with the standard violet halo. Use it anywhere an AI-generated string appears."
          />
        </Sub>

        <Sub title="Line icons" hint="Ionicons · stroke 1.5 · system chrome">
          <SpecTable rows={[
            { name: 'Library',         value: 'Ionicons',           note: 'Single source. Never mix with Material/Feather/etc.' },
            { name: 'Stroke width',    value: '1.5px (outline)',    note: 'Lighter than default 2px to harmonise with the soft Aurora aesthetic.' },
            { name: 'Sizes',           value: '14 / 18 / 22 / 28',  note: 'Discrete. 14 inline with body, 18 in chip + tab, 22 in card, 28 in hero.' },
            { name: 'Color',           value: 'currentColor',       note: 'Always inherits — never set explicit fill in JSX. Theme + state decide.' },
            { name: 'Forbidden',       value: 'filled · custom',    note: 'No filled variants. No hand-drawn one-off icons. Need a custom symbol? Use a glyph.' },
          ]} />
          <Reason
            ux="Outline icons + glyph symbols create a clean visual rhythm: chrome is line, content is glyph."
            psych="Mixed icon styles (some filled, some outline, some custom SVG) signal an amateur app. Strict library use signals discipline."
            impl="Wrap Ionicons in <Icon name=… size=… /> with theme-aware color. Strip any direct @expo/vector-icons import elsewhere via ESLint."
          />
        </Sub>

        <Sub title="Numerals as icons" hint="big numbers ARE icons">
          <div style={{ padding: 18, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}` }}>
            <div style={{ display: 'flex', gap: 32, alignItems: 'center', flexWrap: 'wrap' }}>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 64, color: DS.tx, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>67</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 64, color: '#FF8C3C', lineHeight: 1, fontVariantNumeric: 'tabular-nums', textShadow: '0 0 24px rgba(255,140,60,0.4)' }}>47</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 64, color: '#FFD66B', lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}>L7</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13.5, color: DS.tx2, flex: 1, minWidth: 200, lineHeight: 1.5 }}>
                Life Balance avg, Streak count, Level — these numbers are the screen's primary identity glyph. Treated with the same care as icon design: tabular figures, semantic colour, optional glow, never abbreviated.
              </div>
            </div>
          </div>
        </Sub>
      </Section>
    </>
  );
}

// ── Button state demo ────────────────────────────────────────────────────
function ButtonStateMatrix() {
  const Btn = ({ state, label }) => {
    const map = {
      rest:    { bg: DS.primary, fg: '#0A0612', op: 1, scale: 1, glow: true },
      hover:   { bg: DS.primaryHi, fg: '#0A0612', op: 1, scale: 1, glow: true },
      press:   { bg: DS.primary, fg: '#0A0612', op: 1, scale: 0.96, glow: false },
      focus:   { bg: DS.primary, fg: '#0A0612', op: 1, scale: 1, ring: true },
      loading: { bg: DS.primary, fg: '#0A0612', op: 1, scale: 1, glow: true, spin: true },
      disabled:{ bg: 'rgba(255,255,255,0.06)', fg: DS.tx3, op: 0.6, scale: 1 },
      success: { bg: '#31E0A3', fg: '#0A1F18', op: 1, scale: 1, glow: true, check: true },
      error:   { bg: '#FF5577', fg: '#2A0610', op: 1, scale: 1, glow: true, shake: true },
    }[state];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8 }}>
        <div style={{
          padding: '10px 18px', borderRadius: 14,
          background: map.bg, color: map.fg, opacity: map.op,
          fontFamily: 'Nunito', fontWeight: 900, fontSize: 13,
          transform: `scale(${map.scale})`,
          boxShadow: map.glow ? '0 0 16px rgba(165,132,255,0.45)' : 'none',
          outline: map.ring ? '2px solid #C5B3FF' : 'none', outlineOffset: 3,
          display: 'flex', alignItems: 'center', gap: 6,
        }}>
          {map.spin && <span style={{ display: 'inline-block', width: 12, height: 12, borderRadius: 6, border: `2px solid ${map.fg}33`, borderTopColor: map.fg, animation: 'spin 0.8s linear infinite' }} />}
          {map.check && <span>✓</span>}
          {label}
        </div>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 0.8 }}>{state.toUpperCase()}</div>
      </div>
    );
  };
  return (
    <>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      <div style={{
        padding: 24, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`,
        display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20,
      }}>
        <Btn state="rest"     label="Sync now" />
        <Btn state="hover"    label="Sync now" />
        <Btn state="press"    label="Sync now" />
        <Btn state="focus"    label="Sync now" />
        <Btn state="loading"  label="Syncing…" />
        <Btn state="disabled" label="Sync now" />
        <Btn state="success"  label="Synced" />
        <Btn state="error"    label="Failed" />
      </div>
    </>
  );
}

// ── Input state demo ─────────────────────────────────────────────────────
function InputStateMatrix() {
  const Input = ({ state, value, hint }) => {
    const map = {
      rest:    { bd: DS.border, bg: 'rgba(255,255,255,0.025)', hint: DS.tx3 },
      focus:   { bd: DS.primary, bg: 'rgba(165,132,255,0.08)', hint: DS.primaryHi, glow: true },
      filled:  { bd: DS.borderHi, bg: 'rgba(255,255,255,0.04)', hint: DS.tx2 },
      error:   { bd: '#FF5577', bg: 'rgba(255,85,119,0.08)', hint: '#FF5577' },
      disabled:{ bd: DS.border, bg: 'rgba(255,255,255,0.015)', hint: DS.tx3, op: 0.5 },
    }[state];
    return (
      <div style={{ flex: 1, opacity: map.op || 1 }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 1, marginBottom: 6 }}>{state.toUpperCase()}</div>
        <div style={{
          padding: '12px 14px', borderRadius: 12,
          background: map.bg, border: `1px solid ${map.bd}`,
          boxShadow: map.glow ? '0 0 16px rgba(165,132,255,0.25)' : 'none',
          fontFamily: 'DM Sans, system-ui', fontSize: 14, color: DS.tx,
        }}>{value || <span style={{ color: DS.tx3 }}>Enter your goal…</span>}</div>
        <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11.5, color: map.hint, marginTop: 5 }}>{hint}</div>
      </div>
    );
  };
  return (
    <div style={{ padding: 20, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`, display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14 }}>
      <Input state="rest"     value=""                hint="A one-line vision works best." />
      <Input state="focus"    value="Move to Mumbai"  hint="Looking good." />
      <Input state="filled"   value="Move to Mumbai"  hint="34 chars." />
      <Input state="error"    value="x"               hint="Too short — try a full sentence." />
      <Input state="disabled" value="Locked"          hint="Edit blocked while AI is planning." />
    </div>
  );
}

// ── Card state demo ──────────────────────────────────────────────────────
function CardStateMatrix() {
  const Card = ({ state }) => {
    const m = {
      rest:    { bg: 'rgba(255,255,255,0.045)', bd: DS.border, op: 1, glow: false },
      hover:   { bg: 'rgba(255,255,255,0.07)',  bd: DS.borderHi, op: 1 },
      press:   { bg: 'rgba(255,255,255,0.05)',  bd: DS.borderHi, op: 1, scale: 0.985 },
      selected:{ bg: 'rgba(165,132,255,0.12)',  bd: '#A584FF', op: 1, glow: true },
      live:    { bg: 'linear-gradient(135deg, rgba(165,132,255,0.18), rgba(165,132,255,0.04))', bd: '#A584FF66', op: 1, pulse: true },
      done:    { bg: 'rgba(255,255,255,0.025)', bd: DS.border, op: 0.55, strike: true },
      dim:     { bg: 'rgba(255,255,255,0.015)', bd: DS.border, op: 0.4 },
    }[state];
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 1 }}>{state.toUpperCase()}</div>
        <div style={{
          padding: '12px 14px', borderRadius: 16,
          background: m.bg, border: `1px solid ${m.bd}`,
          opacity: m.op, transform: m.scale ? `scale(${m.scale})` : undefined,
          boxShadow: m.glow ? '0 0 24px rgba(165,132,255,0.3)' : 'none',
          display: 'flex', alignItems: 'center', gap: 10,
          position: 'relative', overflow: 'hidden',
        }}>
          {m.pulse && <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: '#A584FF', boxShadow: '0 0 12px #A584FF' }} />}
          <div style={{ width: 28, height: 28, borderRadius: 9, background: 'rgba(165,132,255,0.18)', border: '1px solid rgba(165,132,255,0.4)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#C9A0FF', fontFamily: 'Nunito', fontWeight: 900, fontSize: 13 }}>◆</div>
          <div style={{ flex: 1 }}>
            <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx, textDecoration: m.strike ? 'line-through' : 'none' }}>Deep work — Spec</div>
            <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: DS.tx3, marginTop: 2 }}>09:00 – 11:30{state === 'live' && <span style={{ color: '#A584FF', marginLeft: 6 }}>● NOW</span>}</div>
          </div>
        </div>
      </div>
    );
  };
  return (
    <div style={{ padding: 20, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`, display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 }}>
      <Card state="rest" />
      <Card state="hover" />
      <Card state="press" />
      <Card state="selected" />
      <Card state="live" />
      <Card state="done" />
      <Card state="dim" />
    </div>
  );
}

// ── Empty state demo ─────────────────────────────────────────────────────
function EmptyStateMatrix() {
  const Empty = ({ icon, title, body, cta, hue }) => (
    <div style={{
      padding: 24, borderRadius: 16,
      background: `linear-gradient(180deg, ${hue}10, transparent)`,
      border: `1px solid ${hue}33`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, textAlign: 'center',
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 18,
        background: `${hue}22`, border: `1px solid ${hue}55`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color: hue, fontFamily: 'Nunito', fontWeight: 900, fontSize: 28,
      }}>{icon}</div>
      <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 16, color: DS.tx }}>{title}</div>
      <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: DS.tx2, maxWidth: 220, lineHeight: 1.5 }}>{body}</div>
      <div style={{ marginTop: 4, padding: '8px 14px', borderRadius: 12, background: hue, color: '#0A0612', fontFamily: 'Nunito', fontWeight: 900, fontSize: 12 }}>{cta}</div>
    </div>
  );
  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
      <Empty icon="♥" hue="#7EE0B8" title="No meals logged yet"
        body="Snap your first meal — AI does the macros in 2s."
        cta="OPEN CAMERA" />
      <Empty icon="◈" hue="#F4C16A" title="No transactions ingested"
        body="Connect Gmail and we'll auto-tag every bank email going forward."
        cta="CONNECT GMAIL" />
      <Empty icon="✦" hue="#FFD66B" title="No quests today"
        body="Pick 2 quick wins or let the AI propose 3 based on your routine."
        cta="GENERATE QUESTS" />
    </div>
  );
}

window.ComponentsSection = ComponentsSection;
