// Gamification visual language
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function PatternsGamification() {
  return (
    <Section id="gamification" eyebrow="17 · GAMIFICATION" title="Gamification visual language"
      lede="The gamification layer is the difference between a tool and a habit. Every visual decision here serves one rule: celebrate progress without manipulating it. Six visual primitives carry the whole system.">

      <Sub title="The six visual primitives">
        <Grid cols={3} gap={12}>
          {[
            { glyph: 'L7', l: 'Level', body: 'A numeric identity. Big, bright, on the avatar ring and the rewards hero. Gold accent always.', c: '#FFD66B' },
            { glyph: 'XP', l: 'XP rail', body: 'A horizontal violet→gold bar that fills with the user\'s progress to the next level. Glows on award.', c: '#A584FF' },
            { glyph: '🔥', l: 'Streak flame', body: 'A literal gradient flame with the count. Dim when not started, bright when active, supernova at personal best.', c: '#FF8C3C' },
            { glyph: '✦', l: 'Badge', body: 'A square glow tile with the badge glyph + name. Earned: hue glow. Locked: 40% opacity outline only.', c: '#C5B3FF' },
            { glyph: '◆', l: 'Quest progress', body: 'A domain-hued bar with N/M numerator. Done quests flood the card with hue at 33%.', c: '#7EE0B8' },
            { glyph: '⬢', l: 'Life Balance hex', body: 'The six-vertex radar. Hero on Today, mini on Profile. Each vertex carries a domain hue.', c: '#7FB8FF' },
          ].map(p => (
            <div key={p.l} style={{
              padding: 16, borderRadius: 16,
              background: `linear-gradient(135deg, ${p.c}10, transparent)`,
              border: `1px solid ${p.c}33`,
            }}>
              <div style={{
                width: 44, height: 44, borderRadius: 14, marginBottom: 10,
                background: `${p.c}1F`, border: `1px solid ${p.c}55`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: p.c, fontFamily: 'Nunito', fontWeight: 900, fontSize: 17,
              }}>{p.glyph}</div>
              <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 15, color: DS.tx }}>{p.l}</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: DS.tx2, marginTop: 6, lineHeight: 1.5 }}>{p.body}</div>
            </div>
          ))}
        </Grid>
      </Sub>

      <Sub title="Streak design rules" hint="the most psychologically loaded primitive">
        <SpecTable rows={[
          { name: 'Brightness ∝ days',    value: 'log scale',           note: 'A 30-day flame is visibly more luminous than a 3-day, but not 10× — log scale prevents the 100-day flame from being unreachable.' },
          { name: 'Personal best ribbon', value: 'gold pill · text "PERSONAL BEST"', note: 'Appears only when current count equals or exceeds historical max. Earns its own micro-haptic.' },
          { name: 'Grace day language',   value: '"1 save available"',  note: 'Never "missed". A grace day used: "Saved by your grace day — back tomorrow".' },
          { name: 'Streak dies softly',   value: 'flame goes greyscale · count → 0', note: 'No red. No flashing. The user feels the loss without being punished.' },
          { name: 'Re-start celebration', value: 'first re-log after break = +50 XP bonus', note: 'Restarting is harder than continuing. Reward it bigger.' },
        ]} />
        <Reason
          ux="Streak design is where habit apps cross into manipulation. Our rule: a streak loss is a fact, not a failure. The flame doesn't burn the user."
          psych="Loss aversion is what makes streaks work; punishment is what makes them addictive. We exploit loss aversion (the count visibly drops) and refuse punishment (no red, no shame copy)."
          impl="Streak rendering passes through useStreakVisual({ count, history, grace }) so the same component handles every variant. Never style streak chips ad-hoc."
        />
      </Sub>

      <Sub title="Level-up moment" hint="the loudest celebration in the app">
        <Reason
          ux="A full-screen overlay with the new level numeral large, the unlocked-things list small, a single 'Continue' button. Auto-dismisses after 6s if no interaction."
          psych="The level-up moment is the closest thing to a 'win condition' the app has. Make it count, but don't extend it. The user came here to live their life — get them back."
          impl="Overlay component renders via a Zustand reward queue. Confetti is SVG particle-emitted via Skia (native) / canvas (web). Sound is a single soft chord (~280ms) — never long."
        />
      </Sub>

      <Sub title="Badge design rules">
        <SpecTable rows={[
          { name: 'One glyph each',     value: 'no custom illustrations',  note: 'Badges reuse domain glyphs (◆♥◈▲●✦) + a hue. Cheaper to design, faster for users to recognise.' },
          { name: 'Locked = outline',   value: '40% opacity',              note: 'Locked badges visible but quiet. Users can see what they\'re working toward — psychological pull.' },
          { name: 'Earned = full',      value: 'hue glow',                 note: 'Drops shadow + hue tint. Tap → detail modal with date + context ("Earned by uploading first blood report on March 28").' },
          { name: 'No "next badge tease"', value: '—',                      note: 'We do NOT show "you\'re close to X". That\'s manipulative. We show all 8 always; the user infers their own next.' },
        ]} />
      </Sub>

      <Sub title="Honest gamification — what we won't do">
        <div style={{
          padding: 18, borderRadius: 16,
          background: 'rgba(255,85,119,0.06)',
          border: '1px solid rgba(255,85,119,0.25)',
        }}>
          <div style={{ fontFamily: 'Nunito', fontWeight: 900, fontSize: 15, color: '#FF5577', marginBottom: 10 }}>Dark patterns banned by policy</div>
          <ul style={{ paddingLeft: 18, margin: 0, fontFamily: 'DM Sans, system-ui', fontSize: 14, color: DS.tx, lineHeight: 1.7 }}>
            <li>No "your streak ends in 2 hours" panic notifications.</li>
            <li>No fake friend activity ("3 friends just earned this badge").</li>
            <li>No artificial scarcity / limited-time quests.</li>
            <li>No XP for opening the app or scrolling. XP rewards behaviour, not attention.</li>
            <li>No leaderboards (Phase 1). Comparison turns life-management into anxiety.</li>
            <li>No paid streak revival. Streaks are about life, not money.</li>
          </ul>
        </div>
        <Reason
          ux="Gamification done badly is the #1 review-1-star reason for habit apps. We pre-commit to what we won't do so the engineering team can push back on PMs."
          psych="The product's North Star is healthy momentum. Every banned pattern would create unhealthy momentum — short-term retention at long-term identity cost."
          impl="Anti-pattern lint: a script scans copy strings for forbidden phrases ('limited time', 'expires soon', 'others have done…') and fails CI. Engineering enforces what design promises."
        />
      </Sub>
    </Section>
  );
}

window.PatternsGamification = PatternsGamification;
