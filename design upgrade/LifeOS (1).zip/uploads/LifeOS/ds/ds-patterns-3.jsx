// Adaptation: responsive, mobile ergonomics, accessibility
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Principle, Pill } = window;

function PatternsAdaptation() {
  return (
    <>
      {/* ─────────────────────────────────────────────── MOBILE ERGONOMICS */}
      <Section id="ergonomics" eyebrow="14 · ERGONOMICS" title="Mobile ergonomics"
        lede="The product runs primarily on phones held one-handed in mornings and evenings. Every primary action must be reachable by a right-thumb arc from the bottom-right. Anything in the top-third is for information, never action.">

        <Sub title="Thumb zones">
          <div style={{
            padding: 24, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`,
            display: 'flex', gap: 30, alignItems: 'flex-start', flexWrap: 'wrap',
          }}>
            <div style={{ position: 'relative', width: 220, height: 380, background: 'rgba(0,0,0,0.3)', borderRadius: 28, border: `1px solid ${DS.borderHi}`, flexShrink: 0 }}>
              {/* Zones */}
              <div style={{ position: 'absolute', inset: 0, borderRadius: 28, overflow: 'hidden' }}>
                <div style={{ position: 'absolute', bottom: 0, right: 0, width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(126,224,184,0.28), transparent 70%)', transform: 'translate(20%, 25%)' }} />
                <div style={{ position: 'absolute', bottom: 0, right: 0, width: 440, height: 440, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,194,58,0.18), transparent 65%)', transform: 'translate(30%, 35%)' }} />
                <div style={{ position: 'absolute', bottom: 0, right: 0, width: 600, height: 600, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,85,119,0.12), transparent 60%)', transform: 'translate(40%, 50%)' }} />
              </div>
              <div style={{ position: 'absolute', bottom: 14, right: 16, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#7EE0B8', letterSpacing: 0.8 }}>EASY</div>
              <div style={{ position: 'absolute', top: '40%', right: 16, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#FFC23A', letterSpacing: 0.8 }}>STRETCH</div>
              <div style={{ position: 'absolute', top: 24, left: 16, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: '#FF5577', letterSpacing: 0.8 }}>HARD</div>
              <div style={{
                position: 'absolute', bottom: 6, left: '50%', transform: 'translateX(-50%)',
                width: 80, height: 3, borderRadius: 3, background: 'rgba(255,255,255,0.6)',
              }} />
            </div>
            <div style={{ flex: 1, minWidth: 280 }}>
              <h4 style={{ margin: 0, fontFamily: 'Nunito', fontWeight: 800, fontSize: 17, color: DS.tx }}>The thumb arc rules</h4>
              <ol style={{ paddingLeft: 18, marginTop: 10, fontFamily: 'DM Sans, system-ui', fontSize: 14, color: DS.tx2, lineHeight: 1.7 }}>
                <li><b style={{ color: DS.tx }}>EASY</b> — bottom-right quadrant. Tab bar, Voice FAB, primary CTAs, "log" buttons.</li>
                <li><b style={{ color: DS.tx }}>STRETCH</b> — mid-screen. Routine blocks, transactions, list rows. Reachable with effort.</li>
                <li><b style={{ color: DS.tx }}>HARD</b> — top-third. Identity, hero stats, status, never actions. Reading zone only.</li>
                <li><b style={{ color: DS.tx }}>NEVER</b> — top-left corner past the notch. Only back-buttons live here, and they have a swipe alternative.</li>
              </ol>
            </div>
          </div>
          <Reason
            ux="60%+ of LifeOS usage is one-handed (morning routine, commute). Designing for two hands punishes the most common context."
            psych="Right-thumb reachability is a physical fact, not a preference. ~88% of users are right-handed; left-handed users get the iOS system mirror."
            impl="No primary action above the 55% screen-height line. Auditable via a Maestro/E2E rule on screen layout snapshots."
          />
        </Sub>

        <Sub title="Touch targets" hint="44 / 48 / 56">
          <SpecTable rows={[
            { name: 'Min hit area',  value: '44 × 44 (iOS) / 48 × 48 (Android)', note: 'Below this, fail Apple HIG / Material guidelines. Includes tab icons, chips, list rows.' },
            { name: 'Primary CTA',   value: '≥ 56 height',                       note: 'Hero buttons (Connect Calendar, Log meal). Bigger fingers, bigger surface.' },
            { name: 'Inline link',   value: '≥ 32 height · 8 padding',           note: 'Smaller is fine ONLY if explicit padding ensures 44×44 invisible hit area.' },
            { name: 'Gap between',   value: '≥ 8',                               note: 'Adjacent tappables must have ≥8px gap or the OS will steal one tap for the other.' },
          ]} />
        </Sub>
      </Section>

      {/* ─────────────────────────────────────────────── RESPONSIVE */}
      <Section id="responsive" eyebrow="15 · RESPONSIVE" title="Responsive behaviour"
        lede="The mobile codebase ships to iOS, Android, and web. Three breakpoints — phone, tablet, desktop. Each is a different layout philosophy, not just wider cards.">

        <Sub title="Breakpoints">
          <Grid cols={3} gap={12}>
            <TokenCard
              sample={<div style={{ display: 'flex', alignItems: 'flex-end', gap: 4 }}><div style={{ width: 40, height: 60, background: 'rgba(165,132,255,0.3)', border: '1px solid rgba(165,132,255,0.6)', borderRadius: 6 }} /></div>}
              name="Phone" value="320 – 599" sub="Single column. Tab bar visible. Hero radar 300px. Standard shipping target."
            />
            <TokenCard
              sample={<div style={{ display: 'flex', alignItems: 'flex-end', gap: 4 }}><div style={{ width: 36, height: 60, background: 'rgba(127,184,255,0.25)', border: '1px solid rgba(127,184,255,0.5)', borderRadius: 6 }} /><div style={{ width: 36, height: 60, background: 'rgba(127,184,255,0.25)', border: '1px solid rgba(127,184,255,0.5)', borderRadius: 6 }} /></div>}
              name="Tablet" value="600 – 1023" sub="Two columns. Tab bar slides to sidebar. Hex radar persists on left; content on right."
            />
            <TokenCard
              sample={<div style={{ display: 'flex', alignItems: 'flex-end', gap: 4 }}><div style={{ width: 16, height: 60, background: 'rgba(126,224,184,0.25)', border: '1px solid rgba(126,224,184,0.5)', borderRadius: 6 }} /><div style={{ width: 36, height: 60, background: 'rgba(126,224,184,0.25)', border: '1px solid rgba(126,224,184,0.5)', borderRadius: 6 }} /><div style={{ width: 26, height: 60, background: 'rgba(126,224,184,0.25)', border: '1px solid rgba(126,224,184,0.5)', borderRadius: 6 }} /></div>}
              name="Desktop" value="1024+" sub="Three columns. Persistent sidebar nav, main flow, contextual right rail (AI assistant, related)."
            />
          </Grid>
          <Reason
            ux="Tablet is not a big phone. Sidebars unlock new layouts. Desktop is not a big tablet — it needs a true info-architecture rebuild."
            psych="Users mentally model 'phone for daily, web for review'. Don't make web a mirror — make it a different posture (planning, weekly insight)."
            impl="Tokens emit different layout primitives per breakpoint (Cols phone={1} tablet={2} desktop={3}). Component bodies don't change; only their compositors do."
          />
        </Sub>

        <Sub title="Fluid scaling">
          <SpecTable rows={[
            { name: 'Type scale',      value: 'unchanged across breakpoints', note: 'Larger screens get wider columns, not bigger text. Display sizes (38/48) are the exception — they grow 1.15× at desktop.' },
            { name: 'Hex radar',       value: '300 (phone) → 380 (tablet) → 420 (desktop)', note: 'Hero element grows; relative position stays.' },
            { name: 'Spacing scale',   value: 'unchanged', note: 'Padding/gap stays the same. Bigger screens get more cards, not bigger cards.' },
            { name: 'Tab bar → sidebar', value: '600px breakpoint', note: 'Below: glass pill at bottom. Above: glass column at left. Same tokens, different orientation.' },
          ]} />
        </Sub>
      </Section>

      {/* ─────────────────────────────────────────────── ACCESSIBILITY */}
      <Section id="a11y" eyebrow="16 · ACCESSIBILITY" title="Accessibility"
        lede="Accessibility isn't a checklist; it's a posture. We target WCAG AA across the board and AAA on critical content (briefings, alerts, AI output).">

        <Sub title="Color & contrast">
          <SpecTable rows={[
            { name: 'Body text',       value: 'AA · ≥ 4.5:1', note: 'F4EFFF on #120A1E hits 14.8:1. 62% F4EFFF (secondary) hits 8.4:1. Safe.' },
            { name: 'Large text',      value: 'AA · ≥ 3.0:1', note: 'Hero numerals on glass cards hit 11.4:1. Safe.' },
            { name: 'AAA · briefings', value: '≥ 7:1',        note: 'AI-generated copy uses primary text + 16px floor + 1.55 line-height.' },
            { name: 'Domain hues on glass', value: '5.6 – 7.2:1', note: 'All six pass AA on dark card. Light-mode equivalent passes on white card.' },
            { name: 'Chip text on hue tint', value: '≥ 4.5:1',   note: 'Use the hue at 92% white over the hue tint, NOT white over hue. CI test guards this.' },
          ]} />
          <Reason
            ux="Contrast is the most-forgotten quality of dark UI. A 'cool muted gray' that scores 3.2:1 is unreadable on a phone in sunlight."
            psych="Users with normal vision skim; users with low vision parse. Both deserve the same content."
            impl="Token resolver exposes contrast(token, surface). Storybook auto-asserts AA per pair; PR fails on regression."
          />
        </Sub>

        <Sub title="Beyond color">
          <SpecTable rows={[
            { name: 'Glyph + color',          value: 'every domain reference',   note: 'Color-blind robustness baked in by P3. The ◆/♥/◈/▲/●/✦ system is also a screen-reader semantic — read out as "goal", "health", etc.' },
            { name: 'Focus indicator',        value: '2px ring · brand violet',  note: 'Every interactive control. Outline-offset 3px so it doesn\'t cut into the card.' },
            { name: 'Reduce motion',          value: 'respected',                note: 'prefers-reduced-motion or LifeOS motion=off collapses all motion. Reward sequence becomes a single flash.' },
            { name: 'Dynamic type',           value: 'respected up to 130%',     note: 'iOS dynamic type scales body 100→130. Past 130% we offer a separate "large type" density.' },
            { name: 'VoiceOver / TalkBack',   value: 'semantic labels everywhere', note: 'Every glyph has a label prop ("Goals, score 78"). Lists use accessibilityRole="list".' },
            { name: 'Voice as primary path',  value: 'always available',         note: 'Voice FAB on every screen. Users who can\'t see can still log a meal, complete a block.' },
          ]} />
        </Sub>

        <Sub title="Cognitive accessibility">
          <Reason
            ux="The product is a life-management tool. Some users come to it during chemo, after a parent's death, during PPD. The UI must never feel demanding."
            psych="Loud streak penalties (red flame, '0!') in moments of stress will cause uninstalls. The grace day system + soft language ('1 save available') is a cognitive-accessibility feature, not just a habit feature."
            impl="Copy library lives in src/copy/. Every notification, alert, and streak message has a 'soft' and 'firm' tone — user setting toggles. Default is soft."
          />
        </Sub>
      </Section>
    </>
  );
}

window.PatternsAdaptation = PatternsAdaptation;
