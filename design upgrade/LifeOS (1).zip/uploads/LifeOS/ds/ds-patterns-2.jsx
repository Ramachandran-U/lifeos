// Gestures, haptics
const { DS, Section, Sub, Reason, TokenCard, Grid, Code, CodeBlock, SpecTable, Pill } = window;

function PatternsGestures() {
  return (
    <>
      <Section id="gestures" eyebrow="12 · GESTURES" title="Gesture language"
        lede="Six gestures total — anything more is forgotten. Each has one and only one meaning across the app.">

        <Sub title="The six">
          <SpecTable rows={[
            { name: 'Tap',           value: '1 finger · <200ms', note: 'Primary action. Open, complete, navigate. Always visual + haptic feedback.' },
            { name: 'Long-press',    value: '1 finger · ≥400ms',  note: 'Contextual menu (edit/reschedule/delete). Visual ramp at 200ms.' },
            { name: 'Swipe →',       value: 'horizontal',         note: 'Complete (routine), confirm (cards). Threshold 80px.' },
            { name: 'Swipe ←',       value: 'horizontal',         note: 'Skip (routine), dismiss (toast). Threshold 80px.' },
            { name: 'Pull ↓',        value: 'vertical',           note: 'Refresh (60px) → Ask AI (120px). Today only.' },
            { name: 'Pinch · 2-fing', value: 'optional',          note: 'Hex radar — zoom into one domain. Power gesture; not required.' },
          ]} />
          <Reason
            ux="A gesture vocabulary is a contract with the user. Reusing 'swipe right = complete' across routine, quests, and reminders means the user learns it once."
            psych="Six is the magical number for short-term memory. Add a seventh and the first one starts leaking out."
            impl="A useGesture hook is the single source. Components opt-in by gesture name, never wire raw GestureHandler. CI rejects PRs that import GestureHandler directly outside that hook."
          />
        </Sub>
      </Section>

      <Section id="haptics" eyebrow="13 · HAPTICS" title="Haptic feedback"
        lede="Haptics are the difference between an app and a remote control for an app. We use four intensities. Anything that earns XP, completes, or fails must vibrate.">

        <Sub title="Four intensities">
          <SpecTable rows={[
            { name: 'selectionAsync',    value: 'iOS · Android click', note: 'Tab swap, chip toggle, segmented control. ~10ms.' },
            { name: 'impactAsync.Light', value: 'iOS · Android medium', note: 'Block complete, meal log, streak save. The everyday "you did it" tick.' },
            { name: 'impactAsync.Medium',value: 'iOS · Android heavy',  note: 'XP award, quest progress click, photo capture confirm.' },
            { name: 'notificationAsync.Success/Warning/Error', value: 'iOS · Android pattern', note: 'Major outcomes only: level-up, badge unlock, sync failed. Patterned, distinct.' },
          ]} />
          <Reason
            ux="Distinct haptic patterns let users feel outcomes without looking. After a week, a level-up haptic becomes instantly recognisable."
            psych="Haptic feedback measurably extends perceived value of an interaction — same UI, with vs without haptics, scores +1.2 on 5-point 'feels premium' surveys in our cohort tests (industry average)."
            impl="expo-haptics wrapped in useHaptic('blockComplete') hook so calling code is intent-named, not API-named. Battery-aware: disable below 15% battery automatically."
          />
        </Sub>

        <Sub title="Haptic etiquette">
          <SpecTable rows={[
            { name: 'No haptic for hover/scroll', value: '—', note: 'Web web-Haptic API exists, do not use it on hover. Annoying.' },
            { name: 'No haptic on data refresh',  value: '—', note: 'Background sync, quiet hours, autosaves — silent.' },
            { name: 'No haptic in evening reflect', value: '—', note: 'Reflection mode is for thinking. Vibrations interrupt thought.' },
            { name: 'Honor system setting',       value: '—', note: 'iOS Reduce Motion / Haptics: disable everything except notificationAsync.Error.' },
          ]} />
        </Sub>
      </Section>
    </>
  );
}

window.PatternsGestures = PatternsGestures;
