// Design system documentation primitives — Aurora Glass style
// Reusable doc helpers: Section, SubSection, Reason, TokenChip, Swatch, etc.

const DS = {
  bg: '#0A0612',
  surface: '#120A1E',
  card: 'rgba(255,255,255,0.045)',
  cardHi: 'rgba(255,255,255,0.07)',
  border: 'rgba(255,255,255,0.08)',
  borderHi: 'rgba(255,255,255,0.14)',
  tx: '#F4EFFF',
  tx2: 'rgba(244,239,255,0.65)',
  tx3: 'rgba(244,239,255,0.4)',
  tx4: 'rgba(244,239,255,0.22)',
  primary: '#A584FF',
  primaryHi: '#C5B3FF',
  goal: '#C9A0FF', health: '#7EE0B8', finance: '#F4C16A',
  career: '#7FB8FF', social: '#FF99C5', polymath: '#FFD66B',
  success: '#31E0A3', warning: '#FFC23A', error: '#FF5577',
  xp: '#FFD66B', streak: '#FF8C3C', badge: '#C5B3FF',
};

// ── Section anchor (numbered, with eyebrow + huge heading) ───────────────
function Section({ id, eyebrow, title, lede, children }) {
  return (
    <section id={id} style={{ padding: '64px 0 32px', borderTop: `1px solid ${DS.border}`, scrollMarginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 12 }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.tx3,
          letterSpacing: 2.5, padding: '4px 9px', borderRadius: 6,
          border: `1px solid ${DS.border}`, background: DS.card,
        }}>{eyebrow}</div>
      </div>
      <h2 style={{
        fontFamily: 'Nunito, system-ui', fontWeight: 900, fontSize: 42,
        margin: '0 0 14px', letterSpacing: -0.8, color: DS.tx, lineHeight: 1.05,
      }}>{title}</h2>
      {lede && (
        <p style={{
          fontFamily: 'DM Sans, system-ui', fontSize: 16, lineHeight: 1.55,
          color: DS.tx2, maxWidth: 680, margin: '0 0 28px',
        }}>{lede}</p>
      )}
      {children}
    </section>
  );
}

function Sub({ id, title, hint, children }) {
  return (
    <div id={id} style={{ marginTop: 36, scrollMarginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 10 }}>
        <h3 style={{
          fontFamily: 'Nunito, system-ui', fontWeight: 800, fontSize: 21,
          margin: 0, color: DS.tx, letterSpacing: -0.2,
        }}>{title}</h3>
        {hint && (
          <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: DS.tx3, letterSpacing: 1 }}>{hint}</span>
        )}
      </div>
      {children}
    </div>
  );
}

// ── Reason callout: UX why / Psych why / Implementation ──────────────────
function Reason({ ux, psych, impl }) {
  const rows = [
    { l: 'UX',     c: '#7FB8FF', body: ux,    icon: <UXIcon /> },
    { l: 'PSYCH',  c: '#FF99C5', body: psych, icon: <PsychIcon /> },
    { l: 'IMPL',   c: '#7EE0B8', body: impl,  icon: <ImplIcon /> },
  ].filter(r => r.body);
  return (
    <div style={{
      marginTop: 14, padding: '14px 16px', borderRadius: 14,
      background: 'rgba(255,255,255,0.025)', border: `1px dashed ${DS.borderHi}`,
      display: 'flex', flexDirection: 'column', gap: 9,
    }}>
      {rows.map(r => (
        <div key={r.l} style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <div style={{
            flex: '0 0 auto', display: 'flex', alignItems: 'center', gap: 6,
            padding: '3px 8px', borderRadius: 6,
            background: `${r.c}14`, border: `1px solid ${r.c}33`, color: r.c,
            fontFamily: 'JetBrains Mono, monospace', fontSize: 10, fontWeight: 600, letterSpacing: 1,
            minWidth: 68,
          }}>{r.icon} {r.l}</div>
          <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13.5, color: DS.tx2, lineHeight: 1.5, flex: 1 }}>{r.body}</div>
        </div>
      ))}
    </div>
  );
}

function UXIcon()    { return <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" fill="none"/></svg>; }
function PsychIcon() { return <svg width="10" height="10" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2 C8 2 5 5 5 9 C5 12 7 14 7 17 V21 H17 V17 C17 14 19 12 19 9 C19 5 16 2 12 2 Z"/></svg>; }
function ImplIcon()  { return <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="8 7 3 12 8 17"/><polyline points="16 7 21 12 16 17"/></svg>; }

// ── Token card — gridable, with name + value + sample ────────────────────
function TokenCard({ name, value, sample, sub }) {
  return (
    <div style={{
      padding: 14, borderRadius: 14,
      background: DS.card, border: `1px solid ${DS.border}`,
      display: 'flex', flexDirection: 'column', gap: 8,
    }}>
      {sample && <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: 56 }}>{sample}</div>}
      <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: DS.tx }}>{name}</div>
      {value !== undefined && (
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.tx3, letterSpacing: 0.4 }}>{value}</div>
      )}
      {sub && (
        <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: DS.tx2, lineHeight: 1.4 }}>{sub}</div>
      )}
    </div>
  );
}

// ── Swatch (color sample) ─────────────────────────────────────────────────
function Swatch({ color, label, value, contrast, note }) {
  return (
    <div style={{
      padding: 14, borderRadius: 14,
      background: DS.card, border: `1px solid ${DS.border}`,
      display: 'flex', flexDirection: 'column', gap: 10,
    }}>
      <div style={{
        height: 72, borderRadius: 10, background: color,
        boxShadow: `0 8px 24px ${color}33, inset 0 0 0 1px rgba(255,255,255,0.05)`,
      }} />
      <div>
        <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx }}>{label}</div>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.tx3, marginTop: 3 }}>{value}</div>
      </div>
      {(contrast || note) && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap' }}>
          {contrast && (
            <div style={{
              padding: '2px 6px', borderRadius: 6, fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5,
              background: contrast.pass ? 'rgba(126,224,184,0.14)' : 'rgba(255,85,119,0.14)',
              color: contrast.pass ? '#7EE0B8' : '#FF5577',
              border: `1px solid ${contrast.pass ? '#7EE0B844' : '#FF557744'}`,
            }}>{contrast.label}</div>
          )}
          {note && <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11, color: DS.tx3 }}>{note}</div>}
        </div>
      )}
    </div>
  );
}

// ── Grid wrapper ──────────────────────────────────────────────────────────
function Grid({ cols = 4, gap = 14, children }) {
  return <div style={{ display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap }}>{children}</div>;
}

// ── Inline code chip ──────────────────────────────────────────────────────
function Code({ children }) {
  return <code style={{
    fontFamily: 'JetBrains Mono, monospace', fontSize: 12,
    padding: '1px 6px', borderRadius: 5,
    background: 'rgba(165,132,255,0.10)', color: '#C5B3FF',
    border: '1px solid rgba(165,132,255,0.18)',
  }}>{children}</code>;
}

// ── Pre-formatted code block ──────────────────────────────────────────────
function CodeBlock({ language = 'css', children }) {
  return (
    <pre style={{
      margin: '12px 0 0', padding: '14px 16px', borderRadius: 12,
      background: 'rgba(0,0,0,0.35)', border: `1px solid ${DS.border}`,
      fontFamily: 'JetBrains Mono, monospace', fontSize: 12.5, lineHeight: 1.55,
      color: '#C5B3FF', overflow: 'auto',
    }}>
      <div style={{ fontSize: 10, color: DS.tx3, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>{language}</div>
      <code style={{ color: DS.tx }}>{children}</code>
    </pre>
  );
}

// ── Spec table — k/v rows ────────────────────────────────────────────────
function SpecTable({ rows }) {
  return (
    <div style={{ borderRadius: 14, border: `1px solid ${DS.border}`, overflow: 'hidden', background: DS.card }}>
      {rows.map((r, i) => (
        <div key={i} style={{
          display: 'grid', gridTemplateColumns: '160px 130px 1fr',
          padding: '11px 14px', gap: 14, alignItems: 'center',
          borderTop: i ? `1px solid ${DS.border}` : 'none',
        }}>
          <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx }}>{r.name}</div>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: r.valueColor || DS.primaryHi, letterSpacing: 0.3 }}>{r.value}</div>
          <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13, color: DS.tx2, lineHeight: 1.4 }}>{r.note}</div>
        </div>
      ))}
    </div>
  );
}

// ── Principle row ────────────────────────────────────────────────────────
function Principle({ n, glyph, color, title, body }) {
  return (
    <div style={{
      display: 'flex', gap: 16, padding: '18px 18px', borderRadius: 16,
      background: `linear-gradient(135deg, ${color}10, transparent)`,
      border: `1px solid ${color}33`,
    }}>
      <div style={{
        flex: '0 0 auto', width: 52, height: 52, borderRadius: 14,
        background: `${color}18`, border: `1px solid ${color}55`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        color, fontFamily: 'Nunito', fontWeight: 900, fontSize: 24,
      }}>{glyph}</div>
      <div style={{ flex: 1 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 10 }}>
          <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 1.5 }}>P{n}</div>
          <h4 style={{ margin: 0, fontFamily: 'Nunito', fontWeight: 900, fontSize: 18, color: DS.tx }}>{title}</h4>
        </div>
        <p style={{ margin: '6px 0 0', fontFamily: 'DM Sans, system-ui', fontSize: 14, color: DS.tx2, lineHeight: 1.55 }}>{body}</p>
      </div>
    </div>
  );
}

// ── Phone preview (mini) ─────────────────────────────────────────────────
function MiniPhone({ width = 200, height = 380, children, label }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6 }}>
      <div style={{
        width, height, background: DS.bg, borderRadius: 28,
        border: `1px solid ${DS.borderHi}`, padding: 8,
        boxShadow: '0 20px 50px rgba(0,0,0,0.4)', position: 'relative', overflow: 'hidden',
      }}>
        <div style={{ borderRadius: 22, height: '100%', overflow: 'hidden', position: 'relative' }}>{children}</div>
      </div>
      {label && <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 0.8 }}>{label}</div>}
    </div>
  );
}

// ── Pill / chip ─────────────────────────────────────────────────────────
function Pill({ color = DS.primary, children, dim = false }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '4px 9px', borderRadius: 999,
      background: dim ? 'rgba(255,255,255,0.04)' : `${color}1A`,
      border: `1px solid ${dim ? DS.border : color + '44'}`,
      fontFamily: 'JetBrains Mono, monospace', fontSize: 10.5, color: dim ? DS.tx3 : color, letterSpacing: 0.3,
    }}>{children}</span>
  );
}

Object.assign(window, {
  DS, Section, Sub, Reason, TokenCard, Swatch, Grid, Code, CodeBlock, SpecTable, Principle, MiniPhone, Pill,
});
