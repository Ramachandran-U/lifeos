// Flows 9–11: habit completion, health logging, finance tracking
const { Flow, StepDiagram, EmotionCurve, Dimensions } = window;

function UXFlow9to11() {
  return (
    <>
      {/* ─────────────────────────────────────────────── 09 HABIT COMPLETION */}
      <Flow id="habit-completion" n="9" title="Habit completion · the tap"
        lede="The most-frequent interaction in the app — completing a routine block, logging a streak, ticking a quest. Frequency demands speed; ceremony demands feedback. The tap must do both.">
        <StepDiagram steps={[
          { title: 'See the live block', body: 'Routine timeline · "NOW" pulse on current.',    screen: 'today',         mood: 'neutral' },
          { title: 'Tap check',          body: 'Press-state scale 0.97 · 80ms haptic.',          screen: 'today',         mood: 'curious' },
          { title: 'Block flips done',   body: 'Border flash · strike-through · soft fade.',     screen: 'today',         mood: 'proud' },
          { title: 'XP travels',         body: '+10 chip rises into the rail.',                  screen: 'today',         mood: 'excited' },
          { title: 'Next block lifts',   body: 'Tomorrow\'s "NOW" pulse moves to next block.',   screen: 'today',         mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'neutral' }, { mood: 'curious' }, { mood: 'proud' }, { mood: 'excited' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'A 5-step micro-arc happens in 1.2 seconds. The user feels it as one continuous beat — but every step is engineered to land.',
          friction: 'Step 1 — the "NOW" indicator must be visible without scroll. If the current block is below the fold at app open, auto-scroll-into-view with a soft animation.',
          dopamine: 'Step 4 — the XP chip flying is the single most-rewarding micro-animation in the product. Time it perfectly: 250ms · spring.snappy.',
          animation: 'Tap (spring.standard) → tick (timing.fast) → XP fly (spring.snappy) → rail fill (timing.normal) → next block highlight (timing.fast).',
          retention: 'Users who complete ≥3 blocks/day retain at 4× rate. The block-complete moment is the engine of the entire retention model.',
          ai: 'If the user completes >5 blocks before noon, AI proposes an optional "stretch block" for the afternoon. Reward overachievement gently.',
          disclosure: 'No copy. No tooltips. The interaction is so frequent that any UI overhead becomes noise. Make the visual story carry all the meaning.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 10 HEALTH LOG */}
      <Flow id="health-log" n="10" title="Health logging · the photo log"
        lede="Logging a meal must take <8 seconds end-to-end or users won\'t do it daily. The AI-powered photo log is the killer feature; everything else (manual entry, search) is the long-tail fallback.">
        <StepDiagram steps={[
          { title: 'Tap log',         body: 'Big CTA on Health screen. Camera opens immediately.', screen: 'health',        mood: 'cautious' },
          { title: 'Snap photo',      body: 'Camera + soft frame guide. One-tap shutter.',         screen: 'camera',        mood: 'curious' },
          { title: 'AI parsing',      body: '2s · "Identifying… chicken bowl, greens, rice".',     screen: 'analysing',     mood: 'curious' },
          { title: 'Review + edit',   body: 'List of items with macros. Tap to adjust.',           screen: 'review-meal',   mood: 'cautious' },
          { title: 'Confirm save',    body: 'Single CTA · ring updates · +5 XP +20 photo bonus.',  screen: 'health',        mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'curious' }, { mood: 'curious' }, { mood: 'cautious' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'Health logging carries shame for many users. Tone is critical — never "you went over budget", always "you\'ve fueled X / target".',
          friction: 'Step 3 — if AI takes >3s the user feels watched. Add streaming UI: items appear as soon as they\'re identified.',
          dopamine: 'Step 5 — the calorie ring filling is a satisfying micro-moment. Use timing.slow (600ms) so users see the ring actively respond.',
          animation: 'Camera shutter haptic. AI label-stream appears word by word. Calorie ring fills with timing.slow. XP chip flies — twice if photo bonus triggers.',
          retention: 'Users who log ≥1 meal/day in week 1 hit a streak that retains 5× better. First-meal-log nudge is one of the highest-priority push opportunities.',
          ai: 'If AI confidence is low (<70%), surface "Did I get this right?" — user feedback trains better recognition. Never auto-save uncertain detections.',
          disclosure: 'Don\'t show macros until after the photo. The photo IS the input; macros are the side-effect. Inverting this kills the simplicity.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 11 FINANCE TRACK */}
      <Flow id="finance-track" n="11" title="Finance tracking · ingest → insight"
        lede="The Gmail-ingested finance flow is uniquely automated — most of the work happens silently. The user only enters the picture for occasional review and weekly insight.">
        <StepDiagram steps={[
          { title: 'Gmail connected',   body: 'One-time auth. Status: live.',                      screen: 'finance/setup', mood: 'cautious' },
          { title: 'Tx auto-ingested', body: 'Background. New rows appear in feed.',              screen: 'background',    mood: 'neutral' },
          { title: 'Open Finance',     body: 'Month tri-stat + sun-arc milestone.',               screen: 'finance',       mood: 'curious' },
          { title: 'Weekly insight',   body: 'AI card · "Food jumped 38% this week".',            screen: 'finance',       mood: 'cautious' },
          { title: 'Adjust or accept', body: 'Tap card → "Try cooking 3× this week" quest.',      screen: 'finance/insight', mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'neutral' }, { mood: 'curious' }, { mood: 'cautious' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'Money is the most-anxious domain. Calm tone, soft type, no red unless truly critical. Hide negative deltas behind a tap for first-time view.',
          friction: 'Step 1 — Gmail auth is the bottleneck. Position the value prop ("never enter a transaction again") before the auth ask.',
          dopamine: 'Step 3 — seeing categorised spending feels like the app did your work for you. The Saved column climbing during the month is a quiet daily reward.',
          animation: 'Sun-arc fills slowly (timing.slow). New transactions fade in at the top of the list (no slide-in — slide reads as anxious here).',
          retention: 'Users with active Gmail ingest retain at 2.8× rate. The flow runs without them; they return because they trust they\'re seeing reality.',
          ai: 'AI weekly insights are conversational, never alarmist. If a category spikes >50% week-over-week, the AI proposes a counter-action AS a quest — not a warning.',
          disclosure: 'Hide individual transactions on first finance open — show only categorised summary. Tap reveals tx list. Most users only ever want the summary.',
        }} />
      </Flow>
    </>
  );
}

window.UXFlow9to11 = UXFlow9to11;
