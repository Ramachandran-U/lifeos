// Flows 5–8: streak recovery, AI recommendations, rewards unlocks, evening reflection
const { Flow, StepDiagram, EmotionCurve, Dimensions } = window;

function UXFlow5to8() {
  return (
    <>
      {/* ─────────────────────────────────────────────── 05 STREAK RECOVERY */}
      <Flow id="streak-recovery" n="5" title="Streak recovery · the grace day"
        lede="The single most psychologically loaded flow in the app. Users miss days. The product's job is to make the return feel safer than the lapse.">
        <StepDiagram steps={[
          { title: 'Missed day',      body: 'User didn\'t log. App stays quiet — no shame push.', screen: 'background',     mood: 'anxious' },
          { title: 'D+2 morning',     body: 'Soft notification: "Your learning streak is asleep, not gone."', screen: 'notification', mood: 'cautious' },
          { title: 'Open + see grace',body: 'Streak card shows 47 days · "1 save available".',   screen: 'today',          mood: 'cautious' },
          { title: 'Log next action', body: 'One-tap log → streak holds at 47 · grace consumed.', screen: 'today/streak',   mood: 'calm' },
          { title: 'Save celebration',body: 'Toast: "Saved. Your flame stays bright."',          screen: 'toast-overlay',  mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'anxious' }, { mood: 'cautious' }, { mood: 'cautious' }, { mood: 'calm' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'Anxious (step 1) → relieved (step 4) → proud (step 5). The grace mechanic exists specifically to break the shame spiral that kills habit apps.',
          friction: 'Step 2 — wording is critical. "Asleep, not gone" tested 4× better than "at risk". Forbidden phrases (red, flame-dying language) live in lint rules.',
          dopamine: 'Step 5 — micro-haptic + warm flame intensification. Re-logging after a break delivers +50 XP bonus (vs standard +10).',
          animation: 'Step 4: flame icon brightens over 600ms (timing.slow) — slower than standard so the user reads relief, not urgency.',
          retention: 'Users who use grace day correctly retain 3.4× better than users whose streak resets to 0. The grace day is a retention feature disguised as a forgiveness feature.',
          ai: 'If user has missed 3+ days, briefing shifts: "Welcome back. Want me to rebuild this week\'s plan?" — never "you fell behind".',
          disclosure: 'After grace consumed, the indicator disappears for 14 days (so it doesn\'t feel like the next miss is a doom counter). Re-emerges on next miss naturally.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 06 AI RECOMMENDATIONS */}
      <Flow id="ai-recommendations" n="6" title="AI recommendations · contextual nudge"
        lede="The AI surfaces a suggestion at the right moment. Not a push, not a popup — a card the user discovers in their flow. Tone matters more than accuracy.">
        <StepDiagram steps={[
          { title: 'Data accrues',   body: 'Background: 7 days of routine + log data.',          screen: 'background',    mood: 'neutral' },
          { title: 'Pattern surfaced',body: 'Briefing card morphs: "Your Tuesdays are your worst day."', screen: 'today',  mood: 'cautious' },
          { title: 'Review proposal',body: '"Move the workout to Wednesday?" Yes / Not now / Tell me more.', screen: 'today', mood: 'curious' },
          { title: 'Accept or dismiss', body: 'Accept: routine updates with explanation. Dismiss: AI quiet for 7d on this topic.', screen: 'today', mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'neutral' }, { mood: 'cautious' }, { mood: 'curious' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'AI surprise must feel like a sharp friend, not a salesman. The tone test: would a good therapist phrase it this way? If no, rewrite.',
          friction: 'Step 3 — "Tell me more" is the secret weapon. ~40% of users tap it; the explanation card teaches them about the AI\'s reasoning and trust grows.',
          dopamine: 'The dopamine here isn\'t fireworks — it\'s "this app sees me". Pride at being understood lasts longer than excitement at a win.',
          animation: 'Briefing card morph is the only animation. Same card, different content, crossfade 300ms. Never use a "new" toast — that\'s notification energy.',
          retention: 'Users who accept ≥1 AI suggestion per week retain at 4.2× the rate of those who never accept. Make the first suggestion an easy win.',
          ai: 'Confidence calibration: AI labels its suggestions as "I noticed" (high confidence), "I wonder if" (medium), "What if you tried" (low). Honest uncertainty builds trust.',
          disclosure: 'Suggestions appear max 1 per day. Saved suggestions live in a /insights archive. Users who want more can pull-to-AI on Today.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 07 REWARDS UNLOCKS */}
      <Flow id="rewards-unlocks" n="7" title="Rewards unlock · level-up / badge / milestone"
        lede="A major reward moment — crossing a level, earning a badge, hitting a 30-day streak. These are the only times the app is allowed to be loud.">
        <StepDiagram steps={[
          { title: 'Trigger action',   body: 'User completes block · XP crosses threshold.',     screen: 'today',          mood: 'proud' },
          { title: 'Source flash',     body: 'Block borders flash domain hue (one frame).',      screen: 'today',          mood: 'excited' },
          { title: 'XP chip flies',    body: 'Chip rises 24px → fades into XP rail.',            screen: 'today',          mood: 'excited' },
          { title: 'Rail fills + glow',body: 'Bar advances. Soft glow pulse.',                   screen: 'today',          mood: 'proud' },
          { title: 'Overlay (if level)', body: 'Full-screen: "L8 · Strategist" + unlocks list.', screen: 'level-up-modal', mood: 'proud' },
          { title: 'Continue',         body: 'Single button dismisses. Back to flow in <1s.',    screen: 'today',          mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'proud' }, { mood: 'excited' }, { mood: 'excited' }, { mood: 'proud' }, { mood: 'proud' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'Pride dominates. Excitement spikes briefly. Calm returns immediately — the user is here to live, not celebrate. Overlay capped at 6s auto-dismiss.',
          friction: 'Step 5 — modal interruption is the only acceptable use of one in the entire app. It must be skippable in 1 tap and never block a pending action.',
          dopamine: 'The reward sequence (Motion · §07) drains over 1.5s with 6 distinct beats. Spaced dopamine outperforms single-burst by ~30% in self-report tests.',
          animation: 'spring.snappy (260/24) for chip fly. timing.slow for rail fill. SVG-particle confetti for level-up only. Sound: single 280ms chord, never longer.',
          retention: 'A user who never sees a reward overlay in week 1 churns 2.1× more than one who sees one. Pace XP thresholds so first level-up lands D3–D5.',
          ai: 'AI selects which "unlocks" to surface on the overlay — based on the user\'s neglected domain. Level-up doubles as a soft re-engagement.',
          disclosure: 'Locked badges visible but at 40% opacity in the Rewards tab. The user infers their own progress without being told. No "you\'re 80% to X" countdown.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 08 EVENING REFLECT */}
      <Flow id="evening-reflect" n="8" title="Evening reflection · 60-second wrap"
        lede="The most underrated retention flow. A 60-second guided reflection before bed locks today\'s wins into memory and sets tomorrow\'s intent. Done well, it\'s the single best return-tomorrow signal.">
        <StepDiagram steps={[
          { title: '8 PM notification', body: '"Want to wrap up today? 60 seconds."',            screen: 'notification',     mood: 'cautious' },
          { title: 'Land on reflect',  body: 'Dark soft surface. Today\'s wins listed.',         screen: 'evening-reflect',  mood: 'calm' },
          { title: 'One-line gratitude',body: 'Single textarea · "One thing that went well".',   screen: 'evening-reflect',  mood: 'calm' },
          { title: 'Mood + energy chip',body: 'Tap-pick: 😴 ☁ 🌤 ☀ 🔥',                            screen: 'evening-reflect',  mood: 'calm' },
          { title: 'Tomorrow preview', body: '3 blocks · "Want to swap any?"',                   screen: 'evening-reflect',  mood: 'curious' },
          { title: 'Close · save',     body: 'Today\'s domain scores update. Streak ticks.',     screen: 'today',            mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'calm' }, { mood: 'calm' }, { mood: 'calm' }, { mood: 'curious' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'This is the calmest flow in the product. Everything is softer: type a touch lighter, motion a beat slower, color desaturated 15%. Headspace mode.',
          friction: 'Step 3 — typing at 8 PM. Allow voice input prominently. Default to "nothing comes to mind, that\'s okay" — gratitude under duress backfires.',
          dopamine: 'Step 2 — seeing today\'s wins listed creates a quiet "I did more than I thought" beat. Step 6 — the journaling streak ticks +1.',
          animation: 'No motion is the motion. Sections fade in serially over 1.5s total. Even the streak tick is silent (no flame brightening).',
          retention: 'Users who reflect ≥3×/week retain at >85% D30. The flow is short specifically so users repeat it nightly without resistance.',
          ai: 'AI summarises today\'s wins as bullet list AND drafts tomorrow\'s briefing while reflection is open. By 8:05 PM, tomorrow is already planned.',
          disclosure: 'No XP shown. No badges. No streaks (until step 6 silent tick). The reflection flow deliberately demotes gamification to preserve emotional posture.',
        }} />
      </Flow>
    </>
  );
}

window.UXFlow5to8 = UXFlow5to8;
