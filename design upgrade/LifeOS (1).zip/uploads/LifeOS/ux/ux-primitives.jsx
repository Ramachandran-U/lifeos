// UX journey primitives — Flow, Step, EmotionCurve, Dimensions grid
const { DS, Section, Sub, Reason, Code, Pill } = window;

// Emotional state palette (anxious → calm → excited)
const MOOD = {
  anxious:  { hue: '#FF5577', label: 'Anxious',  y: 0.18 },
  cautious: { hue: '#FFC23A', label: 'Cautious', y: 0.35 },
  neutral:  { hue: '#7FB8FF', label: 'Neutral',  y: 0.50 },
  calm:     { hue: '#7EE0B8', label: 'Calm',     y: 0.62 },
  curious:  { hue: '#C9A0FF', label: 'Curious',  y: 0.72 },
  excited:  { hue: '#FFD66B', label: 'Excited',  y: 0.85 },
  proud:    { hue: '#FF8C3C', label: 'Proud',    y: 0.92 },
};

// ── Flow header — top-level wrapper
function Flow({ id, n, title, lede, children }) {
  return (
    <section id={id} style={{ padding: '56px 0 24px', borderTop: `1px solid ${DS.border}`, scrollMarginTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 14, marginBottom: 10 }}>
        <div style={{
          fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.tx3,
          letterSpacing: 2.5, padding: '4px 9px', borderRadius: 6,
          border: `1px solid ${DS.border}`, background: DS.card,
        }}>FLOW · {String(n).padStart(2, '0')}</div>
      </div>
      <h2 style={{
        fontFamily: 'Nunito, system-ui', fontWeight: 900, fontSize: 36,
        margin: '0 0 12px', letterSpacing: -0.6, color: DS.tx, lineHeight: 1.05,
      }}>{title}</h2>
      {lede && (
        <p style={{
          fontFamily: 'DM Sans, system-ui', fontSize: 15.5, lineHeight: 1.55,
          color: DS.tx2, maxWidth: 720, margin: '0 0 28px',
        }}>{lede}</p>
      )}
      {children}
    </section>
  );
}

// ── Step diagram — horizontal sequence of nodes
function StepDiagram({ steps }) {
  return (
    <div style={{
      padding: '18px 14px 22px', borderRadius: 16,
      background: DS.card, border: `1px solid ${DS.border}`,
      overflowX: 'auto',
    }}>
      <div style={{ display: 'flex', alignItems: 'stretch', gap: 0, minWidth: 'max-content' }}>
        {steps.map((s, i) => {
          const mood = MOOD[s.mood] || MOOD.neutral;
          return (
            <React.Fragment key={i}>
              <div style={{
                flex: '0 0 165px', padding: 12, borderRadius: 14,
                background: `linear-gradient(180deg, ${mood.hue}12, transparent)`,
                border: `1px solid ${mood.hue}33`,
                display: 'flex', flexDirection: 'column', gap: 6,
                position: 'relative',
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{
                    width: 22, height: 22, borderRadius: 7,
                    background: `${mood.hue}22`, color: mood.hue,
                    border: `1px solid ${mood.hue}55`,
                    fontFamily: 'Nunito', fontWeight: 900, fontSize: 11,
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>{i + 1}</div>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: mood.hue, letterSpacing: 1 }}>{mood.label.toUpperCase()}</div>
                </div>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13.5, color: DS.tx, lineHeight: 1.2 }}>{s.title}</div>
                <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 11.5, color: DS.tx2, lineHeight: 1.4 }}>{s.body}</div>
                {s.screen && (
                  <div style={{ marginTop: 'auto', paddingTop: 4, fontFamily: 'JetBrains Mono, monospace', fontSize: 9, color: DS.tx3, letterSpacing: 0.5 }}>↳ {s.screen}</div>
                )}
              </div>
              {i < steps.length - 1 && (
                <div style={{ flex: '0 0 22px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                  <svg width="20" height="14" viewBox="0 0 20 14">
                    <path d="M 0 7 L 16 7 M 12 3 L 16 7 L 12 11" stroke="rgba(244,239,255,0.35)" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

// ── Emotional curve — SVG line under the flow
function EmotionCurve({ steps, height = 130 }) {
  const w = 200 + steps.length * 187 - 22;
  const stepW = 187;
  const startX = 12 + 165 / 2;
  const points = steps.map((s, i) => {
    const mood = MOOD[s.mood] || MOOD.neutral;
    return [startX + i * stepW, (1 - mood.y) * (height - 30) + 15];
  });
  const pathD = points.map(([x, y], i) => i === 0 ? `M ${x} ${y}` : `C ${points[i-1][0] + stepW/2} ${points[i-1][1]}, ${x - stepW/2} ${y}, ${x} ${y}`).join(' ');
  const areaD = `${pathD} L ${points[points.length-1][0]} ${height} L ${points[0][0]} ${height} Z`;
  return (
    <div style={{
      padding: '14px 14px', borderRadius: 16,
      background: DS.card, border: `1px solid ${DS.border}`,
      marginTop: 12, overflowX: 'auto',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 1.6 }}>EMOTIONAL ARC</div>
        <div style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 10 }}>
          {['anxious','cautious','neutral','calm','curious','excited','proud'].map(k => (
            <div key={k} style={{ display: 'flex', alignItems: 'center', gap: 3 }}>
              <div style={{ width: 6, height: 6, borderRadius: 3, background: MOOD[k].hue }} />
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 8.5, color: DS.tx3 }}>{MOOD[k].label}</div>
            </div>
          ))}
        </div>
      </div>
      <svg width={w} height={height} style={{ display: 'block' }}>
        <defs>
          <linearGradient id={`mood-area-${steps.length}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#A584FF" stopOpacity="0.4" />
            <stop offset="1" stopColor="#A584FF" stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* Gridlines */}
        {[0.25, 0.5, 0.75].map(g => (
          <line key={g} x1={0} x2={w} y1={(1 - g) * (height - 30) + 15} y2={(1 - g) * (height - 30) + 15}
                stroke="rgba(244,239,255,0.05)" strokeWidth="1" />
        ))}
        <path d={areaD} fill={`url(#mood-area-${steps.length})`} />
        <path d={pathD} stroke="#A584FF" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
        {points.map(([x, y], i) => {
          const mood = MOOD[steps[i].mood] || MOOD.neutral;
          return (
            <g key={i}>
              <circle cx={x} cy={y} r="5" fill={mood.hue} stroke="#0A0612" strokeWidth="2" />
            </g>
          );
        })}
      </svg>
    </div>
  );
}

// ── Dimension grid — 7-cell summary per flow
function Dimensions({ items }) {
  // items: { emotion, friction, dopamine, animation, retention, ai, disclosure }
  const cards = [
    { k: 'emotion',    l: 'Emotional state',  c: '#FF99C5', icon: '♥' },
    { k: 'friction',   l: 'Friction points',  c: '#FF5577', icon: '⚠' },
    { k: 'dopamine',   l: 'Dopamine moments', c: '#FFD66B', icon: '✦' },
    { k: 'animation',  l: 'Animations used',  c: '#7FB8FF', icon: '↗' },
    { k: 'retention',  l: 'Retention opp',    c: '#7EE0B8', icon: '↻' },
    { k: 'ai',         l: 'AI intervention',  c: '#A584FF', icon: '◇' },
    { k: 'disclosure', l: 'Progressive disclosure', c: '#F4C16A', icon: '◈' },
  ];
  return (
    <div style={{
      marginTop: 14, display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)',
      gap: 10,
    }}>
      {cards.map(card => (
        <div key={card.k} style={{
          padding: '12px 14px', borderRadius: 14,
          background: 'rgba(255,255,255,0.025)', border: `1px solid ${card.c}22`,
          borderLeft: `3px solid ${card.c}`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 4 }}>
            <span style={{ color: card.c, fontFamily: 'Nunito', fontWeight: 900, fontSize: 13 }}>{card.icon}</span>
            <span style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: card.c, letterSpacing: 1.4 }}>{card.l.toUpperCase()}</span>
          </div>
          <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: DS.tx, lineHeight: 1.5 }}>{items[card.k]}</div>
        </div>
      ))}
    </div>
  );
}

// ── Meta heatmap row — used in churn/overwhelm sections
function HeatRow({ label, value, max = 5, hue = '#FF5577', note }) {
  return (
    <div style={{
      display: 'grid', gridTemplateColumns: '180px 130px 1fr',
      padding: '10px 14px', alignItems: 'center', gap: 14,
      borderBottom: `1px solid ${DS.border}`,
    }}>
      <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: DS.tx }}>{label}</div>
      <div style={{ display: 'flex', gap: 3 }}>
        {Array.from({ length: max }).map((_, i) => (
          <div key={i} style={{
            width: 14, height: 14, borderRadius: 3,
            background: i < value ? hue : 'rgba(255,255,255,0.06)',
            boxShadow: i < value ? `0 0 6px ${hue}66` : 'none',
          }} />
        ))}
      </div>
      <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: DS.tx2, lineHeight: 1.45 }}>{note}</div>
    </div>
  );
}

Object.assign(window, { Flow, StepDiagram, EmotionCurve, Dimensions, HeatRow, MOOD });
