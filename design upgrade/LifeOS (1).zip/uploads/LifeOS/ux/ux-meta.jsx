// Meta analyses: churn, overwhelm, calm vs energetic, cognitive load over time
const { DS, Section, Sub, Reason, Code, Pill } = window;
const { HeatRow, MOOD } = window;

function UXMeta() {
  return (
    <>
      {/* ─────────────────────────────────────────────── CHURN MAP */}
      <Section id="churn" eyebrow="META · 01" title="Where users may churn"
        lede="Five high-risk drop points across the lifecycle. Each has a specific UX countermeasure. Churn isn\'t one big problem — it\'s five medium problems, each fixable.">

        <div style={{ marginTop: 14, padding: '4px 0', borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}` }}>
          <div style={{ display: 'grid', gridTemplateColumns: '180px 130px 1fr', padding: '10px 14px', fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: DS.tx3, letterSpacing: 1.4, borderBottom: `1px solid ${DS.border}` }}>
            <div>RISK POINT</div><div>SEVERITY</div><div>MITIGATION</div>
          </div>
          <HeatRow label="Onboarding step 3 (paste)" value={4} hue="#FF5577" note="Optional but high-perceived-effort. Mitigation: keep skip prominent · pre-populate with a single example sentence · move to D2 if skipped." />
          <HeatRow label="D1 blank radar"            value={4} hue="#FF5577" note="An honest zero-state radar feels like 'this app is empty'. Mitigation: seed scores at 30–45 from onboarding inputs so the user lands on a populated picture." />
          <HeatRow label="Push opt-in (D0/D1)"       value={5} hue="#FF5577" note="Refusing push = 70% lower D7 retention. Mitigation: ask AFTER first reward beat, never on first launch. Copy: 'wake nudge + evening wrap — that\\'s it.'" />
          <HeatRow label="Streak break at D3–D7"     value={3} hue="#FFC23A" note="Lapses early before the habit forms. Mitigation: grace day · soft language · welcome-back micro-flow on the day of return." />
          <HeatRow label="Week-3 plateau"            value={4} hue="#FF5577" note="Novelty fades; first level-up is past. Mitigation: surface FIRST cross-domain insight in week 3 (gated to this date intentionally)." />
          <HeatRow label="Notification fatigue"      value={3} hue="#FFC23A" note="Default 4 pushes/day risks unsubscribes. Mitigation: AI scheduler skips pushes on days the user is already engaged > 2 times." />
        </div>

        <Reason
          ux="Each row is owned by a specific surface. PR template includes a 'which churn point does this address' field — keeps the map alive."
          psych="Churn is rarely a single moment of dissatisfaction. It\'s an accumulation of small frictions that finally tips. Each row above is a small friction we choose to remove."
          impl="Track each as a distinct event in Amplitude: churn_paste_skip, churn_blank_radar, churn_push_decline, churn_streak_break, churn_week3_plateau, churn_notif_unsub. Funnel reports per cohort."
        />
      </Section>

      {/* ─────────────────────────────────────────────── OVERWHELM MAP */}
      <Section id="overwhelm" eyebrow="META · 02" title="Where users may feel overwhelmed"
        lede="The product touches goals, money, health, career, relationships, and learning. Without discipline, that\'s a UI that gives a user a panic attack every Sunday.">

        <div style={{ marginTop: 14, padding: '4px 0', borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}` }}>
          <div style={{ display: 'grid', gridTemplateColumns: '180px 130px 1fr', padding: '10px 14px', fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: DS.tx3, letterSpacing: 1.4, borderBottom: `1px solid ${DS.border}` }}>
            <div>OVERLOAD POINT</div><div>SEVERITY</div><div>STRATEGY</div>
          </div>
          <HeatRow label="Full goal hierarchy"   value={5} hue="#FFC23A" note="Yearly + monthly + weekly + daily = 30+ nodes per goal. Strategy: surface daily tasks only on Today; bury weekly/monthly behind tap." />
          <HeatRow label="All 6 domains active"  value={4} hue="#FFC23A" note="Showing all domains at zero feels like failure. Strategy: progressive activation — onboarding starts with 2 domains; others unlock as the user signals interest." />
          <HeatRow label="Rewards tab density"   value={3} hue="#FFC23A" note="Streaks + Quests + Badges + XP + Level — five primitives in one screen. Strategy: collapse Badges to grid view by default; full board behind 'see all'." />
          <HeatRow label="AI suggestions volume" value={4} hue="#FFC23A" note="Constant 'I noticed…' cards become noise. Strategy: hard cap 1/day · prioritise by domain neglected · user can suppress per-topic." />
          <HeatRow label="Sunday weekly review"  value={5} hue="#FFC23A" note="The natural impulse is a giant review screen. Strategy: split into 3 stories (best, worst, surprise) · 60s each · optional after the first week." />
          <HeatRow label="Onboarding day-1 plan" value={4} hue="#FFC23A" note="Generating a 12-block routine on day 1 is intimidating. Strategy: cap initial routine at 5 blocks · let users add the rest over the first week." />
        </div>

        <Reason
          ux="Progressive disclosure isn\'t just hiding things — it\'s deciding what NOT to show even when asked. Power users will demand 'show everything'; resist."
          psych="Cognitive load is felt before it\'s articulated. By the time a user says 'this is too much', they\'ve already drafted the uninstall."
          impl="Default views ship with the smallest reasonable surface; expanded views are accessed via explicit user action with a one-time tooltip. Track expand-rate as a usability metric."
        />
      </Section>

      {/* ─────────────────────────────────────────────── CALM VS ENERGETIC */}
      <Section id="calm-energetic" eyebrow="META · 03" title="Where the app should feel calm vs energetic"
        lede="Every screen and flow lives somewhere on a calm↔energetic spectrum. The spectrum is a design tool: a screen out of place on it feels wrong even when no individual element does.">

        <Sub title="The spectrum">
          <CalmSpectrum />
        </Sub>

        <Reason
          ux="The spectrum is a calibration tool, not a constraint. A reviewer can ask: 'is this screen pulling toward the right end of the spectrum?' and that\'s a usable design conversation."
          psych="Apps that lean too far calm (Headspace-only) lose retention; too far energetic (Duolingo-only) lose trust. Holding both ends requires per-screen calibration."
          impl="Each screen ships with a calm-energetic dial value (0–10) in its metadata. CI screenshot diffs compare against the dial — a 'rewards' screen that drifts to <6 fails review."
        />
      </Section>

      {/* ─────────────────────────────────────────────── COGNITIVE LOAD OVER TIME */}
      <Section id="cognitive-load" eyebrow="META · 04" title="How cognitive load should reduce over time"
        lede="A new user needs explanations. A 3-month user needs absence-of-friction. The UI must measurably get quieter as the user matures.">

        <Sub title="The curve">
          <CognitiveLoadCurve />
        </Sub>

        <Sub title="What changes over time">
          <div style={{ borderRadius: 14, border: `1px solid ${DS.border}`, background: DS.card, overflow: 'hidden', marginTop: 14 }}>
            {[
              { week: 'W1',  load: 'high', changes: 'Tooltips on every key control. Empty states with explanatory copy. AI explains its reasoning verbosely.' },
              { week: 'W2',  load: 'med',  changes: 'Tooltips disappear after one view. Empty states shrink to one line. AI confidence becomes implicit.' },
              { week: 'W4',  load: 'med',  changes: 'Voice surfaces. Pull-to-AI tutorial. First cross-domain insight (gated for here). Density default offered up.' },
              { week: 'W8',  load: 'low',  changes: 'Power features (long-press menus, keyboard shortcuts on web) become visible via subtle hint. Notifications cut back.' },
              { week: 'W12', load: 'low',  changes: 'AI suggestions become rarer but higher confidence. UI surface is at its minimum — same screens, more whitespace.' },
              { week: 'W26', load: 'min',  changes: 'App is a habitual companion. Welcome screen disappears. Voice is the primary input for daily logging.' },
            ].map((r, i) => {
              const c = r.load === 'high' ? '#FF5577' : r.load === 'med' ? '#FFC23A' : r.load === 'low' ? '#7EE0B8' : '#A584FF';
              return (
                <div key={r.week} style={{ display: 'grid', gridTemplateColumns: '80px 100px 1fr', padding: '11px 14px', alignItems: 'center', gap: 14, borderTop: i ? `1px solid ${DS.border}` : 'none' }}>
                  <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 11, color: DS.primaryHi, letterSpacing: 1 }}>{r.week}</div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <div style={{ width: 8, height: 8, borderRadius: 4, background: c, boxShadow: `0 0 6px ${c}` }} />
                    <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: c, letterSpacing: 0.3 }}>{r.load.toUpperCase()}</div>
                  </div>
                  <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 13, color: DS.tx2, lineHeight: 1.45 }}>{r.changes}</div>
                </div>
              );
            })}
          </div>
        </Sub>

        <Reason
          ux="UI maturity is a feature. A power-user view emerges by attrition of helper text, not addition of complexity."
          psych="A user who feels the app 'breathing alongside them' instead of 'teaching them' has the strongest possible attachment. This is the long-term moat."
          impl="usage_age_days field on user → conditional UI hiding. Tested via cohort views (D7, D30, D90 user lands on Today — different surface). CI snapshots per cohort."
        />
      </Section>
    </>
  );
}

// ── Calm-energetic spectrum component
function CalmSpectrum() {
  const items = [
    { l: 'Evening reflect',  v: 0.05, hue: '#7EE0B8' },
    { l: 'Profile',          v: 0.18, hue: '#C9A0FF' },
    { l: 'Finance review',   v: 0.30, hue: '#F4C16A' },
    { l: 'Health log',       v: 0.42, hue: '#7EE0B8' },
    { l: 'Today (midday)',   v: 0.55, hue: '#7FB8FF' },
    { l: 'Today (morning)',  v: 0.65, hue: '#A584FF' },
    { l: 'Habit completion', v: 0.75, hue: '#FF99C5' },
    { l: 'Streak save',      v: 0.85, hue: '#FF8C3C' },
    { l: 'Level up overlay', v: 0.96, hue: '#FFD66B' },
  ];
  return (
    <div style={{ padding: '22px 18px 18px', borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}` }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: DS.tx3, letterSpacing: 1.5 }}>
        <span style={{ color: '#7EE0B8' }}>← CALM (Headspace)</span>
        <span style={{ color: '#FFD66B' }}>ENERGETIC (Duolingo) →</span>
      </div>
      <div style={{ position: 'relative', height: 110, marginTop: 8 }}>
        <div style={{
          position: 'absolute', top: 22, left: 0, right: 0, height: 4, borderRadius: 2,
          background: 'linear-gradient(90deg, #7EE0B8, #7FB8FF, #A584FF, #FFD66B)',
          boxShadow: '0 0 20px rgba(165,132,255,0.2)',
        }} />
        {items.map((it, i) => (
          <div key={i} style={{
            position: 'absolute', left: `${it.v * 100}%`,
            transform: `translateX(-50%) ${i % 2 ? 'translateY(28px)' : ''}`,
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            top: i % 2 ? 22 : -2,
          }}>
            <div style={{ width: 10, height: 10, borderRadius: 5, background: it.hue, boxShadow: `0 0 10px ${it.hue}`, border: '2px solid #0A0612' }} />
            <div style={{
              padding: '3px 7px', borderRadius: 6, background: 'rgba(0,0,0,0.6)',
              border: `1px solid ${it.hue}55`,
              fontFamily: 'DM Sans, system-ui', fontSize: 10.5, color: DS.tx, whiteSpace: 'nowrap',
            }}>{it.l}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px dashed ${DS.borderHi}`, fontFamily: 'DM Sans, system-ui', fontSize: 12.5, color: DS.tx2, lineHeight: 1.55 }}>
        Reading: <b style={{ color: DS.tx }}>Evening reflect</b> at 0.05 is intentionally the calmest moment in the entire app — Headspace-end. <b style={{ color: DS.tx }}>Level-up overlay</b> at 0.96 is the only place we fully embrace Duolingo energy. Everything else lives at a calibrated point on the spectrum.
      </div>
    </div>
  );
}

// ── Cognitive load curve — line chart over weeks
function CognitiveLoadCurve() {
  const w = 720, h = 220;
  // Weeks 0 → 26, load high → low
  const pts = [
    [0,   190], // W0 hero load (during onboarding)
    [40,  100], // W1 stabilises
    [120, 90],
    [200, 80],
    [280, 70],
    [380, 55],
    [480, 45],
    [580, 38],
    [680, 34],
  ];
  const path = pts.map((p, i) => i === 0 ? `M ${p[0]} ${p[1]}` : `C ${pts[i-1][0]+50} ${pts[i-1][1]}, ${p[0]-50} ${p[1]}, ${p[0]} ${p[1]}`).join(' ');
  const area = `${path} L ${pts[pts.length-1][0]} ${h} L ${pts[0][0]} ${h} Z`;
  return (
    <div style={{ padding: 18, borderRadius: 16, background: DS.card, border: `1px solid ${DS.border}`, marginTop: 14 }}>
      <svg width="100%" height={h} viewBox={`0 0 ${w} ${h + 30}`}>
        <defs>
          <linearGradient id="load-area" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#A584FF" stopOpacity="0.35" />
            <stop offset="1" stopColor="#A584FF" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[40, 80, 120, 160].map(y => (
          <line key={y} x1="0" x2={w} y1={y} y2={y} stroke="rgba(244,239,255,0.05)" strokeWidth="1" />
        ))}
        <path d={area} fill="url(#load-area)" />
        <path d={path} stroke="#A584FF" strokeWidth="2.5" fill="none" strokeLinecap="round" />
        {/* Mark transitions */}
        {[
          { x: 40,  y: 100, l: 'W1' },
          { x: 200, y: 80,  l: 'W2' },
          { x: 380, y: 55,  l: 'W4' },
          { x: 480, y: 45,  l: 'W8' },
          { x: 580, y: 38,  l: 'W12' },
          { x: 680, y: 34,  l: 'W26' },
        ].map(m => (
          <g key={m.l}>
            <circle cx={m.x} cy={m.y} r="5" fill="#FFD66B" stroke="#0A0612" strokeWidth="2" />
            <text x={m.x} y={m.y - 14} fontFamily="JetBrains Mono, monospace" fontSize="10" fill="rgba(244,239,255,0.7)" textAnchor="middle">{m.l}</text>
          </g>
        ))}
        <text x="0"   y={h + 22} fontFamily="JetBrains Mono, monospace" fontSize="10" fill="rgba(244,239,255,0.5)" letterSpacing="1.5">D0  →  USAGE OVER TIME  →  W26</text>
        <text x="0"   y={20}     fontFamily="JetBrains Mono, monospace" fontSize="10" fill="rgba(255,85,119,0.7)" letterSpacing="1.5">HIGH LOAD</text>
        <text x="0"   y={h - 10} fontFamily="JetBrains Mono, monospace" fontSize="10" fill="rgba(126,224,184,0.7)" letterSpacing="1.5">LOW LOAD</text>
      </svg>
    </div>
  );
}

window.UXMeta = UXMeta;
