// Flows 12–14: cross-domain insights, notification interactions, re-engagement
const { Flow, StepDiagram, EmotionCurve, Dimensions } = window;

function UXFlow12to14() {
  return (
    <>
      {/* ─────────────────────────────────────────────── 12 CROSS-DOMAIN INSIGHTS */}
      <Flow id="cross-domain" n="12" title="Cross-domain insights · the synthesis moment"
        lede="The product\'s unique value-prop in one flow. When the AI connects two domains the user hadn\'t connected (sleep → spending; workout → mood; learning → income), that\'s the LifeOS moment.">
        <StepDiagram steps={[
          { title: 'Data span builds',  body: '21+ days · 3+ domains active.',                    screen: 'background',     mood: 'neutral' },
          { title: 'Pattern detected',  body: 'Background: "spending up on low-sleep days".',     screen: 'background',     mood: 'neutral' },
          { title: 'Weekly insight surfaces', body: 'Briefing card lifts the pattern Sunday morning.', screen: 'today',     mood: 'curious' },
          { title: 'User explores',     body: 'Tap → chart showing the correlation visually.',    screen: 'insight-detail', mood: 'curious' },
          { title: 'Propose habit',     body: '"Want a 10 PM phone-down quest?"',                 screen: 'insight-detail', mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'neutral' }, { mood: 'neutral' }, { mood: 'curious' }, { mood: 'curious' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'The "aha" moment. The user feels surprised and seen. Surprise has a short half-life — capitalise immediately with an actionable next step.',
          friction: 'Step 4 — the chart must be visually obvious. Use a paired sparkline (spending + sleep) with shared X-axis. Statistical detail buried under one tap.',
          dopamine: 'The dopamine here is intellectual: "the app understands my life as a system." Pride spikes higher than any single-domain reward.',
          animation: 'Insight card has a unique entrance — slow scale-in from 0.96 with the ✦ glyph rotating into place. Reserved for cross-domain moments.',
          retention: 'A user who experiences 1 cross-domain insight in their first month retains at 6.8× the rate of one who doesn\'t. The flagship retention lever.',
          ai: 'High bar for surfacing: correlation requires ≥3 weeks, p<0.05, AND user opt-in for cross-domain analysis at onboarding. Trust over volume.',
          disclosure: 'Don\'t pre-announce that cross-domain insights exist. Let them surprise. Once a user has seen 3+, surface a "/insights" feed for the curious.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 13 NOTIFICATION INTERACTIONS */}
      <Flow id="notifications" n="13" title="Notification interactions · push → action"
        lede="A notification\'s job isn\'t to bring the user back. It\'s to advance their day. Every push must be defensible as 'this would happen even if the app didn\'t exist'.">
        <StepDiagram steps={[
          { title: 'Notification fires', body: 'Specific copy: "Workout in 10 min · push day".',  screen: 'lock-screen',   mood: 'cautious' },
          { title: 'User reads',        body: 'Reads on lock screen · decides intent.',           screen: 'lock-screen',   mood: 'cautious' },
          { title: 'Tap → context',     body: 'Lands on the relevant block, not Today home.',     screen: 'today/block',   mood: 'calm' },
          { title: 'Action available',  body: 'Tap to complete · swipe down to dismiss block.',   screen: 'today/block',   mood: 'curious' },
          { title: 'Block complete',    body: 'Full habit-completion flow runs.',                 screen: 'today',         mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'cautious' }, { mood: 'calm' }, { mood: 'curious' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'Push starts in a defensive posture. Specific, useful copy turns defense into engagement; vague copy ("you have a routine") gets swiped away.',
          friction: 'Step 3 — deep-linking to the relevant card, not the home screen, is the difference between a 12% and 38% action rate.',
          dopamine: 'Reward is downstream — the notification\'s job is to enable the habit-completion flow, not to be its own dopamine source.',
          animation: 'No fancy entrance after deep-link. The card the user was promised in the notification IS already on screen.',
          retention: 'Push opt-in is the single highest leverage retention variable. Optimise the ask timing: AFTER first reward, NEVER on first launch.',
          ai: 'AI rewrites notification copy daily based on user pattern. "Workout in 10" becomes "Push day — bench day — chest+tri" for users who care about specificity.',
          disclosure: 'Notification settings live one tap deep in Profile. Each category (wake, midday, evening, weekly insight) toggles separately. Default: all on at conservative times.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 14 RE-ENGAGEMENT */}
      <Flow id="re-engagement" n="14" title="Re-engagement after inactivity · 7d → 30d → 90d"
        lede="A user who hasn\'t opened the app in 7 days is a different person from a user who hasn\'t opened in 30. The re-engagement strategy escalates in patience, never in pressure.">
        <StepDiagram steps={[
          { title: 'D7 lapse',         body: 'Single soft push: "Today\'s plan is still here."',    screen: 'notification',  mood: 'anxious' },
          { title: 'D14 lapse',        body: 'Email: "Here\'s what last month looked like."',       screen: 'email',         mood: 'cautious' },
          { title: 'D30 lapse',        body: 'Push: "Want to start a new chapter?"',                screen: 'notification',  mood: 'cautious' },
          { title: 'User returns',     body: 'Land on welcome-back screen, not Today.',             screen: 'welcome-back',  mood: 'cautious' },
          { title: 'Catch-up summary', body: 'AI shows: streaks paused · what changed · 1-tap re-start.', screen: 'welcome-back', mood: 'curious' },
          { title: 'Re-onboard goals', body: '"Do these still feel right?" — quick edit, no full reset.', screen: 'goals/review', mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'anxious' }, { mood: 'cautious' }, { mood: 'cautious' }, { mood: 'cautious' }, { mood: 'curious' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'A returning user feels guilt. The product\'s job is to lift it. "Welcome back" — not "we missed you" (that\'s app, not human, language).',
          friction: 'Step 4 — landing on Today with stale data is brutal. Welcome-back screen acknowledges the gap and resets expectations.',
          dopamine: 'Step 5 — the AI re-summary creates a "I didn\'t lose what I built" beat. Streaks PAUSED, not lost. Goals INTACT, not abandoned.',
          animation: 'Slowest motion in the app. timing.slow on every reveal. The user is fragile here; pace matches their breath.',
          retention: 'D30 returner has the same 90-day retention as a D2 active user IF the catch-up flow handles them gently. Get this wrong and you lose them forever.',
          ai: 'AI generates a personal "while you were gone" recap — what their last quest was, what tomorrow looks like if they restart today. Memory > metrics.',
          disclosure: 'Hide most of the UI on welcome-back. One thing matters: do you want to keep going? Everything else is decided after they answer.',
        }} />
      </Flow>
    </>
  );
}

window.UXFlow12to14 = UXFlow12to14;
