// Flows 1–4: onboarding, first-time activation, daily engagement, goal creation
const { Flow, StepDiagram, EmotionCurve, Dimensions } = window;

function UXFlow1to4() {
  return (
    <>
      {/* ─────────────────────────────────────────────── 01 ONBOARDING */}
      <Flow id="onboarding" n="1" title="Onboarding · vision → first routine"
        lede="Three-screen onboarding compresses 'what is this app' into a tangible, AI-generated daily plan. The goal is to get the user from 'I downloaded this' to 'this knows me' in under 6 minutes.">
        <StepDiagram steps={[
          { title: 'Welcome',        body: '2 lines about the promise. One button.',           screen: 'welcome',          mood: 'curious' },
          { title: 'Vision intent',  body: 'One sentence about who they want to be.',           screen: 'welcome-intent',   mood: 'cautious' },
          { title: 'Discovery paste',body: 'Optional · paste a journal, LinkedIn, anything.',   screen: 'discovery-paste',  mood: 'cautious' },
          { title: 'AI synthesises', body: 'Loading state shows the AI thinking out loud.',     screen: 'discovery-confirm',mood: 'curious' },
          { title: 'Routine preview',body: 'A real, time-blocked Monday morning.',              screen: 'day1-routine',     mood: 'excited' },
          { title: 'First Today',    body: '"Tap your first block." Pre-empts the void.',       screen: '(tabs)/index',     mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'curious' }, { mood: 'cautious' }, { mood: 'cautious' }, { mood: 'curious' }, { mood: 'excited' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'Curiosity → caution → relief → ownership. The drop at step 2 is normal (any input screen creates hesitation); steps 4–5 must over-correct it.',
          friction: 'Step 3 (paste) is optional but most-skipped — keep skip prominent. Step 4\'s loading state is the single highest abandon risk if it exceeds 8s.',
          dopamine: 'Step 5 reveals a real, personalised routine. Step 6 awards the first +10 XP for tapping a block. Both must feel earned, not given.',
          animation: 'FadeInDown stagger (timing.slow · 600ms) per section reveal. Routine blocks land 40ms apart. The hex radar polygon morphs in over 800ms.',
          retention: 'A user who completes Step 5 retains at >70% to D7. A user who exits at Step 3 retains at <15%. This is the conversion gate.',
          ai: 'The AI is the protagonist here. Surface its thinking ("Reading your vision… mapping to a yearly goal… proposing a routine…") — never just a spinner.',
          disclosure: 'Hide the 6 engines. Hide the hex radar. Hide XP. The user sees ONE thing per screen. Everything else unfolds in the days that follow.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 02 ACTIVATION */}
      <Flow id="activation" n="2" title="First-time activation · D0 → D1"
        lede="Activation is the first 24 hours after onboarding. The user must (a) complete at least one block, (b) feel one reward beat, and (c) form an intent to return tomorrow.">
        <StepDiagram steps={[
          { title: 'First Today land', body: 'Hex radar at low scores. Single CTA: tap a block.', screen: 'today',     mood: 'cautious' },
          { title: 'Block complete',   body: 'Tap check → spring + haptic + +10 XP flies up.',    screen: 'today',     mood: 'proud' },
          { title: 'Voice prompt',     body: 'Tooltip: "Ask me anything about today."',           screen: 'today',     mood: 'curious' },
          { title: 'First quest',      body: 'A daily quest auto-generates: "Log 1 meal".',       screen: 'today',     mood: 'curious' },
          { title: 'Push opt-in',      value: '8 PM evening', body: 'Soft ask after the first reward beat. ~3× higher conversion.', screen: 'system-modal', mood: 'cautious' },
          { title: 'D+1 wake nudge',   body: '"Yesterday you did X. Today\'s plan is ready."',    screen: 'notification', mood: 'excited' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'proud' }, { mood: 'curious' }, { mood: 'curious' }, { mood: 'cautious' }, { mood: 'excited' },
        ]} />
        <Dimensions items={{
          emotion: 'Reward (step 2) is the only locked-in high. The dip at step 5 (opt-in) is unavoidable; the climb at step 6 must feel like the app missed them.',
          friction: 'Step 1: blank radar (all zeros) is depressing. Seed scores at 30–45 from onboarding signals so it looks like the app already knows them.',
          dopamine: 'Step 2 — first XP fly + spring + haptic + briefing-card morph. This single moment determines D7 retention more than any other.',
          animation: 'XP chip flies from block → rail (250ms · timing.normal). Rail glows (one frame). Block ticks done. Briefing recomposes ("3 blocks · 1 done").',
          retention: 'D1 return is gated on push opt-in AND a personal block-complete experience. Both matter; neither sufficient alone.',
          ai: 'Generate the first quest based on which onboarding domain was strongest. If user said "lose 10kg" — first quest is health. Identity-aligned quests retain 2.3× better.',
          disclosure: 'Day 1 only shows: hex radar (low fidelity), 1 routine, 1 quest, voice FAB. Streaks come D2. Badges come D7. Profile comes when prompted.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 03 DAILY LOOP */}
      <Flow id="daily-loop" n="3" title="Daily engagement loop · morning → evening"
        lede="The core habit. A retained user opens LifeOS 3–5 times daily across distinct emotional postures. Each session has a different job; the UI must adapt without becoming inconsistent.">
        <StepDiagram steps={[
          { title: '06:30 wake nudge', body: 'Notification with today\'s headline block.',  screen: 'notification', mood: 'cautious' },
          { title: 'Morning land',     body: 'Today screen. Hex radar + briefing.',         screen: 'today',        mood: 'curious' },
          { title: 'Block ticks',      body: '2–4 blocks completed before noon.',           screen: 'today',        mood: 'proud' },
          { title: 'Midday check',     body: 'Quick log: meal, transaction, mood.',         screen: 'health/finance', mood: 'calm' },
          { title: 'Afternoon nudge',  body: '3 PM goal reminder if no progress.',          screen: 'notification', mood: 'cautious' },
          { title: 'Evening reflect',  body: '60s wrap. Tomorrow preview.',                 screen: 'evening-reflect', mood: 'calm' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'cautious' }, { mood: 'curious' }, { mood: 'proud' }, { mood: 'calm' }, { mood: 'cautious' }, { mood: 'calm' },
        ]} />
        <Dimensions items={{
          emotion: 'Morning is curious and forward-looking; midday is task-focused; evening is reflective. The product must read as three different times of day on the same screen design.',
          friction: 'Step 5 (3 PM nudge) risks irritation if blocks ARE getting done. Suppress when same-day block-completion ≥40%.',
          dopamine: 'Step 3 — accumulated XP visible on the rail. Step 6 — streak-save haptic if today is the second day in a row.',
          animation: 'No animation on data refresh (Principle M4). Each new app open is a quiet fade-in (timing.fast 150ms) — no re-stagger.',
          retention: 'The midday check (step 4) is the keystone — users with 3+ daily opens retain at 5× D30. Voice + photo log keep this <10s.',
          ai: 'AI quietly rewrites the briefing at noon and 6 PM based on accumulated events. User sees a fresh, contextual message each session.',
          disclosure: 'Same screen, different state. Morning shows full routine; midday shows "your next block" + quick actions; evening shifts to reflection CTA.',
        }} />
      </Flow>

      {/* ─────────────────────────────────────────────── 04 GOAL CREATION */}
      <Flow id="goal-creation" n="4" title="Goal creation · vision → hierarchy"
        lede="A user states a goal in plain English. The AI decomposes it into yearly/monthly/weekly/daily tasks. The user must feel like co-author, never recipient.">
        <StepDiagram steps={[
          { title: 'New goal CTA',     body: 'Plus button in Goals tab. Single textarea.',     screen: 'goals',          mood: 'curious' },
          { title: 'Write vision',     body: 'AI offers prompts if blank ("relationships, career…").', screen: 'goals/new', mood: 'cautious' },
          { title: 'AI decomposes',    body: 'Yearly → monthly → weekly → daily appears live.', screen: 'goals/new',     mood: 'curious' },
          { title: 'Review hierarchy', body: 'User can edit/remove/regenerate any node.',       screen: 'goals/review',  mood: 'cautious' },
          { title: 'Commit',           body: 'Goal sits in tree. First task lands on Today.',   screen: 'goals',         mood: 'proud' },
        ]} />
        <EmotionCurve steps={[
          { mood: 'curious' }, { mood: 'cautious' }, { mood: 'curious' }, { mood: 'cautious' }, { mood: 'proud' },
        ]} />
        <Dimensions items={{
          emotion: 'Goal-setting is high-stakes. The user fears commitment as much as the failure of it. Soft language ("a direction" not "your goal") lowers the barrier.',
          friction: 'Step 4 — if the AI hierarchy looks wrong, regenerating must take <3s OR the user gives up. Cache 2 variations to swap instantly.',
          dopamine: 'Step 3 — the hierarchy unfolding feels like watching the future map itself. Stagger 200ms per level.',
          animation: 'Tree-build animation: each node fades in with a soft connecting line (timing.normal). Active edit row pulses violet on save.',
          retention: 'Users who edit ≥1 AI suggestion retain 2× better than passive accepters. Surface edit affordance prominently.',
          ai: 'AI doesn\'t just decompose — it also flags risks ("This goal conflicts with your sleep target"). One soft callout per goal.',
          disclosure: 'Show daily tasks immediately. Hide the monthly/yearly view unless tapped. Most users only ever care about tomorrow.',
        }} />
      </Flow>
    </>
  );
}

window.UXFlow1to4 = UXFlow1to4;
