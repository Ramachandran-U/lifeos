// Motion scenes — part 1
// 01 Entry stagger · 02 Long-press complete · 03 Hex morph · 04 Streak +1 · 05 Badge unlock

const { ProFrame, Surface, Display, Title, Body, Meta, Avatar, HexRadar, XpBar,
        TimelineBlock, TabBar, Icon, MicFab, SURF, R, DOMAINS } = window;
const { M, E, clamp, lerp, range, rangeAt, segment, useLoopTime, useDrift, SceneFrame } = window;

// ─────────────────────────────────────────────────────────────
// 01 — Mount entry stagger.
// Today screen lands in 1.4s. Aurora wash → greeting → headline → radar → timeline.
// Each layer arrives a beat later. Settled state breathes ambiently for the rest of
// the loop. Designed to feel like a held breath that releases.
// ─────────────────────────────────────────────────────────────
function MountEntry() {
  const DUR = 4200;
  const t = useLoopTime(DUR);

  // Stage progressions
  const auroraP    = segment(t, 0,    420, E.out);
  const greetP     = segment(t, 220,  520, E.spring);
  const headlineP  = segment(t, 480,  640, E.soft);
  const radarP     = segment(t, 760,  720, E.out);
  const radarDotsP = segment(t, 1100, 380, E.spring);
  const rowsBaseP  = segment(t, 1280, 60, E.out); // start

  // Per-row stagger
  const rowAt = (i) => segment(t, 1280 + i * 70, 420, E.spring);

  // Live-block ambient breathing (after mount)
  const breathT   = clamp((t - 2400) / DUR);
  const breath    = Math.sin(breathT * Math.PI * 4) * 0.5 + 0.5; // 0..1
  const liveScale = lerp(1, 1.006, breath);
  const liveAlpha = lerp(0.88, 1.0, breath);

  return (
    <SceneFrame
      title="01 · First mount"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 0,    label: 'Aurora wash fades in',         spec: '420 ms · ease-out' },
        { at: 220,  label: 'Greeting row springs up',      spec: '520 ms · spring' },
        { at: 480,  label: 'Headline mask reveal',         spec: '640 ms · soft-out' },
        { at: 760,  label: 'Hex polygon strokes',          spec: '720 ms · out' },
        { at: 1280, label: '6 timeline rows · stagger 70', spec: '420 ms · spring' },
        { at: 2400, label: 'Settled · ambient breath',     spec: 'live block · sine 1.4 s' },
      ]}
      footer={<div style={{ paddingBottom: 12, opacity: rowsBaseP }}><TabBar active="today" /></div>}
    >
      {/* Aurora */}
      <div style={{ position: 'absolute', inset: 0, opacity: auroraP, pointerEvents: 'none' }}>
        <div style={{
          position: 'absolute', top: -180, left: -80, width: 360, height: 360, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(165,132,255,0.22), rgba(165,132,255,0) 70%)',
          filter: 'blur(28px)',
        }} />
      </div>

      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 16, position: 'relative' }}>
        {/* Greeting */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 14, marginTop: 10,
          opacity: greetP, transform: `translateY(${(1 - greetP) * 10}px)`,
        }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <Meta size={9.5} color={SURF.tx3}>Tue · May 13 · day 47</Meta>
            <Title size={20} style={{ marginTop: 2, letterSpacing: -0.4 }}>Good morning, Arjun</Title>
          </div>
          <div style={{ opacity: greetP }}><MicFab /></div>
        </div>

        {/* Headline — mask reveal via clip-path */}
        <div style={{ paddingTop: 6, paddingBottom: 2, position: 'relative' }}>
          <div style={{
            clipPath: `inset(0 ${(1 - headlineP) * 100}% 0 0)`,
            transition: 'none',
          }}>
            <Display size={26} style={{ letterSpacing: -0.5, lineHeight: 1.18 }}>
              One thing today.<br/>
              <span style={{ color: SURF.tx2 }}>The </span>
              <span style={{ color: '#C5B3FF' }}>ML mock at 4 PM</span>
              <span style={{ color: SURF.tx2 }}> — the rest is rhythm.</span>
            </Display>
          </div>
        </div>

        {/* Radar surface — fade + scale */}
        <div style={{
          opacity: radarP,
          transform: `translateY(${(1 - radarP) * 8}px) scale(${lerp(0.98, 1, radarP)})`,
        }}>
          <Surface level={1} padding={16} radius={R.lg}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <div style={{ flex: '0 0 auto', position: 'relative' }}>
                <RadarReveal p={radarP} dotsP={radarDotsP} />
              </div>
              <div style={{ flex: 1 }}>
                <Meta>Life balance</Meta>
                <Display size={36} style={{ lineHeight: 1, marginTop: 4 }}>
                  {Math.round(64 * radarDotsP)}
                </Display>
                <Meta color="#7EE0B8" style={{ marginTop: 8, opacity: radarDotsP }}>▲ 4 wk</Meta>
              </div>
            </div>
          </Surface>
        </div>

        {/* Timeline */}
        <div style={{ display: 'flex', flexDirection: 'column', marginTop: 4 }}>
          {[
            { time: '06:30', title: 'Wake · sunlight · 16oz water', mod: 'health',  status: 'completed' },
            { time: '07:00', title: 'Strength · push day',          mod: 'health',  status: 'completed' },
            { time: '09:00', title: 'Deep work · spec for Q3',      mod: 'goal',    live: true },
            { time: '12:30', title: 'Lunch · 600 kcal',             mod: 'health' },
            { time: '14:00', title: 'Andrew Ng · L4',               mod: 'polymath' },
            { time: '16:00', title: 'ML mock · system design',      mod: 'career' },
          ].map((r, i, arr) => {
            const rp = rowAt(i);
            return (
              <div key={i} style={{
                opacity: rp,
                transform: `translateY(${(1 - rp) * 12}px) ${r.live ? `scale(${liveScale})` : ''}`,
              }}>
                <TimelineBlock
                  first={i === 0} last={i === arr.length - 1}
                  time={r.time} title={r.title} module={r.mod}
                  status={r.status} live={r.live}
                  style={r.live ? { opacity: liveAlpha } : undefined}
                />
              </div>
            );
          })}
        </div>
      </div>
    </SceneFrame>
  );
}

// Hex radar with progressive reveal — polygon strokes in, fill fades, dots stagger
function RadarReveal({ p = 1, dotsP = 1, size = 140 }) {
  const cx = size / 2, cy = size / 2;
  const r = size * 0.36;
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  const scores = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };
  const angles = keys.map((_, i) => -Math.PI / 2 + (i * Math.PI / 3));
  const point = (i, scale) => [cx + Math.cos(angles[i]) * r * scale, cy + Math.sin(angles[i]) * r * scale];

  const polyPoints = keys.map((k, i) => {
    const [x, y] = point(i, (scores[k] / 100) * p);
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <linearGradient id="hex-fill-m1" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#A584FF" stopOpacity="0.28" />
          <stop offset="1" stopColor="#7EE0B8" stopOpacity="0.22" />
        </linearGradient>
      </defs>
      {[0.33, 0.66, 1].map((s, gi) => {
        const pts = keys.map((_, i) => {
          const [x, y] = point(i, s);
          return `${x},${y}`;
        }).join(' ');
        return <polygon key={gi} points={pts} fill="none" stroke="rgba(244,239,255,0.07)" strokeWidth="1" opacity={p} />;
      })}
      <polygon points={polyPoints} fill="url(#hex-fill-m1)" stroke="rgba(197,179,255,0.7)" strokeWidth="1.25" strokeLinejoin="round" opacity={p} />
      {keys.map((k, i) => {
        const [x, y] = point(i, (scores[k] / 100));
        return <circle key={k} cx={x} cy={y} r={3 * dotsP} fill={DOMAINS[k].hue} opacity={dotsP} />;
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// 02 — Long-press to complete.
// Cinematic completion moment for a workout block.
// Press → fill → ring → tick draws → XP toast → block falls into "done" tier.
// ─────────────────────────────────────────────────────────────
function LongPressComplete() {
  const DUR = 4400;
  const t = useLoopTime(DUR);

  const idleAlpha     = 1 - segment(t, 3600, 800, E.out);   // resets at end
  const pressP        = segment(t, 200, 1000, E.inOut);     // fill arc
  const pressDone     = pressP >= 1;
  const ringP         = segment(t, 1200, 360, E.out);       // expansion
  const ringFade      = segment(t, 1280, 320, E.in);
  const tickP         = segment(t, 1400, 320, E.out);
  const tickStroke    = lerp(14, 0, tickP);
  const toastP        = segment(t, 1700, 360, E.spring);
  const toastY        = lerp(12, 0, toastP);
  const toastHold     = clamp(1 - segment(t, 2900, 600, E.in)); // fades 2.9-3.5s
  const blockDoneP    = segment(t, 1700, 420, E.out); // block transitions to done tier

  const hue = DOMAINS.health.hue;

  return (
    <SceneFrame
      title="02 · Long-press to complete"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 200,  label: 'Press · radial arc fills',     spec: '1.0 s · ease-in-out' },
        { at: 1200, label: 'Haptic ring · single tick',    spec: '360 ms · expand · fade' },
        { at: 1400, label: 'Checkmark draws live',         spec: '320 ms · ease-out · 14 px stroke' },
        { at: 1700, label: 'XP toast lifts in',            spec: '360 ms · soft spring · y -12' },
        { at: 2100, label: 'Block falls to done · 55 %',   spec: '420 ms · ease-out' },
        { at: 2900, label: 'Toast dissolves',              spec: '600 ms · ease-in' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Today's flow</Title>
          </div>
        </div>

        {/* Earlier blocks — already done */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <TimelineBlock first time="06:30" title="Wake · sunlight" module="health" status="completed" />
        </div>

        {/* The completing block */}
        <div style={{ position: 'relative', paddingTop: 4, paddingBottom: 6 }}>
          {/* Haptic ring */}
          {ringP > 0 && ringFade < 1 && (
            <div style={{
              position: 'absolute', left: 26, top: 24, width: 16, height: 16, borderRadius: 16,
              border: `1.5px solid ${hue}`,
              transform: `translate(-50%, -50%) scale(${1 + ringP * 4})`,
              opacity: (1 - ringFade) * 0.7,
              pointerEvents: 'none',
            }} />
          )}
          {/* Custom block to control press-progress visual */}
          <div style={{ display: 'flex', gap: 14, alignItems: 'flex-start' }}>
            <div style={{ width: 18, position: 'relative', paddingTop: 14, flexShrink: 0 }}>
              <div style={{
                width: 11, height: 11, borderRadius: 6,
                background: pressDone ? hue : SURF.bg,
                border: `1.5px solid ${hue}`,
                margin: '0 auto',
                boxShadow: pressDone ? `0 0 0 5px ${hue}22` : 'none',
                transition: 'background 200ms, box-shadow 220ms',
              }} />
            </div>
            <div style={{
              flex: 1,
              background: `linear-gradient(180deg, ${hue}${pressDone ? '22' : '14'}, ${hue}06)`,
              border: `1px solid ${hue}${pressDone ? '66' : '44'}`,
              borderRadius: R.md,
              padding: '12px 14px',
              opacity: lerp(1, 0.55, blockDoneP),
              transform: `scale(${lerp(1, 0.99, blockDoneP)})`,
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <Meta size={10} color={SURF.tx3} style={{ minWidth: 40 }}>07:00</Meta>
                <Title size={14.5} style={{ flex: 1, textDecorationLine: blockDoneP > 0.5 ? 'line-through' : 'none', textDecorationColor: SURF.tx3 }}>Strength · push day</Title>
                {/* Check chip */}
                <div style={{
                  width: 22, height: 22, borderRadius: 11,
                  background: pressDone ? hue : 'transparent',
                  border: `1.5px solid ${pressDone ? hue : SURF.hairlineStrong}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  transition: 'background 220ms, border-color 220ms',
                }}>
                  {pressDone && (
                    <svg width="14" height="14" viewBox="0 0 14 14">
                      <path d="M3 7 L6 10 L11 4" stroke={SURF.bg} strokeWidth="2.5" fill="none"
                        strokeLinecap="round" strokeLinejoin="round"
                        strokeDasharray="14" strokeDashoffset={tickStroke} />
                    </svg>
                  )}
                </div>
              </div>
              {/* Press progress bar — visible only while pressing */}
              <div style={{
                marginTop: 10, height: 2.5, borderRadius: 2,
                background: 'rgba(255,255,255,0.06)', overflow: 'hidden',
                opacity: pressP < 1 ? 1 : (1 - clamp((t - 1200) / 600)),
              }}>
                <div style={{ width: `${pressP * 100}%`, height: '100%', background: hue }} />
              </div>
              <Body size={10.5} color={SURF.tx3} style={{
                marginTop: 6,
                opacity: pressP < 1 ? lerp(0.4, 0.8, pressP) : (1 - clamp((t - 1200) / 600)),
              }}>
                {pressP < 1 ? 'Hold to confirm · release to log' : ''}
              </Body>
            </div>
          </div>
        </div>

        {/* XP toast */}
        {toastP > 0 && toastHold > 0 && (
          <div style={{
            alignSelf: 'center',
            padding: '8px 14px', borderRadius: R.pill,
            background: 'rgba(126,224,184,0.14)',
            border: '1px solid rgba(126,224,184,0.36)',
            display: 'flex', alignItems: 'center', gap: 8,
            opacity: toastP * toastHold,
            transform: `translateY(${toastY}px)`,
            backdropFilter: 'blur(12px)',
          }}>
            <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
            <Meta color="#7EE0B8">+10 xp · health</Meta>
            <Meta size={9} color={SURF.tx3}>streak 13 →</Meta>
          </div>
        )}

        {/* Remaining blocks — calmly waiting */}
        <div style={{ display: 'flex', flexDirection: 'column', opacity: 0.85 }}>
          <TimelineBlock first time="09:00" title="Deep work · spec" module="goal" live />
          <TimelineBlock time="12:30" title="Lunch · 600 kcal" module="health" />
          <TimelineBlock last time="14:00" title="Andrew Ng · L4" module="polymath" />
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 03 — Hex radar progress morph.
// AI suggests an update to one domain; the polygon morphs smoothly,
// the affected dot pulses, the score number ticks up.
// ─────────────────────────────────────────────────────────────
function HexMorph() {
  const DUR = 5400;
  const t = useLoopTime(DUR);

  const sparkleP = segment(t, 300, 320, E.out);
  const sparkleFade = 1 - segment(t, 900, 400, E.in);

  // Morph progress (forward 1.0 → 2.6s, hold, reverse 4.0 → 4.8s)
  const fwd = segment(t, 1000, 1600, E.inOut);
  const rev = segment(t, 4000, 800, E.in);
  const morphP = clamp(fwd - rev);

  // Affected domain label pulse
  const labelPulse = E.pulse(segment(t, 1900, 800, (x) => x));

  // Score number tick
  const baseScore = 64;
  const targetScore = 71;
  const score = Math.round(lerp(baseScore, targetScore, morphP));

  return (
    <SceneFrame
      title="03 · AI raises a domain"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 300,  label: 'Sparkle pulse · domain marker',  spec: '320 ms · ease-out' },
        { at: 1000, label: 'Polygon morphs forward',          spec: '1.6 s · ease-in-out' },
        { at: 1900, label: 'Label pulses once',               spec: '800 ms · bell' },
        { at: 2600, label: 'Score ticks 64 → 71',             spec: 'linked to morph' },
        { at: 4000, label: 'Resets reverse · ease-in',        spec: '800 ms · for loop' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Today</Title>
          </div>
        </div>

        {/* AI Suggestion banner — appears briefly */}
        <div style={{
          padding: '10px 14px', borderRadius: R.md,
          background: 'rgba(165,132,255,0.08)',
          border: '1px solid rgba(165,132,255,0.28)',
          display: 'flex', alignItems: 'center', gap: 10,
          opacity: rangeAt(t, 200, 800, E.out) * (1 - rangeAt(t, 4400, 800, E.in)),
        }}>
          <Icon name="sparkle" size={14} color="#C5B3FF" />
          <Body size={12} color={SURF.tx1} style={{ flex: 1, lineHeight: 1.4 }}>
            Three career blocks this week brought you up <span style={{ color: '#C5B3FF', fontWeight: 600 }}>+7 points</span>.
          </Body>
        </div>

        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{ position: 'relative' }}>
              <HexMorphSvg p={morphP} sparkleP={sparkleP * sparkleFade} labelPulse={labelPulse} />
            </div>
            <div style={{ flex: 1 }}>
              <Meta>Life balance</Meta>
              <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 4 }}>
                <Display size={36} style={{ lineHeight: 1 }}>{score}</Display>
                <Meta size={10} color="#7EE0B8" style={{ opacity: morphP }}>+7</Meta>
              </div>
              <div style={{ marginTop: 14, display: 'flex', flexDirection: 'column', gap: 6 }}>
                {['goal', 'polymath', 'career'].map((k, i) => {
                  const d = DOMAINS[k];
                  const isAffected = k === 'career';
                  return (
                    <div key={k} style={{
                      display: 'flex', alignItems: 'center', gap: 8,
                      opacity: isAffected ? lerp(1, 1, 1) : 0.8,
                    }}>
                      <div style={{
                        width: 5, height: 5, borderRadius: 3, background: d.hue,
                        transform: isAffected ? `scale(${1 + labelPulse * 0.6})` : 'scale(1)',
                      }} />
                      <Body size={11.5} color={isAffected ? SURF.tx1 : SURF.tx2} style={{ flex: 1, fontFamily: 'DM Sans' }}>{d.label}</Body>
                      <Meta size={10} color={isAffected ? d.hue : SURF.tx3}>
                        {isAffected ? Math.round(lerp(64, 71, morphP)) : (k === 'goal' ? 78 : 82)}
                      </Meta>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </Surface>

        {/* Note */}
        <Surface level={1} padding={12} radius={R.md}>
          <Body size={11.5} color={SURF.tx2} style={{ lineHeight: 1.5 }}>
            Score changes don't snap — the polygon morphs at the same speed as the number ticks. The single affected dot pulses; everything else stays still.
          </Body>
        </Surface>
      </div>
    </SceneFrame>
  );
}

function HexMorphSvg({ p, sparkleP, labelPulse }) {
  const size = 140;
  const cx = size / 2, cy = size / 2;
  const r = size * 0.36;
  const keys = ['goal', 'health', 'finance', 'career', 'social', 'polymath'];
  const A = { goal: 78, health: 64, finance: 52, career: 64, social: 38, polymath: 82 };
  const B = { goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 };
  const angles = keys.map((_, i) => -Math.PI / 2 + (i * Math.PI / 3));
  const point = (i, scale) => [cx + Math.cos(angles[i]) * r * scale, cy + Math.sin(angles[i]) * r * scale];

  const polyPoints = keys.map((k, i) => {
    const s = lerp(A[k], B[k], p) / 100;
    const [x, y] = point(i, s);
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <defs>
        <linearGradient id="hex-fill-m3" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#A584FF" stopOpacity="0.28" />
          <stop offset="1" stopColor="#7EE0B8" stopOpacity="0.22" />
        </linearGradient>
      </defs>
      {[0.33, 0.66, 1].map((s, gi) => {
        const pts = keys.map((_, i) => {
          const [x, y] = point(i, s);
          return `${x},${y}`;
        }).join(' ');
        return <polygon key={gi} points={pts} fill="none" stroke="rgba(244,239,255,0.07)" strokeWidth="1" />;
      })}
      <polygon points={polyPoints} fill="url(#hex-fill-m3)" stroke="rgba(197,179,255,0.7)" strokeWidth="1.25" strokeLinejoin="round" />
      {keys.map((k, i) => {
        const s = lerp(A[k], B[k], p) / 100;
        const [x, y] = point(i, s);
        const affected = k === 'career';
        return (
          <g key={k}>
            {affected && sparkleP > 0 && (
              <circle cx={x} cy={y} r={3 + sparkleP * 8} fill="none" stroke={DOMAINS[k].hue} strokeWidth="1.5" opacity={1 - sparkleP} />
            )}
            <circle cx={x} cy={y} r={affected ? 3 + labelPulse * 1.6 : 3} fill={DOMAINS[k].hue} />
          </g>
        );
      })}
    </svg>
  );
}

// ─────────────────────────────────────────────────────────────
// 04 — Streak +1 tick.
// Number rolls 12 → 13 with a soft bounce; flame inhales then settles.
// The "+1" particle drifts up and dissolves.
// ─────────────────────────────────────────────────────────────
function StreakTick() {
  const DUR = 4000;
  const t = useLoopTime(DUR);

  // Anticipation — flame inhales (scale down a hair before)
  const inhale  = segment(t, 600, 200, E.in);
  // Tick — old number slides up out, new number springs in from below
  const tickOut = segment(t, 800, 220, E.in);
  const tickIn  = segment(t, 880, 360, E.bounce);
  // Flame brightens
  const flameP  = segment(t, 800, 420, E.out);
  // +1 particle drift
  const partP   = segment(t, 900, 900, E.out);
  const partFade = 1 - segment(t, 1500, 500, E.in);
  // Settled state hold
  const settled = t > 1800 && t < 3600;

  return (
    <SceneFrame
      title="04 · Streak +1"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 600,  label: 'Flame inhales · anticipation', spec: '200 ms · ease-in' },
        { at: 800,  label: 'Old "12" slides up & fades',   spec: '220 ms · ease-in' },
        { at: 880,  label: 'New "13" springs from below',  spec: '360 ms · soft bounce' },
        { at: 900,  label: '+1 particle lifts and fades',  spec: '900 ms · ease-out' },
        { at: 1800, label: 'Settled · subtle ember pulse', spec: 'sine 3 s · 4 % size' },
      ]}
    >
      <div style={{ padding: '40px 20px 0', display: 'flex', flexDirection: 'column', gap: 24, alignItems: 'center' }}>
        <Meta>Workout streak</Meta>

        {/* Flame + number */}
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center', gap: 14, padding: '14px 20px', borderRadius: R.xl, background: SURF.s1, border: `1px solid ${SURF.hairline}` }}>
          {/* Flame */}
          <div style={{
            transform: `scale(${lerp(1, 0.94, inhale) * (1 + (settled ? Math.sin(t / 220) * 0.02 : 0))})`,
            transition: 'none',
          }}>
            <svg width="34" height="34" viewBox="0 0 24 24">
              <defs>
                <linearGradient id="flame-tick" x1="0" y1="1" x2="0" y2="0">
                  <stop offset="0" stopColor="#FF4D2D" stopOpacity={lerp(0.4, 1, flameP)} />
                  <stop offset="0.5" stopColor="#FF8C3C" />
                  <stop offset="1" stopColor="#FFC23A" stopOpacity={lerp(0.7, 1, flameP)} />
                </linearGradient>
              </defs>
              <path d="M12 2 C12 6 8 7 8 12 C8 16 10 19 12 22 C14 19 16 16 16 12 C16 9 14 8 14 5 C13 6 12 5 12 2 Z" fill="url(#flame-tick)" />
            </svg>
          </div>

          {/* Number stack */}
          <div style={{ position: 'relative', width: 56, height: 48, overflow: 'hidden' }}>
            {/* Old 12 — leaves up */}
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Nunito', fontWeight: 900, fontSize: 44, color: SURF.tx1, lineHeight: 1, letterSpacing: -1.2,
              transform: `translateY(${-tickOut * 32}px)`,
              opacity: 1 - tickOut,
            }}>12</div>
            {/* New 13 — arrives from below */}
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: 'Nunito', fontWeight: 900, fontSize: 44, color: SURF.tx1, lineHeight: 1, letterSpacing: -1.2,
              transform: `translateY(${(1 - tickIn) * 32}px)`,
              opacity: tickIn,
            }}>13</div>
          </div>
          <Meta color={SURF.tx3}>days</Meta>

          {/* +1 particle */}
          {partP > 0 && partFade > 0 && (
            <div style={{
              position: 'absolute', right: 18, top: 8,
              transform: `translateY(${-partP * 28}px)`,
              opacity: partP * partFade,
              fontFamily: 'Nunito', fontWeight: 800, fontSize: 13, color: '#FF8C3C',
              pointerEvents: 'none',
            }}>+1</div>
          )}
        </div>

        {/* Companion explanation */}
        <Surface level={1} padding={14} radius={R.md} style={{ marginTop: 8 }}>
          <Title size={13}>What you feel</Title>
          <Body size={11.5} color={SURF.tx2} style={{ marginTop: 6, lineHeight: 1.5 }}>
            One soft haptic on commit. No confetti, no shake, no sound. The number bounces only as much as a finger settling on a desk.
          </Body>
        </Surface>

        {/* Sister streaks — calm, unaffected */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 6, alignSelf: 'stretch', marginTop: 4 }}>
          {[
            { l: 'Learn', c: 47, hue: '#7FB8FF' },
            { l: 'Workout', c: 13, hue: '#7EE0B8', highlight: true },
            { l: 'Food', c: 3, hue: '#C9A0FF' },
            { l: 'Journal', c: 0, hue: '#FFD66B', dim: true },
            { l: 'Social', c: 0, hue: '#FF99C5', dim: true },
          ].map((s, i) => (
            <div key={i} style={{
              padding: '10px 4px', borderRadius: R.sm,
              background: s.highlight ? `${s.hue}14` : SURF.s2,
              border: `1px solid ${s.highlight ? s.hue + '44' : SURF.hairline}`,
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            }}>
              <div style={{
                fontFamily: 'Nunito', fontWeight: 800, fontSize: 16,
                color: s.dim ? SURF.tx4 : SURF.tx1, lineHeight: 1, letterSpacing: -0.4,
              }}>{s.l === 'Workout' ? (tickIn > 0.4 ? 13 : 12) : (s.c || '—')}</div>
              <Meta size={8} color={s.dim ? SURF.tx4 : SURF.tx3} style={{ letterSpacing: 0.7 }}>{s.l}</Meta>
            </div>
          ))}
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 05 — Badge unlock.
// Goes from locked → unlocked. Soft halo blooms, glyph crossfades up,
// label saturates. No confetti, no shimmer, no sound.
// ─────────────────────────────────────────────────────────────
function BadgeUnlock() {
  const DUR = 5200;
  const t = useLoopTime(DUR);

  const haloP    = segment(t, 600, 600, E.out);    // halo expands
  const haloFade = 1 - segment(t, 900, 800, E.in); // halo dissolves
  const glyphP   = segment(t, 750, 520, E.spring); // glyph springs
  const labelP   = segment(t, 900, 600, E.soft);   // label saturates
  const lockOpacity = 1 - segment(t, 600, 300, E.in);

  // Reverse for loop
  const reverseStart = 4200;
  const rev = segment(t, reverseStart, 800, E.in);
  const earned = clamp(Math.max(haloP, glyphP, labelP) - rev);

  const hue = '#FF8C3C';

  return (
    <SceneFrame
      title="05 · Badge unlock · 30-day flame"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 600,  label: 'Lock fades · halo blooms',     spec: '600 ms · ease-out' },
        { at: 750,  label: 'Glyph springs in',             spec: '520 ms · soft spring' },
        { at: 900,  label: 'Label saturates · halo fades', spec: '800 ms · ease-in' },
        { at: 1700, label: 'Settled · subtle ember pulse', spec: 'sine 4 s · 2 % brightness' },
        { at: 4200, label: 'Reset · earned dissolves',     spec: '800 ms · for loop' },
      ]}
    >
      <div style={{ padding: '48px 20px 0', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 18 }}>
        {/* Toast — "30-day flame unlocked" */}
        <div style={{
          padding: '8px 16px', borderRadius: R.pill,
          background: `${hue}1A`, border: `1px solid ${hue}55`,
          display: 'flex', alignItems: 'center', gap: 8,
          opacity: earned,
          transform: `translateY(${(1 - earned) * 8}px)`,
        }}>
          <Icon name="flame" size={12} color={hue} strokeWidth={1.8} />
          <Meta color={hue}>30-day flame · unlocked</Meta>
        </div>

        {/* Big badge */}
        <div style={{
          position: 'relative', width: 200, height: 200,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          marginTop: 6,
        }}>
          {/* Halo bloom — single, soft, no glow */}
          {haloP > 0 && haloFade > 0 && (
            <div style={{
              position: 'absolute', inset: 0, borderRadius: '50%',
              background: `radial-gradient(circle, ${hue}33, ${hue}00 60%)`,
              transform: `scale(${0.7 + haloP * 0.6})`,
              opacity: haloFade * 0.9,
              pointerEvents: 'none',
            }} />
          )}
          {/* Card */}
          <div style={{
            position: 'relative',
            width: 160, height: 160, borderRadius: R.lg,
            background: earned > 0.2 ? SURF.s2 : SURF.s1,
            border: `1.5px solid ${earned > 0.2 ? hue + '88' : SURF.hairline}`,
            display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column',
            transition: 'border-color 320ms, background 320ms',
          }}>
            {/* Lock icon (locked state) */}
            {lockOpacity > 0 && (
              <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: lockOpacity }}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke={SURF.tx4} strokeWidth="1.6" strokeLinecap="round">
                  <rect x="5" y="10" width="14" height="10" rx="2" />
                  <path d="M8 10 V7 a4 4 0 018 0 v3" />
                </svg>
              </div>
            )}
            {/* Glyph (unlocked state) */}
            <div style={{
              fontFamily: 'Nunito', fontWeight: 800, fontSize: 56, color: hue,
              lineHeight: 1, letterSpacing: -2,
              opacity: glyphP,
              transform: `scale(${lerp(0.7, 1, glyphP)})`,
            }}>▲</div>
            <div style={{
              fontFamily: 'Nunito', fontWeight: 800, fontSize: 12, color: lerp(SURF.tx4, hue, labelP) === SURF.tx4 ? SURF.tx4 : SURF.tx1,
              marginTop: 12, opacity: labelP, letterSpacing: -0.1,
            }}>30-day flame</div>
          </div>
        </div>

        {/* Story */}
        <Surface level={1} padding={14} radius={R.md} style={{ marginTop: 10 }}>
          <Body size={12.5} color={SURF.tx1} style={{ lineHeight: 1.55, fontWeight: 500 }}>
            "You logged a workout 30 days in a row."
          </Body>
          <Body size={11.5} color={SURF.tx3} style={{ marginTop: 8, lineHeight: 1.5 }}>
            A single shipped product unlock. The badge stays warm in the rewards tab. The toast vanishes at 1.6 s. Nothing else interrupts the screen the user was on.
          </Body>
        </Surface>
      </div>
    </SceneFrame>
  );
}

Object.assign(window, { MountEntry, LongPressComplete, HexMorph, StreakTick, BadgeUnlock });
