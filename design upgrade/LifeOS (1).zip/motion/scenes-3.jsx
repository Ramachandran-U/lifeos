// Motion scenes — part 3
// 10 Health logging · 11 Idle ambient · Intro motion principles

const { ProFrame, Surface, Display, Title, Body, Meta, Avatar, HexRadar, XpBar,
        TimelineBlock, TabBar, Icon, MicFab, Sparkline, Ring, SURF, R, DOMAINS } = window;
const { M, E, clamp, lerp, range, rangeAt, segment, useLoopTime, useDrift, SceneFrame } = window;

// ─────────────────────────────────────────────────────────────
// 10 — Health logging · photo-to-macros.
// Camera shutter → photo lands → AI scan sweeps → detected items
// fade in sequentially → macro ring fills → save chip lifts.
// ─────────────────────────────────────────────────────────────
function HealthLogging() {
  const DUR = 6000;
  const t = useLoopTime(DUR);

  const shutter   = E.pulse(segment(t, 100, 240, (x) => x));   // single flash
  const photoIn   = segment(t, 300, 480, E.soft);              // photo drops + settles
  const scanP     = segment(t, 700, 1100, E.inOut);            // scan line sweeps
  const scanFade  = 1 - segment(t, 1700, 400, E.in);

  // Detected items appear after scan
  const itemAt = (i) => segment(t, 1700 + i * 90, 460, E.spring);

  // Ring fills
  const ringP = segment(t, 2200, 900, E.out);

  // XP toast lifts in last
  const toastP = segment(t, 3000, 380, E.spring);

  const exitP  = segment(t, 5200, 600, E.in);

  return (
    <SceneFrame
      title="10 · Health · meal logged from photo"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 100,  label: 'Shutter · 50 ms bell flash',         spec: '240 ms · pulse' },
        { at: 300,  label: 'Photo drops in · soft-out',           spec: '480 ms · scale 0.94 → 1' },
        { at: 700,  label: 'AI scan line sweeps top → bottom',    spec: '1.1 s · ease-in-out' },
        { at: 1700, label: 'Detected items fade in · stagger 90 ms', spec: '460 ms · spring' },
        { at: 2200, label: 'Macro ring fills · 900 ms',           spec: 'stroke-dashoffset · ease-out' },
        { at: 3000, label: '+20 xp · slides up · 380 ms',         spec: 'soft spring' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="goals" /></div>}
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 14, opacity: 1 - exitP }}>
        <div style={{ marginTop: 8 }}>
          <Meta color="#7EE0B8">Health</Meta>
          <Display size={22} style={{ marginTop: 4 }}>Lunch · just now</Display>
        </div>

        {/* Photo card */}
        <Surface level={1} padding={0} radius={R.lg} style={{ overflow: 'hidden' }}>
          {/* Photo slot — solid gradient stand-in */}
          <div style={{
            height: 180,
            background: 'linear-gradient(135deg, #2a3a2e, #1a2a22 60%, #3a4a3a)',
            position: 'relative',
            transform: `scale(${lerp(0.94, 1, photoIn)})`,
            opacity: photoIn,
          }}>
            {/* Shutter flash */}
            <div style={{
              position: 'absolute', inset: 0, background: '#F4EFFF',
              opacity: shutter * 0.6, pointerEvents: 'none',
            }} />
            {/* Stand-in plate */}
            <div style={{
              position: 'absolute', inset: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              opacity: 0.4,
            }}>
              <svg width="80" height="80" viewBox="0 0 100 100" fill="none">
                <circle cx="50" cy="50" r="36" stroke="#A8C9B0" strokeWidth="2" />
                <circle cx="50" cy="50" r="28" stroke="#A8C9B0" strokeWidth="1" opacity="0.5" />
                <path d="M30 55 Q50 30 70 55" stroke="#A8C9B0" strokeWidth="2" opacity="0.7" />
              </svg>
            </div>
            {/* AI scan line */}
            {scanFade > 0 && (
              <div style={{
                position: 'absolute', left: 0, right: 0,
                top: `${scanP * 100}%`,
                height: 2,
                background: 'linear-gradient(90deg, rgba(126,224,184,0), rgba(126,224,184,1), rgba(126,224,184,0))',
                opacity: scanFade,
                pointerEvents: 'none',
                boxShadow: '0 0 12px rgba(126,224,184,0.6)',
              }} />
            )}
            {/* Scan trace tint */}
            {scanP > 0 && scanFade > 0 && (
              <div style={{
                position: 'absolute', left: 0, right: 0, top: 0, bottom: `${(1 - scanP) * 100}%`,
                background: 'linear-gradient(180deg, rgba(126,224,184,0.05), rgba(126,224,184,0.15))',
                opacity: scanFade,
                pointerEvents: 'none',
              }} />
            )}
            {/* Scanning chip */}
            <div style={{
              position: 'absolute', top: 12, left: 12,
              padding: '5px 10px', borderRadius: R.pill,
              background: 'rgba(11,7,18,0.7)', border: `1px solid ${SURF.hairline}`,
              backdropFilter: 'blur(8px)',
              display: 'flex', alignItems: 'center', gap: 6,
              opacity: scanFade,
            }}>
              <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
              <Meta size={9} color="#7EE0B8">scanning…</Meta>
            </div>
          </div>

          {/* Detected items */}
          <div style={{ padding: '14px 16px', display: 'flex', flexDirection: 'column', gap: 10 }}>
            <Meta>Recognised</Meta>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              {[
                { l: 'Grilled chicken',  m: '180 g · 38P · 220 kcal' },
                { l: 'Brown rice',       m: '120 g · 3P · 140 kcal'  },
                { l: 'Roasted veg',      m: '160 g · 4P · 90 kcal'   },
                { l: 'Olive dressing',   m: '15 g · 0P · 170 kcal'   },
              ].map((d, i) => {
                const p = itemAt(i);
                return (
                  <div key={i} style={{
                    display: 'flex', alignItems: 'center', gap: 10,
                    padding: '8px 0',
                    borderTop: i ? `1px solid ${SURF.hairline}` : 'none',
                    opacity: p,
                    transform: `translateX(${(1 - p) * 8}px)`,
                  }}>
                    <div style={{ width: 5, height: 5, borderRadius: 3, background: '#7EE0B8' }} />
                    <Title size={13} style={{ flex: 1, fontWeight: 700 }}>{d.l}</Title>
                    <Meta size={9.5} color={SURF.tx3}>{d.m}</Meta>
                  </div>
                );
              })}
            </div>
          </div>
        </Surface>

        {/* Macro ring + summary */}
        <Surface level={1} padding={14} radius={R.lg} style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Ring
            size={90}
            stroke={8}
            gap={3}
            segments={[
              { value: 620 * ringP, max: 2000, color: '#7EE0B8' },
              { value: 45 * ringP,  max: 140,  color: '#F4C16A' },
            ]}
            center={
              <>
                <Meta size={8}>+kcal</Meta>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 20, color: SURF.tx1, lineHeight: 1, marginTop: 2 }}>{Math.round(620 * ringP)}</div>
              </>
            }
          />
          <div style={{ flex: 1 }}>
            <Title size={14}>Added to today</Title>
            <Body size={11.5} color={SURF.tx3} style={{ marginTop: 2 }}>1,420 → 2,040 kcal · 92 → 137g P</Body>
            <div style={{ marginTop: 10, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
              <div style={{ width: `${ringP * 88}%`, height: '100%', background: '#7EE0B8' }} />
            </div>
            <Meta size={9} color={SURF.tx3} style={{ marginTop: 6 }}>protein · 137 / 140 g</Meta>
          </div>
        </Surface>

        {/* XP toast */}
        <div style={{
          alignSelf: 'center',
          padding: '8px 14px', borderRadius: R.pill,
          background: 'rgba(201,160,255,0.14)',
          border: '1px solid rgba(201,160,255,0.36)',
          display: 'flex', alignItems: 'center', gap: 8,
          opacity: toastP,
          transform: `translateY(${(1 - toastP) * 10}px)`,
        }}>
          <div style={{ width: 5, height: 5, borderRadius: 3, background: '#C9A0FF' }} />
          <Meta color="#C9A0FF">+20 xp · food photo</Meta>
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 11 — Idle ambient.
// Settled state. The product is alive but not asking for attention.
// Aurora orbs drift in lazy sin paths. The live block has a 4 s breath.
// The status dot blinks once every 3 s. The mic FAB has a very subtle
// halo pulse to indicate "I'm listening if you need me".
// ─────────────────────────────────────────────────────────────
function IdleAmbient() {
  const DUR = 8000;
  const t = useLoopTime(DUR);

  // Aurora drift: slow sine, ±6 px
  const dx1 = Math.sin((t / 8000) * Math.PI * 2) * 6;
  const dy1 = Math.cos((t / 8000) * Math.PI * 2 + 0.8) * 4;
  const dx2 = Math.sin((t / 9200) * Math.PI * 2 + 1.6) * 5;
  const dy2 = Math.cos((t / 7400) * Math.PI * 2 + 0.4) * 5;

  // Live block breath — 4 s period
  const breath = (Math.sin((t / 4000) * Math.PI * 2) + 1) / 2;
  const liveScale = lerp(1, 1.006, breath);
  const liveAlpha = lerp(0.92, 1.0, breath);

  // Mic FAB halo — 5 s period
  const halo = (Math.sin((t / 5000) * Math.PI * 2) + 1) / 2;
  const haloOpacity = lerp(0.15, 0.4, halo);
  const haloScale = lerp(1.0, 1.18, halo);

  // Live "NOW" dot blink — every 2.6s, brief
  const blinkPhase = (t % 2600) / 2600;
  const blinkOpacity = blinkPhase < 0.1 ? 1 : lerp(0.4, 1, Math.max(0, 1 - (blinkPhase - 0.1) * 4));

  // Avatar ring oscillates ±0.5%
  const ringDrift = Math.sin((t / 6400) * Math.PI * 2) * 0.005;

  return (
    <SceneFrame
      title="11 · Idle · alive but quiet"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 0,    label: 'Aurora drifts · ±6 px · sin 8 s',     spec: 'CSS transform only' },
        { at: 0,    label: 'Live block · 4 s breath · scale 1.006', spec: 'opacity 0.92 → 1.0' },
        { at: 0,    label: 'Mic FAB · 5 s halo pulse',              spec: 'opacity 0.15 → 0.40' },
        { at: 0,    label: 'Status dot · 2.6 s blink',              spec: '100 ms on · 400 ms decay' },
        { at: 0,    label: 'Avatar ring · ±0.5 % drift',            spec: 'sin 6.4 s' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}
    >
      {/* Aurora — drifts */}
      <div style={{ position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden' }}>
        <div style={{
          position: 'absolute', top: -180, left: -80, width: 360, height: 360, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(165,132,255,0.22), rgba(165,132,255,0) 70%)',
          filter: 'blur(28px)',
          transform: `translate(${dx1}px, ${dy1}px)`,
        }} />
        <div style={{
          position: 'absolute', top: -120, right: -120, width: 320, height: 320, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(126,224,184,0.10), rgba(126,224,184,0) 70%)',
          filter: 'blur(36px)',
          transform: `translate(${dx2}px, ${dy2}px)`,
        }} />
      </div>

      <div style={{ padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 16, position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <div style={{ transform: `scale(${1 + ringDrift})` }}>
            <Avatar initials="AR" pct={0.42 + ringDrift} size={42} />
          </div>
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Today</Title>
          </div>
          {/* Mic FAB with halo */}
          <div style={{ position: 'relative' }}>
            <div style={{
              position: 'absolute', inset: -6, borderRadius: '50%',
              border: `1px solid rgba(165,132,255,${haloOpacity})`,
              transform: `scale(${haloScale})`,
              pointerEvents: 'none',
            }} />
            <MicFab />
          </div>
        </div>

        {/* Live block - breathing */}
        <div style={{
          padding: '14px 16px', borderRadius: R.md,
          background: `linear-gradient(180deg, ${DOMAINS.goal.hue}${Math.round(lerp(8, 18, breath)).toString(16).padStart(2,'0')}, ${DOMAINS.goal.hue}08)`,
          border: `1px solid ${DOMAINS.goal.hue}${Math.round(lerp(36, 64, breath)).toString(16).padStart(2,'0')}`,
          transform: `scale(${liveScale})`,
          opacity: liveAlpha,
          transformOrigin: 'center',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
            <Meta color="#C5B3FF">Live · deep work</Meta>
            <div style={{ flex: 1 }} />
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <div style={{ width: 5, height: 5, borderRadius: 3, background: '#C5B3FF', opacity: blinkOpacity }} />
              <Meta size={9.5} color="#C5B3FF">42m left</Meta>
            </div>
          </div>
          <Title size={15}>Spec for Q3 launch</Title>
          <Body size={11.5} color={SURF.tx3} style={{ marginTop: 4 }}>Started 09:18 · phone in dock</Body>
          <div style={{ marginTop: 12, height: 3, borderRadius: 2, background: 'rgba(255,255,255,0.06)', overflow: 'hidden' }}>
            <div style={{ width: '62%', height: '100%', background: 'linear-gradient(90deg, #A584FF, #C5B3FF)' }} />
          </div>
        </div>

        {/* Rest of the page is calm and still */}
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <TimelineBlock first time="12:30" title="Lunch · 600 kcal" module="health" />
          <TimelineBlock time="14:00" title="Andrew Ng · L4" module="polymath" />
          <TimelineBlock last time="16:00" title="ML mock · system design" module="career" />
        </div>

        {/* Calm message about what the user feels */}
        <Surface level={1} padding={14} radius={R.md}>
          <Body size={11.5} color={SURF.tx2} style={{ lineHeight: 1.55 }}>
            Nothing demands you. The block is alive — barely — so glancing at the phone tells you the work is still running. Look away and the screen forgets you were there.
          </Body>
        </Surface>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// Intro — motion principles (a wide artboard)
// ─────────────────────────────────────────────────────────────
function MotionIntro() {
  // A small live demo strip at the bottom showing each ease curve.
  const t = useLoopTime(3000);
  const p = t / 3000;

  const curves = [
    { l: 'out',    fn: E.out,    use: 'Entries · reveals · soft landings' },
    { l: 'soft',   fn: E.soft,   use: 'Hero text · large surface arrivals' },
    { l: 'spring', fn: E.spring, use: 'Springs · taps · short snaps' },
    { l: 'bounce', fn: E.bounce, use: 'Number ticks · streak +1' },
    { l: 'in-out', fn: E.inOut,  use: 'Morphs · scroll · transitions' },
    { l: 'pulse',  fn: E.pulse,  use: 'Flashes · attention bells' },
  ];

  return (
    <div style={{
      width: 1080, height: 1280,
      background: '#0B0712',
      padding: 56,
      fontFamily: 'DM Sans, system-ui',
      position: 'relative', overflow: 'hidden',
      color: SURF.tx1,
    }}>
      {/* quiet aurora */}
      <div style={{
        position: 'absolute', top: -200, right: -180, width: 520, height: 520, borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(165,132,255,0.16), rgba(165,132,255,0) 70%)',
        filter: 'blur(36px)', pointerEvents: 'none',
      }} />

      <div style={{ display: 'flex', alignItems: 'baseline', gap: 18, position: 'relative' }}>
        <Meta size={11} color="rgba(244,239,255,0.4)">LifeOS · motion + interaction pass</Meta>
        <div style={{ flex: 1, height: 1, background: SURF.hairline }} />
        <Meta size={11} color="rgba(244,239,255,0.4)">11 scenes · 4 — 8 s each</Meta>
      </div>

      <div style={{ marginTop: 28, maxWidth: 820, position: 'relative' }}>
        <Display size={62} style={{ letterSpacing: -1.2, lineHeight: 1, fontWeight: 800 }}>
          Make it move<br/>
          <span style={{ color: SURF.tx3 }}>like a thought, not a slot machine.</span>
        </Display>
        <Body size={17} color={SURF.tx2} style={{ marginTop: 28, lineHeight: 1.6, maxWidth: 620 }}>
          Every motion in LifeOS is intentional. A hold returns warmth, a streak rolls forward with a finger's settle, an AI thought lands at reading speed. Nothing pings, nothing bounces just to bounce. Below — the six curves the product uses, the timing budget, and the rule we never break.
        </Body>
      </div>

      {/* Motion philosophy — three pillars */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 24, marginTop: 56, position: 'relative' }}>
        {[
          { h: 'Soft physics',     b: 'Springs with damping 0.7+, never below 0.55. Bounce stops at one overshoot. Nothing overshoots more than 6 %.' },
          { h: 'Spatial continuity',b: 'Anything that becomes something else moves through space to get there. Sheets rise from the FAB, headers compress into the band they will become.' },
          { h: 'Emotional pacing',  b: 'Calm beats fast. Text reveals at reading speed. Insights wait for you to look. Rewards arrive at the end of an action, never at its start.' },
        ].map((p, i) => (
          <div key={i} style={{ padding: '20px 22px', borderRadius: R.lg, border: `1px solid ${SURF.hairline}`, background: SURF.s1 }}>
            <div style={{ width: 6, height: 6, borderRadius: 3, background: ['#A584FF', '#7EE0B8', '#FFD66B'][i], marginBottom: 12 }} />
            <Title size={17}>{p.h}</Title>
            <Body size={13} color={SURF.tx2} style={{ marginTop: 8, lineHeight: 1.55 }}>{p.b}</Body>
          </div>
        ))}
      </div>

      {/* Six curves with live previews */}
      <div style={{ marginTop: 56, position: 'relative' }}>
        <Meta size={11} color={SURF.tx3} style={{ marginBottom: 16 }}>Six curves · the entire motion vocabulary</Meta>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 16 }}>
          {curves.map(c => {
            const v = c.fn(p);
            return (
              <div key={c.l} style={{ padding: '16px 18px', borderRadius: R.md, border: `1px solid ${SURF.hairline}`, background: SURF.s1 }}>
                <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 14 }}>
                  <Title size={14}>{c.l}</Title>
                  <div style={{ flex: 1 }} />
                  <Meta size={9.5} color={SURF.tx3}>{(v * 100).toFixed(0)} %</Meta>
                </div>
                {/* curve plot */}
                <svg width="100%" height="50" viewBox="0 0 100 50" style={{ overflow: 'visible' }}>
                  <path
                    d={(() => {
                      const pts = [];
                      for (let i = 0; i <= 40; i++) {
                        const x = i / 40;
                        const y = c.fn(x);
                        pts.push(`${i === 0 ? 'M' : 'L'} ${x * 100} ${50 - y * 46 - 2}`);
                      }
                      return pts.join(' ');
                    })()}
                    fill="none" stroke="rgba(244,239,255,0.16)" strokeWidth="1.4"
                  />
                  {/* live dot */}
                  <circle cx={p * 100} cy={50 - v * 46 - 2} r="3" fill="#A584FF" />
                </svg>
                {/* live moving ball */}
                <div style={{ marginTop: 10, height: 10, borderRadius: 5, background: 'rgba(255,255,255,0.04)', position: 'relative' }}>
                  <div style={{
                    position: 'absolute', top: 1, left: `calc(${v * 100}% - 4px)`,
                    width: 8, height: 8, borderRadius: 4, background: '#C5B3FF',
                  }} />
                </div>
                <Body size={11} color={SURF.tx3} style={{ marginTop: 10, lineHeight: 1.45 }}>{c.use}</Body>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer rule */}
      <div style={{ position: 'absolute', left: 56, right: 56, bottom: 56, paddingTop: 22, borderTop: `1px solid ${SURF.hairline}` }}>
        <Meta size={11} color={SURF.tx3}>The one rule we never break</Meta>
        <Title size={20} style={{ marginTop: 8, letterSpacing: -0.3 }}>
          If a motion exists, it tells the user something they need to know.
        </Title>
      </div>
    </div>
  );
}

Object.assign(window, { HealthLogging, IdleAmbient, MotionIntro });
