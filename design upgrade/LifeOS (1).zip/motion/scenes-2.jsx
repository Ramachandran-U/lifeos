// Motion scenes — part 2
// 06 Sheet enter/exit · 07 Scroll dynamics · 08 AI insight reveal · 09 Loading → loaded

const { ProFrame, Surface, Display, Title, Body, Meta, Avatar, HexRadar, XpBar, Skel,
        TimelineBlock, TabBar, Icon, MicFab, Sparkline, Ring, SURF, R, DOMAINS } = window;
const { M, E, clamp, lerp, range, rangeAt, segment, useLoopTime, useDrift, SceneFrame } = window;

// ─────────────────────────────────────────────────────────────
// 06 — Quick-log sheet enter/exit.
// Tap mic → sheet rises with soft spring → grid items stagger →
// hold → sheet slides back down. The page behind dims gently.
// ─────────────────────────────────────────────────────────────
function SheetEnterExit() {
  const DUR = 5600;
  const t = useLoopTime(DUR);

  // 1. FAB press (anticipation)
  const fabPress  = segment(t, 200, 200, E.in);
  const fabRelease = 1 - segment(t, 350, 200, E.out);
  const fabScale = lerp(1, 0.92, fabPress) * lerp(0.92, 1, 1 - fabRelease);

  // 2. Scrim + sheet
  const scrimIn   = segment(t, 350, 480, E.out);
  const sheetIn   = segment(t, 380, 540, E.spring);

  // 3. Grid stagger — 6 items
  const itemAt = (i) => segment(t, 900 + i * 50, 320, E.spring);

  // 4. Hold
  const holdEnd = 4000;

  // 5. Exit — sheet slides down, scrim fades
  const sheetOut = segment(t, holdEnd, 520, E.in);
  const scrimOut = segment(t, holdEnd + 80, 460, E.in);

  const sheetY = lerp(420, 0, sheetIn) + sheetOut * 460;
  const scrimAlpha = (scrimIn - scrimOut) * 0.55;

  return (
    <SceneFrame
      title="06 · Quick-log sheet"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 200,  label: 'Mic FAB · press · scale 92 %',  spec: '200 ms · ease-in' },
        { at: 380,  label: 'Sheet · spring up · 540 ms',    spec: 'soft spring' },
        { at: 350,  label: 'Scrim · linear fade · 480 ms',  spec: 'ease-out · 55 % alpha' },
        { at: 900,  label: '6 tiles · stagger 50 ms',       spec: '320 ms · spring' },
        { at: 4000, label: 'Sheet exits · ease-in',         spec: '520 ms · y 460' },
      ]}
      footer={
        <div style={{ paddingBottom: 12, position: 'relative' }}>
          <TabBar active="today" />
        </div>
      }
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 14, filter: `brightness(${lerp(1, 0.45, scrimAlpha / 0.55)}) saturate(${lerp(1, 0.85, scrimAlpha / 0.55)})` }}>
        {/* Today preview behind */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10 }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Good morning, Arjun</Title>
          </div>
          <div style={{ transform: `scale(${fabScale})` }}>
            <MicFab listening={fabPress > 0 && fabRelease > 0} />
          </div>
        </div>
        <Display size={24} style={{ marginTop: 6 }}>One thing today.</Display>
        <Surface level={1} padding={16} radius={R.lg} style={{ marginTop: 6, height: 160 }} />
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <TimelineBlock first time="06:30" title="Wake · sunlight" module="health" status="completed" />
          <TimelineBlock time="09:00" title="Deep work · spec" module="goal" live />
          <TimelineBlock last time="12:30" title="Lunch · 600 kcal" module="health" />
        </div>
      </div>

      {/* Scrim */}
      <div style={{ position: 'absolute', inset: 0, background: `rgba(8,4,16,${scrimAlpha})`, zIndex: 4, pointerEvents: 'none' }} />

      {/* Sheet */}
      <div style={{
        position: 'absolute', left: 9, right: 9, bottom: 9, zIndex: 5,
        transform: `translateY(${sheetY}px)`,
        opacity: sheetIn > 0.05 ? 1 : sheetIn * 20,
        background: SURF.s4,
        borderTopLeftRadius: 32, borderTopRightRadius: 32,
        borderBottomLeftRadius: 38, borderBottomRightRadius: 38,
        backdropFilter: 'blur(28px) saturate(140%)',
        WebkitBackdropFilter: 'blur(28px) saturate(140%)',
        border: `1px solid ${SURF.hairlineStrong}`,
        boxShadow: '0 -12px 40px rgba(0,0,0,0.45)',
        padding: '14px 18px 22px',
      }}>
        <div style={{ width: 38, height: 4, borderRadius: 2, background: SURF.hairlineStrong, margin: '0 auto 14px' }} />
        <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 4 }}>
          <Title size={17}>Log something</Title>
          <div style={{ flex: 1 }} />
          <Meta size={9.5} color={SURF.tx3}>+20 xp</Meta>
        </div>
        <Body size={12} color={SURF.tx3} style={{ marginBottom: 14 }}>Pick what just happened.</Body>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
          {[
            { l: 'Meal',     i: 'camera',  c: '#7EE0B8' },
            { l: 'Mood',     i: 'sun',     c: '#FFD66B' },
            { l: 'Workout',  i: 'bolt',    c: '#7FB8FF' },
            { l: 'Spend',    i: 'plus',    c: '#F4C16A' },
            { l: 'Journal',  i: 'leaf',    c: '#C9A0FF' },
            { l: 'Resource', i: 'bell',    c: '#FF99C5' },
          ].map((x, i) => {
            const p = itemAt(i);
            return (
              <div key={i} style={{
                padding: '14px 8px', borderRadius: R.md,
                background: SURF.s2, border: `1px solid ${SURF.hairline}`,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
                opacity: p,
                transform: `translateY(${(1 - p) * 12}px) scale(${lerp(0.96, 1, p)})`,
              }}>
                <Icon name={x.i} size={20} color={x.c} strokeWidth={1.6} />
                <Title size={12} style={{ marginTop: 2 }}>{x.l}</Title>
              </div>
            );
          })}
        </div>

        {/* Voice option */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 12, marginTop: 16,
          padding: '12px 14px', borderRadius: R.md,
          border: `1px solid ${SURF.hairline}`, background: SURF.s1,
          opacity: itemAt(5),
        }}>
          <MicFab listening />
          <div style={{ flex: 1 }}>
            <Title size={13}>Or just say it</Title>
            <Body size={11} color={SURF.tx3} style={{ marginTop: 2 }}>"Logged a 35 min run"</Body>
          </div>
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 07 — Scroll dynamics.
// The hero zone compresses into a sticky band as the page scrolls.
// The aurora wash drifts at half the scroll velocity (parallax).
// At rest the band reads as native chrome; at top it dissolves entirely.
// ─────────────────────────────────────────────────────────────
function ScrollDynamics() {
  const DUR = 6400;
  const t = useLoopTime(DUR);

  // Scroll progress: 0 at top, 1 fully scrolled.
  // 0–800ms idle, 800–2400 scroll down, 2400–3800 hold, 3800–5400 scroll up, 5400–6400 idle
  const down = segment(t, 800, 1600, E.inOut);
  const up   = segment(t, 3800, 1600, E.inOut);
  const sp = clamp(down - up); // 0..1

  // Content moves up by this many px
  const offset = sp * 360;

  // Sticky band materializes when sp > 0.18
  const bandP = clamp((sp - 0.18) / 0.5);

  return (
    <SceneFrame
      title="07 · Scroll · sticky chrome"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 800,  label: 'Scroll begins · ease-in-out',    spec: '1.6 s · 360 px' },
        { at: 1200, label: 'Hero typography shrinks',        spec: 'linked to scroll · 32 → 14' },
        { at: 1400, label: 'Aurora drifts at 0.5× velocity', spec: 'parallax' },
        { at: 1600, label: 'Sticky band materializes · 240 ms blur', spec: 'opacity · backdrop-filter' },
        { at: 3800, label: 'Scroll up · mirror exit',         spec: 'ease-in-out · 1.6 s' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}
    >
      {/* Aurora parallax */}
      <div style={{
        position: 'absolute', inset: 0, pointerEvents: 'none', overflow: 'hidden',
        transform: `translateY(${-offset * 0.5}px)`,
      }}>
        <div style={{
          position: 'absolute', top: -180, left: -80, width: 360, height: 360, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(165,132,255,0.22), rgba(165,132,255,0) 70%)',
          filter: 'blur(28px)',
        }} />
        <div style={{
          position: 'absolute', top: -120, right: -120, width: 320, height: 320, borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(126,224,184,0.10), rgba(126,224,184,0) 70%)',
          filter: 'blur(36px)',
        }} />
      </div>

      {/* Sticky band (chrome) — fades + blurs in */}
      <div style={{
        position: 'absolute', left: 9, right: 9, top: 56, zIndex: 5,
        padding: '8px 18px',
        background: `rgba(11,7,18,${bandP * 0.78})`,
        backdropFilter: bandP > 0 ? `blur(${20 * bandP}px) saturate(140%)` : 'none',
        WebkitBackdropFilter: bandP > 0 ? `blur(${20 * bandP}px) saturate(140%)` : 'none',
        borderBottom: bandP > 0.4 ? `1px solid ${SURF.hairline}` : 'none',
        display: 'flex', alignItems: 'center', gap: 10,
        opacity: bandP,
        pointerEvents: 'none',
      }}>
        <Avatar initials="AR" pct={0.42} size={28} />
        <div style={{ flex: 1 }}>
          <Title size={13}>Today</Title>
          <Meta size={9}>balance 64 · 2 of 6 done</Meta>
        </div>
        <div style={{ width: 22, height: 22, borderRadius: 11, border: `1px solid ${SURF.hairline}`, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Icon name="search" size={11} color={SURF.tx2} />
        </div>
      </div>

      {/* Page content — translates up */}
      <div style={{
        padding: '4px 20px 0', display: 'flex', flexDirection: 'column', gap: 16,
        transform: `translateY(${-offset}px)`,
        position: 'relative',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 10, opacity: 1 - clamp(sp * 1.6) }}>
          <Avatar initials="AR" pct={0.42} size={42} />
          <div style={{ flex: 1 }}>
            <Meta size={9.5}>Tue · May 13</Meta>
            <Title size={20} style={{ marginTop: 2 }}>Good morning, Arjun</Title>
          </div>
          <MicFab />
        </div>

        <Display size={lerp(26, 18, clamp(sp * 1.4))} style={{ letterSpacing: -0.5, lineHeight: 1.18, opacity: 1 - clamp(sp * 1.2) }}>
          One thing today.<br/>
          <span style={{ color: SURF.tx2 }}>The </span>
          <span style={{ color: '#C5B3FF' }}>ML mock at 4 PM</span>
        </Display>

        <Surface level={1} padding={16} radius={R.lg}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <HexRadar scores={{ goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 }} size={120} showLabels={false} />
            <div style={{ flex: 1 }}>
              <Meta>Life balance</Meta>
              <Display size={32} style={{ lineHeight: 1, marginTop: 4 }}>64</Display>
              <Meta color="#7EE0B8" style={{ marginTop: 8 }}>▲ 4 wk</Meta>
            </div>
          </div>
        </Surface>

        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <TimelineBlock first time="06:30" title="Wake · sunlight" module="health" status="completed" />
          <TimelineBlock time="07:00" title="Strength · push day" module="health" status="completed" />
          <TimelineBlock time="09:00" title="Deep work · spec" module="goal" live />
          <TimelineBlock time="12:30" title="Lunch · 600 kcal" module="health" />
          <TimelineBlock time="14:00" title="Andrew Ng · L4" module="polymath" />
          <TimelineBlock last time="16:00" title="ML mock interview" module="career" />
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 08 — AI insight reveal.
// Sparkle pulses, then text reveals with a soft typing rhythm,
// then the chart bars rise in stagger, then the highlighted bar pulses
// once. Premium because it's slow enough to actually read.
// ─────────────────────────────────────────────────────────────
function AIInsightReveal() {
  const DUR = 5800;
  const t = useLoopTime(DUR);

  const sparkP   = segment(t, 200, 320, E.out);
  const sparkFade = 1 - segment(t, 700, 400, E.in);

  // Typed reveal
  const FULL = "Food delivery up 38% — 11 Swiggy orders. Try cooking 3× this week to claw back ~₹2,800.";
  const typeP = segment(t, 600, 1900, E.inOut);
  const chars = Math.floor(FULL.length * typeP);
  const typed = FULL.slice(0, chars);
  const cursorOn = ((t / 500) | 0) % 2 === 0;

  // Bar stagger
  const barAt = (i) => segment(t, 2500 + i * 60, 380, E.spring);

  // Friday pulse
  const friPulse = E.pulse(segment(t, 3200, 700, (x) => x));

  // Exit reset
  const exitP = segment(t, 4900, 600, E.in);

  return (
    <SceneFrame
      title="08 · AI insight · finance"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 200,  label: 'Sparkle pulses · attention',    spec: '320 ms · ease-out' },
        { at: 600,  label: 'Text types in · 1.9 s',         spec: 'ease-in-out · 49 chars/s' },
        { at: 2500, label: '7 bars rise · stagger 60 ms',   spec: '380 ms · soft spring' },
        { at: 3200, label: 'Friday bar pulses once',         spec: '700 ms · bell · scale 1.06' },
        { at: 4900, label: 'Fades for loop',                 spec: '600 ms · ease-in' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="goals" /></div>}
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 14, opacity: 1 - exitP }}>
        <div style={{ marginTop: 10 }}>
          <Meta color="#F4C16A">Money</Meta>
          <Display size={26} style={{ marginTop: 4 }}>May at a glance</Display>
        </div>

        {/* Stub summary */}
        <Surface level={1} padding={14} radius={R.lg}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr' }}>
            {[
              { l: 'Earned', v: '₹1.42L' },
              { l: 'Spent',  v: '₹1.03L' },
              { l: 'Saved',  v: '₹38.4k', tone: '#7EE0B8' },
            ].map((s, i) => (
              <div key={i} style={{ borderLeft: i ? `1px solid ${SURF.hairline}` : 'none', paddingLeft: i ? 12 : 0 }}>
                <Meta size={9.5}>{s.l}</Meta>
                <div style={{ fontFamily: 'Nunito', fontWeight: 800, fontSize: 17, color: s.tone || SURF.tx1, marginTop: 4 }}>{s.v}</div>
              </div>
            ))}
          </div>
        </Surface>

        {/* The actual AI insight card */}
        <Surface level={2} padding={16} radius={R.lg} accent="#C9A0FF">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <div style={{
              transform: `scale(${lerp(0.6, 1, sparkP)})`,
              opacity: sparkP * sparkFade + (1 - sparkFade) * 1,
            }}>
              <Icon name="sparkle" size={14} color="#C5B3FF" />
            </div>
            <Meta color="#C5B3FF">This week's spend</Meta>
            {/* Sparkle ripple */}
            {sparkP > 0 && sparkFade > 0.01 && (
              <div style={{
                width: 14, height: 14, borderRadius: 7,
                position: 'absolute', top: 14, left: 12,
                border: `1px solid #C5B3FF`,
                transform: `scale(${1 + sparkP * 2.5})`,
                opacity: sparkFade * 0.6,
                pointerEvents: 'none',
              }} />
            )}
          </div>

          {/* Typed body */}
          <Body size={13.5} color={SURF.tx1} style={{ lineHeight: 1.5, minHeight: 60 }}>
            {(() => {
              // Highlight the "up 38%" fragment
              const hl = "up 38%";
              if (typed.includes(hl)) {
                const idx = typed.indexOf(hl);
                return (
                  <>
                    {typed.slice(0, idx)}
                    <span style={{ color: '#FF99C5', fontWeight: 600 }}>{typed.slice(idx, idx + hl.length)}</span>
                    {typed.slice(idx + hl.length)}
                  </>
                );
              }
              return typed;
            })()}
            {typeP < 1 && cursorOn && <span style={{ color: '#C5B3FF', marginLeft: 1 }}>▍</span>}
          </Body>

          {/* Bar chart */}
          <div style={{ marginTop: 16 }}>
            <div style={{ display: 'flex', gap: 6, alignItems: 'flex-end', height: 56 }}>
              {[12, 8, 22, 18, 28, 14, 10].map((v, i) => {
                const p = barAt(i);
                const isFri = i === 4;
                const pulseScale = isFri ? 1 + friPulse * 0.06 : 1;
                return (
                  <div key={i} style={{
                    flex: 1, height: `${(v / 28) * 100 * p}%`,
                    borderRadius: 3,
                    background: isFri ? '#FF99C5' : 'rgba(255,153,197,0.28)',
                    transformOrigin: 'bottom',
                    transform: `scaleY(${p}) scale(${pulseScale})`,
                    opacity: p,
                  }} />
                );
              })}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
              {['M','T','W','T','F','S','S'].map((l, i) => (
                <Meta key={i} size={9} color={i === 4 ? '#FF99C5' : SURF.tx4} style={{ flex: 1, textAlign: 'center', letterSpacing: 0.6, opacity: barAt(i) }}>{l}</Meta>
              ))}
            </div>
          </div>
        </Surface>

        {/* Action prompt — slides in after the chart settles */}
        <div style={{
          opacity: segment(t, 3700, 400, E.out) * (1 - exitP),
          transform: `translateY(${(1 - segment(t, 3700, 400, E.out)) * 12}px)`,
        }}>
          <Surface level={1} padding={12} radius={R.md} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Body size={12} color={SURF.tx2} style={{ flex: 1, lineHeight: 1.4 }}>Set a 3-meals-home target for next week?</Body>
            <div style={{ padding: '6px 12px', borderRadius: R.sm, background: 'rgba(126,224,184,0.16)', border: '1px solid rgba(126,224,184,0.36)', fontFamily: 'DM Sans', fontWeight: 600, fontSize: 11.5, color: '#7EE0B8' }}>Yes</div>
          </Surface>
        </div>
      </div>
    </SceneFrame>
  );
}

// ─────────────────────────────────────────────────────────────
// 09 — Loading → loaded.
// Skeleton shimmer at a calm pace, then real content fades in by row
// with a 90 ms stagger. No spinner. The shimmer reverses for loop.
// ─────────────────────────────────────────────────────────────
function LoadingToLoaded() {
  const DUR = 5400;
  const t = useLoopTime(DUR);

  // 0–1900ms skeleton, 1900–3400ms transition, 3400–4400 hold, 4400–5400 reset
  const loaded = segment(t, 1900, 1300, E.out);
  const reset  = segment(t, 4400, 800, E.in);

  // Per-row stagger
  const rowAt = (i) => segment(t, 1900 + i * 90, 700, E.out);

  const eff = clamp(loaded - reset);

  return (
    <SceneFrame
      title="09 · Loading → loaded"
      durationMs={DUR}
      t={t}
      beats={[
        { at: 0,    label: 'Skeleton · global shimmer',         spec: '1.8 s loop · 480 px sweep' },
        { at: 1900, label: 'Skeletons fade · content arrives',   spec: '1.3 s · ease-out' },
        { at: 1900, label: 'Rows stagger 90 ms · 7 items',       spec: '700 ms each' },
        { at: 4400, label: 'Reset · for loop',                   spec: '800 ms · ease-in' },
      ]}
      footer={<div style={{ paddingBottom: 12 }}><TabBar active="today" /></div>}
    >
      <div style={{ padding: '6px 20px 0', display: 'flex', flexDirection: 'column', gap: 14, position: 'relative' }}>
        {/* Skeleton layer */}
        <div style={{ opacity: 1 - eff, position: 'relative', display: 'flex', flexDirection: 'column', gap: 14, marginTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Skel w={42} h={42} r={21} />
            <div style={{ flex: 1 }}>
              <Skel w={80} h={9} r={4} />
              <Skel w={160} h={18} r={6} style={{ marginTop: 6 }} />
            </div>
            <Skel w={40} h={40} r={20} />
          </div>
          <Skel w="78%" h={22} r={8} />
          <Skel w="60%" h={22} r={8} />
          <Surface level={1} padding={16} radius={R.lg}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
              <Skel w={120} h={120} r={60} />
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                <Skel w={60} h={9} r={3} />
                <Skel w={80} h={28} r={8} />
                <Skel w="100%" h={6} r={3} style={{ marginTop: 6 }} />
                <Skel w="80%" h={6} r={3} />
              </div>
            </div>
          </Surface>
          {[0,1,2,3,4].map(i => (
            <div key={i} style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
              <Skel w={11} h={11} r={6} />
              <Skel w={42} h={10} r={4} />
              <Skel w={`${[60, 75, 50, 70, 65][i]}%`} h={14} r={6} />
            </div>
          ))}
        </div>

        {/* Loaded layer — overlaid */}
        <div style={{ position: 'absolute', inset: 0, padding: '16px 20px 0', display: 'flex', flexDirection: 'column', gap: 14, pointerEvents: eff > 0.4 ? 'auto' : 'none' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, opacity: rowAt(0) * (1 - reset), transform: `translateY(${(1 - rowAt(0)) * 8}px)` }}>
            <Avatar initials="AR" pct={0.42} size={42} />
            <div style={{ flex: 1 }}>
              <Meta size={9.5}>Tue · May 13</Meta>
              <Title size={20} style={{ marginTop: 2 }}>Good morning, Arjun</Title>
            </div>
            <MicFab />
          </div>

          <div style={{ opacity: rowAt(1) * (1 - reset), transform: `translateY(${(1 - rowAt(1)) * 8}px)` }}>
            <Display size={26} style={{ letterSpacing: -0.5, lineHeight: 1.18 }}>
              One thing today.<br/>
              <span style={{ color: SURF.tx2 }}>The </span>
              <span style={{ color: '#C5B3FF' }}>ML mock at 4 PM</span>
            </Display>
          </div>

          <div style={{ opacity: rowAt(2) * (1 - reset), transform: `translateY(${(1 - rowAt(2)) * 10}px)` }}>
            <Surface level={1} padding={16} radius={R.lg}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
                <HexRadar scores={{ goal: 78, health: 64, finance: 52, career: 71, social: 38, polymath: 82 }} size={110} showLabels={false} />
                <div style={{ flex: 1 }}>
                  <Meta>Life balance</Meta>
                  <Display size={32} style={{ lineHeight: 1, marginTop: 4 }}>64</Display>
                  <Meta color="#7EE0B8" style={{ marginTop: 8 }}>▲ 4 wk</Meta>
                </div>
              </div>
            </Surface>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {[
              ['06:30','Wake · sunlight','health','completed'],
              ['07:00','Strength · push day','health','completed'],
              ['09:00','Deep work · spec','goal','pending'],
              ['12:30','Lunch · 600 kcal','health','pending'],
            ].map((r, i, arr) => {
              const p = rowAt(3 + i) * (1 - reset);
              return (
                <div key={i} style={{ opacity: p, transform: `translateY(${(1 - p) * 10}px)` }}>
                  <TimelineBlock first={i === 0} last={i === arr.length - 1} time={r[0]} title={r[1]} module={r[2]} status={r[3]} live={i === 2} />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </SceneFrame>
  );
}

Object.assign(window, { SheetEnterExit, ScrollDynamics, AIInsightReveal, LoadingToLoaded });
