// Motion shared — hooks, easings, tokens, frame wrapper
// All motion in this pass is built from these atoms.

// ─────────────────────────────────────────────────────────────
// Motion tokens — opinionated, conservative, premium-leaning
// ─────────────────────────────────────────────────────────────
const M = {
  // Durations (ms)
  hairFast:   120,  // micro feedback (press)
  fast:       220,  // hover, chip press, small fade
  med:        360,  // standard reveal
  slow:       520,  // hero reveal, sheet enter
  hero:       780,  // first-mount mount
  ambient:   4200,  // breathing, drift

  // Stagger spacings (ms)
  staggerTight: 40,
  stagger:      70,
  staggerWide:  120,
};

// Eases — written as t in [0,1] → [0,1]
const E = {
  out:    (t) => 1 - Math.pow(1 - t, 3),
  in:     (t) => t * t * t,
  inOut:  (t) => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2,
  // Soft spring-flavored ease-out — used for "lands gently"
  soft:   (t) => 1 - Math.pow(1 - t, 4),
  // Damped overshoot — gentle, single tiny pull-back
  spring: (t) => {
    if (t >= 1) return 1;
    return 1 - Math.exp(-5.5 * t) * Math.cos(7.0 * t);
  },
  // Decaying bounce — used for streak number tick
  bounce: (t) => {
    if (t >= 1) return 1;
    return 1 - Math.exp(-4 * t) * Math.cos(9 * t);
  },
  // Smooth bell — 0 → 1 → 0 across [0,1]; useful for flashes
  pulse:  (t) => {
    const x = Math.sin(Math.PI * Math.max(0, Math.min(1, t)));
    return x;
  },
};

// ─────────────────────────────────────────────────────────────
// Utility: progress mapping
// ─────────────────────────────────────────────────────────────
function clamp(x, lo = 0, hi = 1) { return Math.max(lo, Math.min(hi, x)); }
function lerp(a, b, t) { return a + (b - a) * t; }
// range(t, a, b) → 0 when t<=a, 1 when t>=b, linear in between
function range(t, a, b) { return clamp((t - a) / (b - a)); }
// rangeAt(t, a, b, ease) → eased progress 0..1 across the window
function rangeAt(t, a, b, easeFn = E.out) { return easeFn(range(t, a, b)); }
// segment(t, start, len, ease) → eased 0..1 across [start, start+len]
function segment(t, start, len, easeFn = E.out) { return easeFn(clamp((t - start) / len)); }

// ─────────────────────────────────────────────────────────────
// useLoopTime — single rAF loop, returns ms within [0, durationMs]
// All scenes share this pattern so timings stay readable.
// ─────────────────────────────────────────────────────────────
function useLoopTime(durationMs = 5000) {
  const [t, setT] = React.useState(0);
  React.useEffect(() => {
    let raf;
    const start = performance.now();
    const tick = (now) => {
      setT((now - start) % durationMs);
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [durationMs]);
  return t;
}

// useDrift — returns a -1..1 sine over `periodMs` for ambient motion
function useDrift(periodMs = 6000, phase = 0) {
  const t = useLoopTime(periodMs);
  return Math.sin((t / periodMs) * Math.PI * 2 + phase);
}

// ─────────────────────────────────────────────────────────────
// SceneFrame — phone frame + caption + timeline ticker
// Used by every motion scene so they look consistent.
// ─────────────────────────────────────────────────────────────
const { ProFrame, Surface, Display, Title, Body, Meta, Icon, SURF, R } = window;

function SceneFrame({ children, title, beats, durationMs, t, footer }) {
  const pct = t / durationMs;
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Caption above */}
      <div style={{ marginLeft: 4, marginRight: 4 }}>
        <Meta size={10} color="rgba(60,50,40,0.55)">{(t / 1000).toFixed(1)}s · loops {(durationMs / 1000).toFixed(1)}s</Meta>
        <div style={{ fontFamily: 'Nunito, system-ui', fontWeight: 800, fontSize: 17, color: 'rgba(40,30,20,0.85)', letterSpacing: -0.2, marginTop: 2 }}>{title}</div>
        {/* Beat timeline */}
        <div style={{ position: 'relative', height: 14, marginTop: 8 }}>
          <div style={{ position: 'absolute', left: 0, right: 0, top: 6, height: 2, borderRadius: 1, background: 'rgba(60,50,40,0.1)' }} />
          <div style={{ position: 'absolute', left: 0, top: 6, height: 2, borderRadius: 1, width: `${pct * 100}%`, background: 'rgba(40,30,20,0.55)' }} />
          {(beats || []).map((b, i) => (
            <div key={i} style={{
              position: 'absolute', left: `${(b.at / durationMs) * 100}%`,
              top: 0, transform: 'translateX(-50%)',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2,
            }}>
              <div style={{
                width: 6, height: 6, borderRadius: 3,
                background: t / durationMs >= b.at / durationMs ? 'rgba(40,30,20,0.7)' : 'rgba(60,50,40,0.18)',
                marginTop: 4,
              }} />
            </div>
          ))}
          {/* Playhead */}
          <div style={{
            position: 'absolute', left: `${pct * 100}%`, top: 0, transform: 'translateX(-50%)',
            width: 2, height: 14, background: '#1a1028', borderRadius: 1,
          }} />
        </div>
      </div>

      {/* Phone frame, no outer label (caption replaces it) */}
      <ProFrame time="9:41" hero={false} footer={footer}>
        {children}
      </ProFrame>

      {/* Beat labels under */}
      {beats && beats.length > 0 && (
        <div style={{ marginTop: 2, paddingLeft: 4, paddingRight: 4 }}>
          {beats.map((b, i) => (
            <div key={i} style={{
              display: 'flex', gap: 10, alignItems: 'baseline',
              padding: '5px 0', borderBottom: i < beats.length - 1 ? '1px solid rgba(60,50,40,0.08)' : 'none',
              opacity: t >= b.at ? 1 : 0.35,
              transition: 'opacity 200ms',
            }}>
              <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 10, color: 'rgba(60,50,40,0.55)', letterSpacing: 0.8, width: 44, flexShrink: 0 }}>{(b.at / 1000).toFixed(1)}s</div>
              <div style={{ fontFamily: 'DM Sans, system-ui', fontSize: 12, color: 'rgba(40,30,20,0.85)', fontWeight: 500 }}>{b.label}</div>
              {b.spec && <div style={{ fontFamily: 'JetBrains Mono, monospace', fontSize: 9.5, color: 'rgba(60,50,40,0.5)', letterSpacing: 0.4, marginLeft: 'auto' }}>{b.spec}</div>}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// Re-export
Object.assign(window, {
  M, E, clamp, lerp, range, rangeAt, segment,
  useLoopTime, useDrift,
  SceneFrame,
});
